import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/api/subscriptions/tiers/{product}'
*/
const getTiers4f07c4cd53e5c3969ecd9c2102e2760b = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTiers4f07c4cd53e5c3969ecd9c2102e2760b.url(args, options),
    method: 'get',
})

getTiers4f07c4cd53e5c3969ecd9c2102e2760b.definition = {
    methods: ["get","head"],
    url: '/api/subscriptions/tiers/{product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/api/subscriptions/tiers/{product}'
*/
getTiers4f07c4cd53e5c3969ecd9c2102e2760b.url = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: args.product,
    }

    return getTiers4f07c4cd53e5c3969ecd9c2102e2760b.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/api/subscriptions/tiers/{product}'
*/
getTiers4f07c4cd53e5c3969ecd9c2102e2760b.get = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTiers4f07c4cd53e5c3969ecd9c2102e2760b.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/api/subscriptions/tiers/{product}'
*/
getTiers4f07c4cd53e5c3969ecd9c2102e2760b.head = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTiers4f07c4cd53e5c3969ecd9c2102e2760b.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/api/subscriptions/tiers/{product}'
*/
const getTiers4f07c4cd53e5c3969ecd9c2102e2760bForm = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getTiers4f07c4cd53e5c3969ecd9c2102e2760b.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/api/subscriptions/tiers/{product}'
*/
getTiers4f07c4cd53e5c3969ecd9c2102e2760bForm.get = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getTiers4f07c4cd53e5c3969ecd9c2102e2760b.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/api/subscriptions/tiers/{product}'
*/
getTiers4f07c4cd53e5c3969ecd9c2102e2760bForm.head = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getTiers4f07c4cd53e5c3969ecd9c2102e2760b.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getTiers4f07c4cd53e5c3969ecd9c2102e2760b.form = getTiers4f07c4cd53e5c3969ecd9c2102e2760bForm
/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/subscriptions/tiers/{product}'
*/
const getTierscbac36a7e8a176cc9c813c8f45ab568e = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTierscbac36a7e8a176cc9c813c8f45ab568e.url(args, options),
    method: 'get',
})

getTierscbac36a7e8a176cc9c813c8f45ab568e.definition = {
    methods: ["get","head"],
    url: '/subscriptions/tiers/{product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/subscriptions/tiers/{product}'
*/
getTierscbac36a7e8a176cc9c813c8f45ab568e.url = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: args.product,
    }

    return getTierscbac36a7e8a176cc9c813c8f45ab568e.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/subscriptions/tiers/{product}'
*/
getTierscbac36a7e8a176cc9c813c8f45ab568e.get = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTierscbac36a7e8a176cc9c813c8f45ab568e.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/subscriptions/tiers/{product}'
*/
getTierscbac36a7e8a176cc9c813c8f45ab568e.head = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTierscbac36a7e8a176cc9c813c8f45ab568e.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/subscriptions/tiers/{product}'
*/
const getTierscbac36a7e8a176cc9c813c8f45ab568eForm = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getTierscbac36a7e8a176cc9c813c8f45ab568e.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/subscriptions/tiers/{product}'
*/
getTierscbac36a7e8a176cc9c813c8f45ab568eForm.get = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getTierscbac36a7e8a176cc9c813c8f45ab568e.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getTiers
* @see app/Http/Controllers/SubscriptionController.php:28
* @route '/subscriptions/tiers/{product}'
*/
getTierscbac36a7e8a176cc9c813c8f45ab568eForm.head = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getTierscbac36a7e8a176cc9c813c8f45ab568e.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getTierscbac36a7e8a176cc9c813c8f45ab568e.form = getTierscbac36a7e8a176cc9c813c8f45ab568eForm

export const getTiers = {
    '/api/subscriptions/tiers/{product}': getTiers4f07c4cd53e5c3969ecd9c2102e2760b,
    '/subscriptions/tiers/{product}': getTierscbac36a7e8a176cc9c813c8f45ab568e,
}

/**
* @see \App\Http\Controllers\SubscriptionController::subscribe
* @see app/Http/Controllers/SubscriptionController.php:52
* @route '/api/subscriptions'
*/
const subscribe140d629c2f7d3233b5ec8d322e24dd7b = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: subscribe140d629c2f7d3233b5ec8d322e24dd7b.url(options),
    method: 'post',
})

subscribe140d629c2f7d3233b5ec8d322e24dd7b.definition = {
    methods: ["post"],
    url: '/api/subscriptions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::subscribe
* @see app/Http/Controllers/SubscriptionController.php:52
* @route '/api/subscriptions'
*/
subscribe140d629c2f7d3233b5ec8d322e24dd7b.url = (options?: RouteQueryOptions) => {
    return subscribe140d629c2f7d3233b5ec8d322e24dd7b.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::subscribe
* @see app/Http/Controllers/SubscriptionController.php:52
* @route '/api/subscriptions'
*/
subscribe140d629c2f7d3233b5ec8d322e24dd7b.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: subscribe140d629c2f7d3233b5ec8d322e24dd7b.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::subscribe
* @see app/Http/Controllers/SubscriptionController.php:52
* @route '/api/subscriptions'
*/
const subscribe140d629c2f7d3233b5ec8d322e24dd7bForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: subscribe140d629c2f7d3233b5ec8d322e24dd7b.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::subscribe
* @see app/Http/Controllers/SubscriptionController.php:52
* @route '/api/subscriptions'
*/
subscribe140d629c2f7d3233b5ec8d322e24dd7bForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: subscribe140d629c2f7d3233b5ec8d322e24dd7b.url(options),
    method: 'post',
})

subscribe140d629c2f7d3233b5ec8d322e24dd7b.form = subscribe140d629c2f7d3233b5ec8d322e24dd7bForm
/**
* @see \App\Http\Controllers\SubscriptionController::subscribe
* @see app/Http/Controllers/SubscriptionController.php:52
* @route '/subscriptions'
*/
const subscribe0a8203b045524b27442e2849357c73e7 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: subscribe0a8203b045524b27442e2849357c73e7.url(options),
    method: 'post',
})

subscribe0a8203b045524b27442e2849357c73e7.definition = {
    methods: ["post"],
    url: '/subscriptions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::subscribe
* @see app/Http/Controllers/SubscriptionController.php:52
* @route '/subscriptions'
*/
subscribe0a8203b045524b27442e2849357c73e7.url = (options?: RouteQueryOptions) => {
    return subscribe0a8203b045524b27442e2849357c73e7.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::subscribe
* @see app/Http/Controllers/SubscriptionController.php:52
* @route '/subscriptions'
*/
subscribe0a8203b045524b27442e2849357c73e7.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: subscribe0a8203b045524b27442e2849357c73e7.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::subscribe
* @see app/Http/Controllers/SubscriptionController.php:52
* @route '/subscriptions'
*/
const subscribe0a8203b045524b27442e2849357c73e7Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: subscribe0a8203b045524b27442e2849357c73e7.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::subscribe
* @see app/Http/Controllers/SubscriptionController.php:52
* @route '/subscriptions'
*/
subscribe0a8203b045524b27442e2849357c73e7Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: subscribe0a8203b045524b27442e2849357c73e7.url(options),
    method: 'post',
})

subscribe0a8203b045524b27442e2849357c73e7.form = subscribe0a8203b045524b27442e2849357c73e7Form

export const subscribe = {
    '/api/subscriptions': subscribe140d629c2f7d3233b5ec8d322e24dd7b,
    '/subscriptions': subscribe0a8203b045524b27442e2849357c73e7,
}

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/api/subscriptions'
*/
const getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.url(options),
    method: 'get',
})

getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.definition = {
    methods: ["get","head"],
    url: '/api/subscriptions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/api/subscriptions'
*/
getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.url = (options?: RouteQueryOptions) => {
    return getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/api/subscriptions'
*/
getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/api/subscriptions'
*/
getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/api/subscriptions'
*/
const getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7bForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/api/subscriptions'
*/
getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7bForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/api/subscriptions'
*/
getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7bForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b.form = getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7bForm
/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/subscriptions'
*/
const getUserSubscriptions0a8203b045524b27442e2849357c73e7 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserSubscriptions0a8203b045524b27442e2849357c73e7.url(options),
    method: 'get',
})

getUserSubscriptions0a8203b045524b27442e2849357c73e7.definition = {
    methods: ["get","head"],
    url: '/subscriptions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/subscriptions'
*/
getUserSubscriptions0a8203b045524b27442e2849357c73e7.url = (options?: RouteQueryOptions) => {
    return getUserSubscriptions0a8203b045524b27442e2849357c73e7.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/subscriptions'
*/
getUserSubscriptions0a8203b045524b27442e2849357c73e7.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserSubscriptions0a8203b045524b27442e2849357c73e7.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/subscriptions'
*/
getUserSubscriptions0a8203b045524b27442e2849357c73e7.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getUserSubscriptions0a8203b045524b27442e2849357c73e7.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/subscriptions'
*/
const getUserSubscriptions0a8203b045524b27442e2849357c73e7Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSubscriptions0a8203b045524b27442e2849357c73e7.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/subscriptions'
*/
getUserSubscriptions0a8203b045524b27442e2849357c73e7Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSubscriptions0a8203b045524b27442e2849357c73e7.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::getUserSubscriptions
* @see app/Http/Controllers/SubscriptionController.php:141
* @route '/subscriptions'
*/
getUserSubscriptions0a8203b045524b27442e2849357c73e7Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSubscriptions0a8203b045524b27442e2849357c73e7.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getUserSubscriptions0a8203b045524b27442e2849357c73e7.form = getUserSubscriptions0a8203b045524b27442e2849357c73e7Form

export const getUserSubscriptions = {
    '/api/subscriptions': getUserSubscriptions140d629c2f7d3233b5ec8d322e24dd7b,
    '/subscriptions': getUserSubscriptions0a8203b045524b27442e2849357c73e7,
}

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/api/subscriptions/{id}'
*/
const showf86f97b5091f9723d0a25db4535ee476 = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showf86f97b5091f9723d0a25db4535ee476.url(args, options),
    method: 'get',
})

showf86f97b5091f9723d0a25db4535ee476.definition = {
    methods: ["get","head"],
    url: '/api/subscriptions/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/api/subscriptions/{id}'
*/
showf86f97b5091f9723d0a25db4535ee476.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return showf86f97b5091f9723d0a25db4535ee476.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/api/subscriptions/{id}'
*/
showf86f97b5091f9723d0a25db4535ee476.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showf86f97b5091f9723d0a25db4535ee476.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/api/subscriptions/{id}'
*/
showf86f97b5091f9723d0a25db4535ee476.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showf86f97b5091f9723d0a25db4535ee476.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/api/subscriptions/{id}'
*/
const showf86f97b5091f9723d0a25db4535ee476Form = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showf86f97b5091f9723d0a25db4535ee476.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/api/subscriptions/{id}'
*/
showf86f97b5091f9723d0a25db4535ee476Form.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showf86f97b5091f9723d0a25db4535ee476.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/api/subscriptions/{id}'
*/
showf86f97b5091f9723d0a25db4535ee476Form.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showf86f97b5091f9723d0a25db4535ee476.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showf86f97b5091f9723d0a25db4535ee476.form = showf86f97b5091f9723d0a25db4535ee476Form
/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/subscriptions/{id}'
*/
const show7f5ecd93d9ac925ac90f078dbae6280c = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show7f5ecd93d9ac925ac90f078dbae6280c.url(args, options),
    method: 'get',
})

show7f5ecd93d9ac925ac90f078dbae6280c.definition = {
    methods: ["get","head"],
    url: '/subscriptions/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/subscriptions/{id}'
*/
show7f5ecd93d9ac925ac90f078dbae6280c.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return show7f5ecd93d9ac925ac90f078dbae6280c.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/subscriptions/{id}'
*/
show7f5ecd93d9ac925ac90f078dbae6280c.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show7f5ecd93d9ac925ac90f078dbae6280c.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/subscriptions/{id}'
*/
show7f5ecd93d9ac925ac90f078dbae6280c.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show7f5ecd93d9ac925ac90f078dbae6280c.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/subscriptions/{id}'
*/
const show7f5ecd93d9ac925ac90f078dbae6280cForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show7f5ecd93d9ac925ac90f078dbae6280c.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/subscriptions/{id}'
*/
show7f5ecd93d9ac925ac90f078dbae6280cForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show7f5ecd93d9ac925ac90f078dbae6280c.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SubscriptionController::show
* @see app/Http/Controllers/SubscriptionController.php:167
* @route '/subscriptions/{id}'
*/
show7f5ecd93d9ac925ac90f078dbae6280cForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show7f5ecd93d9ac925ac90f078dbae6280c.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show7f5ecd93d9ac925ac90f078dbae6280c.form = show7f5ecd93d9ac925ac90f078dbae6280cForm

export const show = {
    '/api/subscriptions/{id}': showf86f97b5091f9723d0a25db4535ee476,
    '/subscriptions/{id}': show7f5ecd93d9ac925ac90f078dbae6280c,
}

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
* @see app/Http/Controllers/SubscriptionController.php:196
* @route '/api/subscriptions/{id}/cancel'
*/
const cancel0a7e83a6154940f5034752c545928c9e = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel0a7e83a6154940f5034752c545928c9e.url(args, options),
    method: 'post',
})

cancel0a7e83a6154940f5034752c545928c9e.definition = {
    methods: ["post"],
    url: '/api/subscriptions/{id}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
* @see app/Http/Controllers/SubscriptionController.php:196
* @route '/api/subscriptions/{id}/cancel'
*/
cancel0a7e83a6154940f5034752c545928c9e.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return cancel0a7e83a6154940f5034752c545928c9e.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
* @see app/Http/Controllers/SubscriptionController.php:196
* @route '/api/subscriptions/{id}/cancel'
*/
cancel0a7e83a6154940f5034752c545928c9e.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel0a7e83a6154940f5034752c545928c9e.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
* @see app/Http/Controllers/SubscriptionController.php:196
* @route '/api/subscriptions/{id}/cancel'
*/
const cancel0a7e83a6154940f5034752c545928c9eForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel0a7e83a6154940f5034752c545928c9e.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
* @see app/Http/Controllers/SubscriptionController.php:196
* @route '/api/subscriptions/{id}/cancel'
*/
cancel0a7e83a6154940f5034752c545928c9eForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel0a7e83a6154940f5034752c545928c9e.url(args, options),
    method: 'post',
})

cancel0a7e83a6154940f5034752c545928c9e.form = cancel0a7e83a6154940f5034752c545928c9eForm
/**
* @see \App\Http\Controllers\SubscriptionController::cancel
* @see app/Http/Controllers/SubscriptionController.php:196
* @route '/subscriptions/{id}/cancel'
*/
const cancelda73ec7d72222ed5acf8f4444d17d76a = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancelda73ec7d72222ed5acf8f4444d17d76a.url(args, options),
    method: 'post',
})

cancelda73ec7d72222ed5acf8f4444d17d76a.definition = {
    methods: ["post"],
    url: '/subscriptions/{id}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
* @see app/Http/Controllers/SubscriptionController.php:196
* @route '/subscriptions/{id}/cancel'
*/
cancelda73ec7d72222ed5acf8f4444d17d76a.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return cancelda73ec7d72222ed5acf8f4444d17d76a.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
* @see app/Http/Controllers/SubscriptionController.php:196
* @route '/subscriptions/{id}/cancel'
*/
cancelda73ec7d72222ed5acf8f4444d17d76a.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancelda73ec7d72222ed5acf8f4444d17d76a.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
* @see app/Http/Controllers/SubscriptionController.php:196
* @route '/subscriptions/{id}/cancel'
*/
const cancelda73ec7d72222ed5acf8f4444d17d76aForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancelda73ec7d72222ed5acf8f4444d17d76a.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
* @see app/Http/Controllers/SubscriptionController.php:196
* @route '/subscriptions/{id}/cancel'
*/
cancelda73ec7d72222ed5acf8f4444d17d76aForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancelda73ec7d72222ed5acf8f4444d17d76a.url(args, options),
    method: 'post',
})

cancelda73ec7d72222ed5acf8f4444d17d76a.form = cancelda73ec7d72222ed5acf8f4444d17d76aForm

export const cancel = {
    '/api/subscriptions/{id}/cancel': cancel0a7e83a6154940f5034752c545928c9e,
    '/subscriptions/{id}/cancel': cancelda73ec7d72222ed5acf8f4444d17d76a,
}

/**
* @see \App\Http\Controllers\SubscriptionController::changeTier
* @see app/Http/Controllers/SubscriptionController.php:242
* @route '/api/subscriptions/{id}/change-tier'
*/
const changeTier0db8b7e6b2c0e28ca35f622a16d44273 = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: changeTier0db8b7e6b2c0e28ca35f622a16d44273.url(args, options),
    method: 'post',
})

changeTier0db8b7e6b2c0e28ca35f622a16d44273.definition = {
    methods: ["post"],
    url: '/api/subscriptions/{id}/change-tier',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::changeTier
* @see app/Http/Controllers/SubscriptionController.php:242
* @route '/api/subscriptions/{id}/change-tier'
*/
changeTier0db8b7e6b2c0e28ca35f622a16d44273.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return changeTier0db8b7e6b2c0e28ca35f622a16d44273.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::changeTier
* @see app/Http/Controllers/SubscriptionController.php:242
* @route '/api/subscriptions/{id}/change-tier'
*/
changeTier0db8b7e6b2c0e28ca35f622a16d44273.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: changeTier0db8b7e6b2c0e28ca35f622a16d44273.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::changeTier
* @see app/Http/Controllers/SubscriptionController.php:242
* @route '/api/subscriptions/{id}/change-tier'
*/
const changeTier0db8b7e6b2c0e28ca35f622a16d44273Form = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: changeTier0db8b7e6b2c0e28ca35f622a16d44273.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::changeTier
* @see app/Http/Controllers/SubscriptionController.php:242
* @route '/api/subscriptions/{id}/change-tier'
*/
changeTier0db8b7e6b2c0e28ca35f622a16d44273Form.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: changeTier0db8b7e6b2c0e28ca35f622a16d44273.url(args, options),
    method: 'post',
})

changeTier0db8b7e6b2c0e28ca35f622a16d44273.form = changeTier0db8b7e6b2c0e28ca35f622a16d44273Form
/**
* @see \App\Http\Controllers\SubscriptionController::changeTier
* @see app/Http/Controllers/SubscriptionController.php:242
* @route '/subscriptions/{id}/change-tier'
*/
const changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cb = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cb.url(args, options),
    method: 'post',
})

changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cb.definition = {
    methods: ["post"],
    url: '/subscriptions/{id}/change-tier',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::changeTier
* @see app/Http/Controllers/SubscriptionController.php:242
* @route '/subscriptions/{id}/change-tier'
*/
changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cb.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cb.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::changeTier
* @see app/Http/Controllers/SubscriptionController.php:242
* @route '/subscriptions/{id}/change-tier'
*/
changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cb.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cb.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::changeTier
* @see app/Http/Controllers/SubscriptionController.php:242
* @route '/subscriptions/{id}/change-tier'
*/
const changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cbForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cb.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SubscriptionController::changeTier
* @see app/Http/Controllers/SubscriptionController.php:242
* @route '/subscriptions/{id}/change-tier'
*/
changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cbForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cb.url(args, options),
    method: 'post',
})

changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cb.form = changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cbForm

export const changeTier = {
    '/api/subscriptions/{id}/change-tier': changeTier0db8b7e6b2c0e28ca35f622a16d44273,
    '/subscriptions/{id}/change-tier': changeTier32bbb0f1b6a23d1880fb1aedaa1ac6cb,
}

const SubscriptionController = { getTiers, subscribe, getUserSubscriptions, show, cancel, changeTier }

export default SubscriptionController