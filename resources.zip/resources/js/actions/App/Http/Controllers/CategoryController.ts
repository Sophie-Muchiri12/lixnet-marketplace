import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/api/categories'
*/
const index029b5c5da98b03e3d218bf29682b5f92 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index029b5c5da98b03e3d218bf29682b5f92.url(options),
    method: 'get',
})

index029b5c5da98b03e3d218bf29682b5f92.definition = {
    methods: ["get","head"],
    url: '/api/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/api/categories'
*/
index029b5c5da98b03e3d218bf29682b5f92.url = (options?: RouteQueryOptions) => {
    return index029b5c5da98b03e3d218bf29682b5f92.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/api/categories'
*/
index029b5c5da98b03e3d218bf29682b5f92.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index029b5c5da98b03e3d218bf29682b5f92.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/api/categories'
*/
index029b5c5da98b03e3d218bf29682b5f92.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index029b5c5da98b03e3d218bf29682b5f92.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/api/categories'
*/
const index029b5c5da98b03e3d218bf29682b5f92Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index029b5c5da98b03e3d218bf29682b5f92.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/api/categories'
*/
index029b5c5da98b03e3d218bf29682b5f92Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index029b5c5da98b03e3d218bf29682b5f92.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/api/categories'
*/
index029b5c5da98b03e3d218bf29682b5f92Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index029b5c5da98b03e3d218bf29682b5f92.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index029b5c5da98b03e3d218bf29682b5f92.form = index029b5c5da98b03e3d218bf29682b5f92Form
/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/categories'
*/
const index7a4f8d9d0be39757f6a1352cf8f1ab45 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index7a4f8d9d0be39757f6a1352cf8f1ab45.url(options),
    method: 'get',
})

index7a4f8d9d0be39757f6a1352cf8f1ab45.definition = {
    methods: ["get","head"],
    url: '/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/categories'
*/
index7a4f8d9d0be39757f6a1352cf8f1ab45.url = (options?: RouteQueryOptions) => {
    return index7a4f8d9d0be39757f6a1352cf8f1ab45.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/categories'
*/
index7a4f8d9d0be39757f6a1352cf8f1ab45.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index7a4f8d9d0be39757f6a1352cf8f1ab45.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/categories'
*/
index7a4f8d9d0be39757f6a1352cf8f1ab45.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index7a4f8d9d0be39757f6a1352cf8f1ab45.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/categories'
*/
const index7a4f8d9d0be39757f6a1352cf8f1ab45Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index7a4f8d9d0be39757f6a1352cf8f1ab45.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/categories'
*/
index7a4f8d9d0be39757f6a1352cf8f1ab45Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index7a4f8d9d0be39757f6a1352cf8f1ab45.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::index
* @see app/Http/Controllers/CategoryController.php:16
* @route '/categories'
*/
index7a4f8d9d0be39757f6a1352cf8f1ab45Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index7a4f8d9d0be39757f6a1352cf8f1ab45.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index7a4f8d9d0be39757f6a1352cf8f1ab45.form = index7a4f8d9d0be39757f6a1352cf8f1ab45Form

export const index = {
    '/api/categories': index029b5c5da98b03e3d218bf29682b5f92,
    '/categories': index7a4f8d9d0be39757f6a1352cf8f1ab45,
}

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/api/categories/{category}'
*/
const showc0c7fcfe8d567c18a64c7ac90fd7ac11 = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showc0c7fcfe8d567c18a64c7ac90fd7ac11.url(args, options),
    method: 'get',
})

showc0c7fcfe8d567c18a64c7ac90fd7ac11.definition = {
    methods: ["get","head"],
    url: '/api/categories/{category}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/api/categories/{category}'
*/
showc0c7fcfe8d567c18a64c7ac90fd7ac11.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { category: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: typeof args.category === 'object'
        ? args.category.id
        : args.category,
    }

    return showc0c7fcfe8d567c18a64c7ac90fd7ac11.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/api/categories/{category}'
*/
showc0c7fcfe8d567c18a64c7ac90fd7ac11.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showc0c7fcfe8d567c18a64c7ac90fd7ac11.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/api/categories/{category}'
*/
showc0c7fcfe8d567c18a64c7ac90fd7ac11.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showc0c7fcfe8d567c18a64c7ac90fd7ac11.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/api/categories/{category}'
*/
const showc0c7fcfe8d567c18a64c7ac90fd7ac11Form = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showc0c7fcfe8d567c18a64c7ac90fd7ac11.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/api/categories/{category}'
*/
showc0c7fcfe8d567c18a64c7ac90fd7ac11Form.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showc0c7fcfe8d567c18a64c7ac90fd7ac11.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/api/categories/{category}'
*/
showc0c7fcfe8d567c18a64c7ac90fd7ac11Form.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showc0c7fcfe8d567c18a64c7ac90fd7ac11.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showc0c7fcfe8d567c18a64c7ac90fd7ac11.form = showc0c7fcfe8d567c18a64c7ac90fd7ac11Form
/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/categories/{category}'
*/
const show932602c99fedbd393af66fd0b1a6c2ea = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show932602c99fedbd393af66fd0b1a6c2ea.url(args, options),
    method: 'get',
})

show932602c99fedbd393af66fd0b1a6c2ea.definition = {
    methods: ["get","head"],
    url: '/categories/{category}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/categories/{category}'
*/
show932602c99fedbd393af66fd0b1a6c2ea.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { category: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: typeof args.category === 'object'
        ? args.category.id
        : args.category,
    }

    return show932602c99fedbd393af66fd0b1a6c2ea.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/categories/{category}'
*/
show932602c99fedbd393af66fd0b1a6c2ea.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show932602c99fedbd393af66fd0b1a6c2ea.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/categories/{category}'
*/
show932602c99fedbd393af66fd0b1a6c2ea.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show932602c99fedbd393af66fd0b1a6c2ea.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/categories/{category}'
*/
const show932602c99fedbd393af66fd0b1a6c2eaForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show932602c99fedbd393af66fd0b1a6c2ea.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/categories/{category}'
*/
show932602c99fedbd393af66fd0b1a6c2eaForm.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show932602c99fedbd393af66fd0b1a6c2ea.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::show
* @see app/Http/Controllers/CategoryController.php:40
* @route '/categories/{category}'
*/
show932602c99fedbd393af66fd0b1a6c2eaForm.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show932602c99fedbd393af66fd0b1a6c2ea.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show932602c99fedbd393af66fd0b1a6c2ea.form = show932602c99fedbd393af66fd0b1a6c2eaForm

export const show = {
    '/api/categories/{category}': showc0c7fcfe8d567c18a64c7ac90fd7ac11,
    '/categories/{category}': show932602c99fedbd393af66fd0b1a6c2ea,
}

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/api/categories/slug/{slug}'
*/
const showBySlugb9616007d50fb5142e21019ba99959df = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showBySlugb9616007d50fb5142e21019ba99959df.url(args, options),
    method: 'get',
})

showBySlugb9616007d50fb5142e21019ba99959df.definition = {
    methods: ["get","head"],
    url: '/api/categories/slug/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/api/categories/slug/{slug}'
*/
showBySlugb9616007d50fb5142e21019ba99959df.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return showBySlugb9616007d50fb5142e21019ba99959df.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/api/categories/slug/{slug}'
*/
showBySlugb9616007d50fb5142e21019ba99959df.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showBySlugb9616007d50fb5142e21019ba99959df.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/api/categories/slug/{slug}'
*/
showBySlugb9616007d50fb5142e21019ba99959df.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showBySlugb9616007d50fb5142e21019ba99959df.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/api/categories/slug/{slug}'
*/
const showBySlugb9616007d50fb5142e21019ba99959dfForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showBySlugb9616007d50fb5142e21019ba99959df.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/api/categories/slug/{slug}'
*/
showBySlugb9616007d50fb5142e21019ba99959dfForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showBySlugb9616007d50fb5142e21019ba99959df.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/api/categories/slug/{slug}'
*/
showBySlugb9616007d50fb5142e21019ba99959dfForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showBySlugb9616007d50fb5142e21019ba99959df.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showBySlugb9616007d50fb5142e21019ba99959df.form = showBySlugb9616007d50fb5142e21019ba99959dfForm
/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/categories/slug/{slug}'
*/
const showBySlugc7ad453f070227c9aa45ab863ab3bcf6 = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showBySlugc7ad453f070227c9aa45ab863ab3bcf6.url(args, options),
    method: 'get',
})

showBySlugc7ad453f070227c9aa45ab863ab3bcf6.definition = {
    methods: ["get","head"],
    url: '/categories/slug/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/categories/slug/{slug}'
*/
showBySlugc7ad453f070227c9aa45ab863ab3bcf6.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return showBySlugc7ad453f070227c9aa45ab863ab3bcf6.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/categories/slug/{slug}'
*/
showBySlugc7ad453f070227c9aa45ab863ab3bcf6.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showBySlugc7ad453f070227c9aa45ab863ab3bcf6.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/categories/slug/{slug}'
*/
showBySlugc7ad453f070227c9aa45ab863ab3bcf6.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showBySlugc7ad453f070227c9aa45ab863ab3bcf6.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/categories/slug/{slug}'
*/
const showBySlugc7ad453f070227c9aa45ab863ab3bcf6Form = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showBySlugc7ad453f070227c9aa45ab863ab3bcf6.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/categories/slug/{slug}'
*/
showBySlugc7ad453f070227c9aa45ab863ab3bcf6Form.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showBySlugc7ad453f070227c9aa45ab863ab3bcf6.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CategoryController::showBySlug
* @see app/Http/Controllers/CategoryController.php:64
* @route '/categories/slug/{slug}'
*/
showBySlugc7ad453f070227c9aa45ab863ab3bcf6Form.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showBySlugc7ad453f070227c9aa45ab863ab3bcf6.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showBySlugc7ad453f070227c9aa45ab863ab3bcf6.form = showBySlugc7ad453f070227c9aa45ab863ab3bcf6Form

export const showBySlug = {
    '/api/categories/slug/{slug}': showBySlugb9616007d50fb5142e21019ba99959df,
    '/categories/slug/{slug}': showBySlugc7ad453f070227c9aa45ab863ab3bcf6,
}

/**
* @see \App\Http\Controllers\CategoryController::store
* @see app/Http/Controllers/CategoryController.php:97
* @route '/api/admin/categories'
*/
const store771dad12bbe1adde455d808763b2e535 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store771dad12bbe1adde455d808763b2e535.url(options),
    method: 'post',
})

store771dad12bbe1adde455d808763b2e535.definition = {
    methods: ["post"],
    url: '/api/admin/categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CategoryController::store
* @see app/Http/Controllers/CategoryController.php:97
* @route '/api/admin/categories'
*/
store771dad12bbe1adde455d808763b2e535.url = (options?: RouteQueryOptions) => {
    return store771dad12bbe1adde455d808763b2e535.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::store
* @see app/Http/Controllers/CategoryController.php:97
* @route '/api/admin/categories'
*/
store771dad12bbe1adde455d808763b2e535.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store771dad12bbe1adde455d808763b2e535.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CategoryController::store
* @see app/Http/Controllers/CategoryController.php:97
* @route '/api/admin/categories'
*/
const store771dad12bbe1adde455d808763b2e535Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store771dad12bbe1adde455d808763b2e535.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CategoryController::store
* @see app/Http/Controllers/CategoryController.php:97
* @route '/api/admin/categories'
*/
store771dad12bbe1adde455d808763b2e535Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store771dad12bbe1adde455d808763b2e535.url(options),
    method: 'post',
})

store771dad12bbe1adde455d808763b2e535.form = store771dad12bbe1adde455d808763b2e535Form
/**
* @see \App\Http\Controllers\CategoryController::store
* @see app/Http/Controllers/CategoryController.php:97
* @route '/admin/categories'
*/
const store377c0d45be70873e0ecaf350cc14e1cf = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store377c0d45be70873e0ecaf350cc14e1cf.url(options),
    method: 'post',
})

store377c0d45be70873e0ecaf350cc14e1cf.definition = {
    methods: ["post"],
    url: '/admin/categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CategoryController::store
* @see app/Http/Controllers/CategoryController.php:97
* @route '/admin/categories'
*/
store377c0d45be70873e0ecaf350cc14e1cf.url = (options?: RouteQueryOptions) => {
    return store377c0d45be70873e0ecaf350cc14e1cf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::store
* @see app/Http/Controllers/CategoryController.php:97
* @route '/admin/categories'
*/
store377c0d45be70873e0ecaf350cc14e1cf.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store377c0d45be70873e0ecaf350cc14e1cf.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CategoryController::store
* @see app/Http/Controllers/CategoryController.php:97
* @route '/admin/categories'
*/
const store377c0d45be70873e0ecaf350cc14e1cfForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store377c0d45be70873e0ecaf350cc14e1cf.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CategoryController::store
* @see app/Http/Controllers/CategoryController.php:97
* @route '/admin/categories'
*/
store377c0d45be70873e0ecaf350cc14e1cfForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store377c0d45be70873e0ecaf350cc14e1cf.url(options),
    method: 'post',
})

store377c0d45be70873e0ecaf350cc14e1cf.form = store377c0d45be70873e0ecaf350cc14e1cfForm

export const store = {
    '/api/admin/categories': store771dad12bbe1adde455d808763b2e535,
    '/admin/categories': store377c0d45be70873e0ecaf350cc14e1cf,
}

/**
* @see \App\Http\Controllers\CategoryController::update
* @see app/Http/Controllers/CategoryController.php:124
* @route '/api/admin/categories/{category}'
*/
const update220222cb39a1b83d7b200cf50af0c6b3 = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update220222cb39a1b83d7b200cf50af0c6b3.url(args, options),
    method: 'put',
})

update220222cb39a1b83d7b200cf50af0c6b3.definition = {
    methods: ["put"],
    url: '/api/admin/categories/{category}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CategoryController::update
* @see app/Http/Controllers/CategoryController.php:124
* @route '/api/admin/categories/{category}'
*/
update220222cb39a1b83d7b200cf50af0c6b3.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { category: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: typeof args.category === 'object'
        ? args.category.id
        : args.category,
    }

    return update220222cb39a1b83d7b200cf50af0c6b3.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::update
* @see app/Http/Controllers/CategoryController.php:124
* @route '/api/admin/categories/{category}'
*/
update220222cb39a1b83d7b200cf50af0c6b3.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update220222cb39a1b83d7b200cf50af0c6b3.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\CategoryController::update
* @see app/Http/Controllers/CategoryController.php:124
* @route '/api/admin/categories/{category}'
*/
const update220222cb39a1b83d7b200cf50af0c6b3Form = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update220222cb39a1b83d7b200cf50af0c6b3.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CategoryController::update
* @see app/Http/Controllers/CategoryController.php:124
* @route '/api/admin/categories/{category}'
*/
update220222cb39a1b83d7b200cf50af0c6b3Form.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update220222cb39a1b83d7b200cf50af0c6b3.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update220222cb39a1b83d7b200cf50af0c6b3.form = update220222cb39a1b83d7b200cf50af0c6b3Form
/**
* @see \App\Http\Controllers\CategoryController::update
* @see app/Http/Controllers/CategoryController.php:124
* @route '/admin/categories/{category}'
*/
const updated3574d41649b4dd208d031db42e0efd4 = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updated3574d41649b4dd208d031db42e0efd4.url(args, options),
    method: 'put',
})

updated3574d41649b4dd208d031db42e0efd4.definition = {
    methods: ["put"],
    url: '/admin/categories/{category}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CategoryController::update
* @see app/Http/Controllers/CategoryController.php:124
* @route '/admin/categories/{category}'
*/
updated3574d41649b4dd208d031db42e0efd4.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { category: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: typeof args.category === 'object'
        ? args.category.id
        : args.category,
    }

    return updated3574d41649b4dd208d031db42e0efd4.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::update
* @see app/Http/Controllers/CategoryController.php:124
* @route '/admin/categories/{category}'
*/
updated3574d41649b4dd208d031db42e0efd4.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updated3574d41649b4dd208d031db42e0efd4.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\CategoryController::update
* @see app/Http/Controllers/CategoryController.php:124
* @route '/admin/categories/{category}'
*/
const updated3574d41649b4dd208d031db42e0efd4Form = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updated3574d41649b4dd208d031db42e0efd4.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CategoryController::update
* @see app/Http/Controllers/CategoryController.php:124
* @route '/admin/categories/{category}'
*/
updated3574d41649b4dd208d031db42e0efd4Form.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updated3574d41649b4dd208d031db42e0efd4.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updated3574d41649b4dd208d031db42e0efd4.form = updated3574d41649b4dd208d031db42e0efd4Form

export const update = {
    '/api/admin/categories/{category}': update220222cb39a1b83d7b200cf50af0c6b3,
    '/admin/categories/{category}': updated3574d41649b4dd208d031db42e0efd4,
}

/**
* @see \App\Http\Controllers\CategoryController::destroy
* @see app/Http/Controllers/CategoryController.php:151
* @route '/api/admin/categories/{category}'
*/
const destroy220222cb39a1b83d7b200cf50af0c6b3 = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy220222cb39a1b83d7b200cf50af0c6b3.url(args, options),
    method: 'delete',
})

destroy220222cb39a1b83d7b200cf50af0c6b3.definition = {
    methods: ["delete"],
    url: '/api/admin/categories/{category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CategoryController::destroy
* @see app/Http/Controllers/CategoryController.php:151
* @route '/api/admin/categories/{category}'
*/
destroy220222cb39a1b83d7b200cf50af0c6b3.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { category: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: typeof args.category === 'object'
        ? args.category.id
        : args.category,
    }

    return destroy220222cb39a1b83d7b200cf50af0c6b3.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::destroy
* @see app/Http/Controllers/CategoryController.php:151
* @route '/api/admin/categories/{category}'
*/
destroy220222cb39a1b83d7b200cf50af0c6b3.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy220222cb39a1b83d7b200cf50af0c6b3.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CategoryController::destroy
* @see app/Http/Controllers/CategoryController.php:151
* @route '/api/admin/categories/{category}'
*/
const destroy220222cb39a1b83d7b200cf50af0c6b3Form = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy220222cb39a1b83d7b200cf50af0c6b3.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CategoryController::destroy
* @see app/Http/Controllers/CategoryController.php:151
* @route '/api/admin/categories/{category}'
*/
destroy220222cb39a1b83d7b200cf50af0c6b3Form.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy220222cb39a1b83d7b200cf50af0c6b3.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy220222cb39a1b83d7b200cf50af0c6b3.form = destroy220222cb39a1b83d7b200cf50af0c6b3Form
/**
* @see \App\Http\Controllers\CategoryController::destroy
* @see app/Http/Controllers/CategoryController.php:151
* @route '/admin/categories/{category}'
*/
const destroyd3574d41649b4dd208d031db42e0efd4 = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyd3574d41649b4dd208d031db42e0efd4.url(args, options),
    method: 'delete',
})

destroyd3574d41649b4dd208d031db42e0efd4.definition = {
    methods: ["delete"],
    url: '/admin/categories/{category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CategoryController::destroy
* @see app/Http/Controllers/CategoryController.php:151
* @route '/admin/categories/{category}'
*/
destroyd3574d41649b4dd208d031db42e0efd4.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { category: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: typeof args.category === 'object'
        ? args.category.id
        : args.category,
    }

    return destroyd3574d41649b4dd208d031db42e0efd4.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::destroy
* @see app/Http/Controllers/CategoryController.php:151
* @route '/admin/categories/{category}'
*/
destroyd3574d41649b4dd208d031db42e0efd4.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyd3574d41649b4dd208d031db42e0efd4.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CategoryController::destroy
* @see app/Http/Controllers/CategoryController.php:151
* @route '/admin/categories/{category}'
*/
const destroyd3574d41649b4dd208d031db42e0efd4Form = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyd3574d41649b4dd208d031db42e0efd4.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CategoryController::destroy
* @see app/Http/Controllers/CategoryController.php:151
* @route '/admin/categories/{category}'
*/
destroyd3574d41649b4dd208d031db42e0efd4Form.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyd3574d41649b4dd208d031db42e0efd4.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyd3574d41649b4dd208d031db42e0efd4.form = destroyd3574d41649b4dd208d031db42e0efd4Form

export const destroy = {
    '/api/admin/categories/{category}': destroy220222cb39a1b83d7b200cf50af0c6b3,
    '/admin/categories/{category}': destroyd3574d41649b4dd208d031db42e0efd4,
}

const CategoryController = { index, show, showBySlug, store, update, destroy }

export default CategoryController