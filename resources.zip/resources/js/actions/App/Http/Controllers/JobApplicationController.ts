import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\JobApplicationController::store
* @see app/Http/Controllers/JobApplicationController.php:28
* @route '/api/job-applications'
*/
const store235c73bd5ed8067654fe5c3b1ea793c8 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store235c73bd5ed8067654fe5c3b1ea793c8.url(options),
    method: 'post',
})

store235c73bd5ed8067654fe5c3b1ea793c8.definition = {
    methods: ["post"],
    url: '/api/job-applications',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\JobApplicationController::store
* @see app/Http/Controllers/JobApplicationController.php:28
* @route '/api/job-applications'
*/
store235c73bd5ed8067654fe5c3b1ea793c8.url = (options?: RouteQueryOptions) => {
    return store235c73bd5ed8067654fe5c3b1ea793c8.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::store
* @see app/Http/Controllers/JobApplicationController.php:28
* @route '/api/job-applications'
*/
store235c73bd5ed8067654fe5c3b1ea793c8.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store235c73bd5ed8067654fe5c3b1ea793c8.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobApplicationController::store
* @see app/Http/Controllers/JobApplicationController.php:28
* @route '/api/job-applications'
*/
const store235c73bd5ed8067654fe5c3b1ea793c8Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store235c73bd5ed8067654fe5c3b1ea793c8.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobApplicationController::store
* @see app/Http/Controllers/JobApplicationController.php:28
* @route '/api/job-applications'
*/
store235c73bd5ed8067654fe5c3b1ea793c8Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store235c73bd5ed8067654fe5c3b1ea793c8.url(options),
    method: 'post',
})

store235c73bd5ed8067654fe5c3b1ea793c8.form = store235c73bd5ed8067654fe5c3b1ea793c8Form
/**
* @see \App\Http\Controllers\JobApplicationController::store
* @see app/Http/Controllers/JobApplicationController.php:28
* @route '/job-applications'
*/
const storee121dcfd6ca7260498a7093b022aa53d = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storee121dcfd6ca7260498a7093b022aa53d.url(options),
    method: 'post',
})

storee121dcfd6ca7260498a7093b022aa53d.definition = {
    methods: ["post"],
    url: '/job-applications',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\JobApplicationController::store
* @see app/Http/Controllers/JobApplicationController.php:28
* @route '/job-applications'
*/
storee121dcfd6ca7260498a7093b022aa53d.url = (options?: RouteQueryOptions) => {
    return storee121dcfd6ca7260498a7093b022aa53d.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::store
* @see app/Http/Controllers/JobApplicationController.php:28
* @route '/job-applications'
*/
storee121dcfd6ca7260498a7093b022aa53d.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storee121dcfd6ca7260498a7093b022aa53d.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobApplicationController::store
* @see app/Http/Controllers/JobApplicationController.php:28
* @route '/job-applications'
*/
const storee121dcfd6ca7260498a7093b022aa53dForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storee121dcfd6ca7260498a7093b022aa53d.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobApplicationController::store
* @see app/Http/Controllers/JobApplicationController.php:28
* @route '/job-applications'
*/
storee121dcfd6ca7260498a7093b022aa53dForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storee121dcfd6ca7260498a7093b022aa53d.url(options),
    method: 'post',
})

storee121dcfd6ca7260498a7093b022aa53d.form = storee121dcfd6ca7260498a7093b022aa53dForm

export const store = {
    '/api/job-applications': store235c73bd5ed8067654fe5c3b1ea793c8,
    '/job-applications': storee121dcfd6ca7260498a7093b022aa53d,
}

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/api/admin/job-applications'
*/
const index78ce58ce16a07aa7f90d6a24c968189d = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index78ce58ce16a07aa7f90d6a24c968189d.url(options),
    method: 'get',
})

index78ce58ce16a07aa7f90d6a24c968189d.definition = {
    methods: ["get","head"],
    url: '/api/admin/job-applications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/api/admin/job-applications'
*/
index78ce58ce16a07aa7f90d6a24c968189d.url = (options?: RouteQueryOptions) => {
    return index78ce58ce16a07aa7f90d6a24c968189d.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/api/admin/job-applications'
*/
index78ce58ce16a07aa7f90d6a24c968189d.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index78ce58ce16a07aa7f90d6a24c968189d.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/api/admin/job-applications'
*/
index78ce58ce16a07aa7f90d6a24c968189d.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index78ce58ce16a07aa7f90d6a24c968189d.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/api/admin/job-applications'
*/
const index78ce58ce16a07aa7f90d6a24c968189dForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index78ce58ce16a07aa7f90d6a24c968189d.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/api/admin/job-applications'
*/
index78ce58ce16a07aa7f90d6a24c968189dForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index78ce58ce16a07aa7f90d6a24c968189d.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/api/admin/job-applications'
*/
index78ce58ce16a07aa7f90d6a24c968189dForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index78ce58ce16a07aa7f90d6a24c968189d.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index78ce58ce16a07aa7f90d6a24c968189d.form = index78ce58ce16a07aa7f90d6a24c968189dForm
/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/admin/job-applications'
*/
const indexe485597e89f306df26ac0cf20c48b27c = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexe485597e89f306df26ac0cf20c48b27c.url(options),
    method: 'get',
})

indexe485597e89f306df26ac0cf20c48b27c.definition = {
    methods: ["get","head"],
    url: '/admin/job-applications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/admin/job-applications'
*/
indexe485597e89f306df26ac0cf20c48b27c.url = (options?: RouteQueryOptions) => {
    return indexe485597e89f306df26ac0cf20c48b27c.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/admin/job-applications'
*/
indexe485597e89f306df26ac0cf20c48b27c.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexe485597e89f306df26ac0cf20c48b27c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/admin/job-applications'
*/
indexe485597e89f306df26ac0cf20c48b27c.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexe485597e89f306df26ac0cf20c48b27c.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/admin/job-applications'
*/
const indexe485597e89f306df26ac0cf20c48b27cForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexe485597e89f306df26ac0cf20c48b27c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/admin/job-applications'
*/
indexe485597e89f306df26ac0cf20c48b27cForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexe485597e89f306df26ac0cf20c48b27c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::index
* @see app/Http/Controllers/JobApplicationController.php:16
* @route '/admin/job-applications'
*/
indexe485597e89f306df26ac0cf20c48b27cForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexe485597e89f306df26ac0cf20c48b27c.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexe485597e89f306df26ac0cf20c48b27c.form = indexe485597e89f306df26ac0cf20c48b27cForm

export const index = {
    '/api/admin/job-applications': index78ce58ce16a07aa7f90d6a24c968189d,
    '/admin/job-applications': indexe485597e89f306df26ac0cf20c48b27c,
}

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/api/admin/job-applications/{application}'
*/
const showf5411bf51d203da6a2f2163e361bc215 = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showf5411bf51d203da6a2f2163e361bc215.url(args, options),
    method: 'get',
})

showf5411bf51d203da6a2f2163e361bc215.definition = {
    methods: ["get","head"],
    url: '/api/admin/job-applications/{application}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/api/admin/job-applications/{application}'
*/
showf5411bf51d203da6a2f2163e361bc215.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return showf5411bf51d203da6a2f2163e361bc215.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/api/admin/job-applications/{application}'
*/
showf5411bf51d203da6a2f2163e361bc215.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showf5411bf51d203da6a2f2163e361bc215.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/api/admin/job-applications/{application}'
*/
showf5411bf51d203da6a2f2163e361bc215.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showf5411bf51d203da6a2f2163e361bc215.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/api/admin/job-applications/{application}'
*/
const showf5411bf51d203da6a2f2163e361bc215Form = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showf5411bf51d203da6a2f2163e361bc215.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/api/admin/job-applications/{application}'
*/
showf5411bf51d203da6a2f2163e361bc215Form.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showf5411bf51d203da6a2f2163e361bc215.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/api/admin/job-applications/{application}'
*/
showf5411bf51d203da6a2f2163e361bc215Form.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showf5411bf51d203da6a2f2163e361bc215.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showf5411bf51d203da6a2f2163e361bc215.form = showf5411bf51d203da6a2f2163e361bc215Form
/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/admin/job-applications/{application}'
*/
const show11eecb773ef489ef2de4c7d1ccc8ba82 = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show11eecb773ef489ef2de4c7d1ccc8ba82.url(args, options),
    method: 'get',
})

show11eecb773ef489ef2de4c7d1ccc8ba82.definition = {
    methods: ["get","head"],
    url: '/admin/job-applications/{application}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/admin/job-applications/{application}'
*/
show11eecb773ef489ef2de4c7d1ccc8ba82.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return show11eecb773ef489ef2de4c7d1ccc8ba82.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/admin/job-applications/{application}'
*/
show11eecb773ef489ef2de4c7d1ccc8ba82.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show11eecb773ef489ef2de4c7d1ccc8ba82.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/admin/job-applications/{application}'
*/
show11eecb773ef489ef2de4c7d1ccc8ba82.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show11eecb773ef489ef2de4c7d1ccc8ba82.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/admin/job-applications/{application}'
*/
const show11eecb773ef489ef2de4c7d1ccc8ba82Form = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show11eecb773ef489ef2de4c7d1ccc8ba82.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/admin/job-applications/{application}'
*/
show11eecb773ef489ef2de4c7d1ccc8ba82Form.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show11eecb773ef489ef2de4c7d1ccc8ba82.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::show
* @see app/Http/Controllers/JobApplicationController.php:67
* @route '/admin/job-applications/{application}'
*/
show11eecb773ef489ef2de4c7d1ccc8ba82Form.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show11eecb773ef489ef2de4c7d1ccc8ba82.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show11eecb773ef489ef2de4c7d1ccc8ba82.form = show11eecb773ef489ef2de4c7d1ccc8ba82Form

export const show = {
    '/api/admin/job-applications/{application}': showf5411bf51d203da6a2f2163e361bc215,
    '/admin/job-applications/{application}': show11eecb773ef489ef2de4c7d1ccc8ba82,
}

/**
* @see \App\Http\Controllers\JobApplicationController::update
* @see app/Http/Controllers/JobApplicationController.php:78
* @route '/api/admin/job-applications/{application}'
*/
const updatef5411bf51d203da6a2f2163e361bc215 = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatef5411bf51d203da6a2f2163e361bc215.url(args, options),
    method: 'put',
})

updatef5411bf51d203da6a2f2163e361bc215.definition = {
    methods: ["put"],
    url: '/api/admin/job-applications/{application}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\JobApplicationController::update
* @see app/Http/Controllers/JobApplicationController.php:78
* @route '/api/admin/job-applications/{application}'
*/
updatef5411bf51d203da6a2f2163e361bc215.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return updatef5411bf51d203da6a2f2163e361bc215.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::update
* @see app/Http/Controllers/JobApplicationController.php:78
* @route '/api/admin/job-applications/{application}'
*/
updatef5411bf51d203da6a2f2163e361bc215.put = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatef5411bf51d203da6a2f2163e361bc215.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\JobApplicationController::update
* @see app/Http/Controllers/JobApplicationController.php:78
* @route '/api/admin/job-applications/{application}'
*/
const updatef5411bf51d203da6a2f2163e361bc215Form = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updatef5411bf51d203da6a2f2163e361bc215.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobApplicationController::update
* @see app/Http/Controllers/JobApplicationController.php:78
* @route '/api/admin/job-applications/{application}'
*/
updatef5411bf51d203da6a2f2163e361bc215Form.put = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updatef5411bf51d203da6a2f2163e361bc215.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updatef5411bf51d203da6a2f2163e361bc215.form = updatef5411bf51d203da6a2f2163e361bc215Form
/**
* @see \App\Http\Controllers\JobApplicationController::update
* @see app/Http/Controllers/JobApplicationController.php:78
* @route '/admin/job-applications/{application}'
*/
const update11eecb773ef489ef2de4c7d1ccc8ba82 = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update11eecb773ef489ef2de4c7d1ccc8ba82.url(args, options),
    method: 'put',
})

update11eecb773ef489ef2de4c7d1ccc8ba82.definition = {
    methods: ["put"],
    url: '/admin/job-applications/{application}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\JobApplicationController::update
* @see app/Http/Controllers/JobApplicationController.php:78
* @route '/admin/job-applications/{application}'
*/
update11eecb773ef489ef2de4c7d1ccc8ba82.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return update11eecb773ef489ef2de4c7d1ccc8ba82.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::update
* @see app/Http/Controllers/JobApplicationController.php:78
* @route '/admin/job-applications/{application}'
*/
update11eecb773ef489ef2de4c7d1ccc8ba82.put = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update11eecb773ef489ef2de4c7d1ccc8ba82.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\JobApplicationController::update
* @see app/Http/Controllers/JobApplicationController.php:78
* @route '/admin/job-applications/{application}'
*/
const update11eecb773ef489ef2de4c7d1ccc8ba82Form = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update11eecb773ef489ef2de4c7d1ccc8ba82.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobApplicationController::update
* @see app/Http/Controllers/JobApplicationController.php:78
* @route '/admin/job-applications/{application}'
*/
update11eecb773ef489ef2de4c7d1ccc8ba82Form.put = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update11eecb773ef489ef2de4c7d1ccc8ba82.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update11eecb773ef489ef2de4c7d1ccc8ba82.form = update11eecb773ef489ef2de4c7d1ccc8ba82Form

export const update = {
    '/api/admin/job-applications/{application}': updatef5411bf51d203da6a2f2163e361bc215,
    '/admin/job-applications/{application}': update11eecb773ef489ef2de4c7d1ccc8ba82,
}

/**
* @see \App\Http\Controllers\JobApplicationController::destroy
* @see app/Http/Controllers/JobApplicationController.php:105
* @route '/api/admin/job-applications/{application}'
*/
const destroyf5411bf51d203da6a2f2163e361bc215 = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyf5411bf51d203da6a2f2163e361bc215.url(args, options),
    method: 'delete',
})

destroyf5411bf51d203da6a2f2163e361bc215.definition = {
    methods: ["delete"],
    url: '/api/admin/job-applications/{application}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\JobApplicationController::destroy
* @see app/Http/Controllers/JobApplicationController.php:105
* @route '/api/admin/job-applications/{application}'
*/
destroyf5411bf51d203da6a2f2163e361bc215.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return destroyf5411bf51d203da6a2f2163e361bc215.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::destroy
* @see app/Http/Controllers/JobApplicationController.php:105
* @route '/api/admin/job-applications/{application}'
*/
destroyf5411bf51d203da6a2f2163e361bc215.delete = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyf5411bf51d203da6a2f2163e361bc215.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\JobApplicationController::destroy
* @see app/Http/Controllers/JobApplicationController.php:105
* @route '/api/admin/job-applications/{application}'
*/
const destroyf5411bf51d203da6a2f2163e361bc215Form = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyf5411bf51d203da6a2f2163e361bc215.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobApplicationController::destroy
* @see app/Http/Controllers/JobApplicationController.php:105
* @route '/api/admin/job-applications/{application}'
*/
destroyf5411bf51d203da6a2f2163e361bc215Form.delete = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyf5411bf51d203da6a2f2163e361bc215.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyf5411bf51d203da6a2f2163e361bc215.form = destroyf5411bf51d203da6a2f2163e361bc215Form
/**
* @see \App\Http\Controllers\JobApplicationController::destroy
* @see app/Http/Controllers/JobApplicationController.php:105
* @route '/admin/job-applications/{application}'
*/
const destroy11eecb773ef489ef2de4c7d1ccc8ba82 = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy11eecb773ef489ef2de4c7d1ccc8ba82.url(args, options),
    method: 'delete',
})

destroy11eecb773ef489ef2de4c7d1ccc8ba82.definition = {
    methods: ["delete"],
    url: '/admin/job-applications/{application}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\JobApplicationController::destroy
* @see app/Http/Controllers/JobApplicationController.php:105
* @route '/admin/job-applications/{application}'
*/
destroy11eecb773ef489ef2de4c7d1ccc8ba82.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return destroy11eecb773ef489ef2de4c7d1ccc8ba82.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::destroy
* @see app/Http/Controllers/JobApplicationController.php:105
* @route '/admin/job-applications/{application}'
*/
destroy11eecb773ef489ef2de4c7d1ccc8ba82.delete = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy11eecb773ef489ef2de4c7d1ccc8ba82.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\JobApplicationController::destroy
* @see app/Http/Controllers/JobApplicationController.php:105
* @route '/admin/job-applications/{application}'
*/
const destroy11eecb773ef489ef2de4c7d1ccc8ba82Form = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy11eecb773ef489ef2de4c7d1ccc8ba82.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobApplicationController::destroy
* @see app/Http/Controllers/JobApplicationController.php:105
* @route '/admin/job-applications/{application}'
*/
destroy11eecb773ef489ef2de4c7d1ccc8ba82Form.delete = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy11eecb773ef489ef2de4c7d1ccc8ba82.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy11eecb773ef489ef2de4c7d1ccc8ba82.form = destroy11eecb773ef489ef2de4c7d1ccc8ba82Form

export const destroy = {
    '/api/admin/job-applications/{application}': destroyf5411bf51d203da6a2f2163e361bc215,
    '/admin/job-applications/{application}': destroy11eecb773ef489ef2de4c7d1ccc8ba82,
}

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/api/admin/job-applications/{application}/download-resume'
*/
const downloadResumea095cf4ea3d8f7074178ac90c4ee812a = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadResumea095cf4ea3d8f7074178ac90c4ee812a.url(args, options),
    method: 'get',
})

downloadResumea095cf4ea3d8f7074178ac90c4ee812a.definition = {
    methods: ["get","head"],
    url: '/api/admin/job-applications/{application}/download-resume',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/api/admin/job-applications/{application}/download-resume'
*/
downloadResumea095cf4ea3d8f7074178ac90c4ee812a.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return downloadResumea095cf4ea3d8f7074178ac90c4ee812a.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/api/admin/job-applications/{application}/download-resume'
*/
downloadResumea095cf4ea3d8f7074178ac90c4ee812a.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadResumea095cf4ea3d8f7074178ac90c4ee812a.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/api/admin/job-applications/{application}/download-resume'
*/
downloadResumea095cf4ea3d8f7074178ac90c4ee812a.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadResumea095cf4ea3d8f7074178ac90c4ee812a.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/api/admin/job-applications/{application}/download-resume'
*/
const downloadResumea095cf4ea3d8f7074178ac90c4ee812aForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadResumea095cf4ea3d8f7074178ac90c4ee812a.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/api/admin/job-applications/{application}/download-resume'
*/
downloadResumea095cf4ea3d8f7074178ac90c4ee812aForm.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadResumea095cf4ea3d8f7074178ac90c4ee812a.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/api/admin/job-applications/{application}/download-resume'
*/
downloadResumea095cf4ea3d8f7074178ac90c4ee812aForm.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadResumea095cf4ea3d8f7074178ac90c4ee812a.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

downloadResumea095cf4ea3d8f7074178ac90c4ee812a.form = downloadResumea095cf4ea3d8f7074178ac90c4ee812aForm
/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/admin/job-applications/{application}/download-resume'
*/
const downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4 = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.url(args, options),
    method: 'get',
})

downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.definition = {
    methods: ["get","head"],
    url: '/admin/job-applications/{application}/download-resume',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/admin/job-applications/{application}/download-resume'
*/
downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/admin/job-applications/{application}/download-resume'
*/
downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/admin/job-applications/{application}/download-resume'
*/
downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/admin/job-applications/{application}/download-resume'
*/
const downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4Form = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/admin/job-applications/{application}/download-resume'
*/
downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4Form.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobApplicationController::downloadResume
* @see app/Http/Controllers/JobApplicationController.php:123
* @route '/admin/job-applications/{application}/download-resume'
*/
downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4Form.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4.form = downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4Form

export const downloadResume = {
    '/api/admin/job-applications/{application}/download-resume': downloadResumea095cf4ea3d8f7074178ac90c4ee812a,
    '/admin/job-applications/{application}/download-resume': downloadResume823f4bf76a43ccf3f7a8fc1365f4d9e4,
}

const JobApplicationController = { store, index, show, update, destroy, downloadResume }

export default JobApplicationController