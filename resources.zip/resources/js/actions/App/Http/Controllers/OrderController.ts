import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/api/orders/get'
*/
const index2a62a2af54cc10b589bc642ede266c0f = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index2a62a2af54cc10b589bc642ede266c0f.url(options),
    method: 'get',
})

index2a62a2af54cc10b589bc642ede266c0f.definition = {
    methods: ["get","head"],
    url: '/api/orders/get',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/api/orders/get'
*/
index2a62a2af54cc10b589bc642ede266c0f.url = (options?: RouteQueryOptions) => {
    return index2a62a2af54cc10b589bc642ede266c0f.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/api/orders/get'
*/
index2a62a2af54cc10b589bc642ede266c0f.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index2a62a2af54cc10b589bc642ede266c0f.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/api/orders/get'
*/
index2a62a2af54cc10b589bc642ede266c0f.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index2a62a2af54cc10b589bc642ede266c0f.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/api/orders/get'
*/
const index2a62a2af54cc10b589bc642ede266c0fForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index2a62a2af54cc10b589bc642ede266c0f.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/api/orders/get'
*/
index2a62a2af54cc10b589bc642ede266c0fForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index2a62a2af54cc10b589bc642ede266c0f.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/api/orders/get'
*/
index2a62a2af54cc10b589bc642ede266c0fForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index2a62a2af54cc10b589bc642ede266c0f.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index2a62a2af54cc10b589bc642ede266c0f.form = index2a62a2af54cc10b589bc642ede266c0fForm
/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/orders/get'
*/
const indexabe7d5ca4fcc98c42bdf973f543d2c69 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexabe7d5ca4fcc98c42bdf973f543d2c69.url(options),
    method: 'get',
})

indexabe7d5ca4fcc98c42bdf973f543d2c69.definition = {
    methods: ["get","head"],
    url: '/orders/get',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/orders/get'
*/
indexabe7d5ca4fcc98c42bdf973f543d2c69.url = (options?: RouteQueryOptions) => {
    return indexabe7d5ca4fcc98c42bdf973f543d2c69.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/orders/get'
*/
indexabe7d5ca4fcc98c42bdf973f543d2c69.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexabe7d5ca4fcc98c42bdf973f543d2c69.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/orders/get'
*/
indexabe7d5ca4fcc98c42bdf973f543d2c69.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexabe7d5ca4fcc98c42bdf973f543d2c69.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/orders/get'
*/
const indexabe7d5ca4fcc98c42bdf973f543d2c69Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexabe7d5ca4fcc98c42bdf973f543d2c69.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/orders/get'
*/
indexabe7d5ca4fcc98c42bdf973f543d2c69Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexabe7d5ca4fcc98c42bdf973f543d2c69.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::index
* @see app/Http/Controllers/OrderController.php:270
* @route '/orders/get'
*/
indexabe7d5ca4fcc98c42bdf973f543d2c69Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexabe7d5ca4fcc98c42bdf973f543d2c69.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexabe7d5ca4fcc98c42bdf973f543d2c69.form = indexabe7d5ca4fcc98c42bdf973f543d2c69Form

export const index = {
    '/api/orders/get': index2a62a2af54cc10b589bc642ede266c0f,
    '/orders/get': indexabe7d5ca4fcc98c42bdf973f543d2c69,
}

/**
* @see \App\Http\Controllers\OrderController::store
* @see app/Http/Controllers/OrderController.php:172
* @route '/api/orders'
*/
const store3e512021f864d7544b44c9596911b435 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store3e512021f864d7544b44c9596911b435.url(options),
    method: 'post',
})

store3e512021f864d7544b44c9596911b435.definition = {
    methods: ["post"],
    url: '/api/orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\OrderController::store
* @see app/Http/Controllers/OrderController.php:172
* @route '/api/orders'
*/
store3e512021f864d7544b44c9596911b435.url = (options?: RouteQueryOptions) => {
    return store3e512021f864d7544b44c9596911b435.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderController::store
* @see app/Http/Controllers/OrderController.php:172
* @route '/api/orders'
*/
store3e512021f864d7544b44c9596911b435.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store3e512021f864d7544b44c9596911b435.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\OrderController::store
* @see app/Http/Controllers/OrderController.php:172
* @route '/api/orders'
*/
const store3e512021f864d7544b44c9596911b435Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store3e512021f864d7544b44c9596911b435.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\OrderController::store
* @see app/Http/Controllers/OrderController.php:172
* @route '/api/orders'
*/
store3e512021f864d7544b44c9596911b435Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store3e512021f864d7544b44c9596911b435.url(options),
    method: 'post',
})

store3e512021f864d7544b44c9596911b435.form = store3e512021f864d7544b44c9596911b435Form
/**
* @see \App\Http\Controllers\OrderController::store
* @see app/Http/Controllers/OrderController.php:172
* @route '/orders'
*/
const store46d571d7fe903e8a2eecb1a2ccbb23f8 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store46d571d7fe903e8a2eecb1a2ccbb23f8.url(options),
    method: 'post',
})

store46d571d7fe903e8a2eecb1a2ccbb23f8.definition = {
    methods: ["post"],
    url: '/orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\OrderController::store
* @see app/Http/Controllers/OrderController.php:172
* @route '/orders'
*/
store46d571d7fe903e8a2eecb1a2ccbb23f8.url = (options?: RouteQueryOptions) => {
    return store46d571d7fe903e8a2eecb1a2ccbb23f8.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderController::store
* @see app/Http/Controllers/OrderController.php:172
* @route '/orders'
*/
store46d571d7fe903e8a2eecb1a2ccbb23f8.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store46d571d7fe903e8a2eecb1a2ccbb23f8.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\OrderController::store
* @see app/Http/Controllers/OrderController.php:172
* @route '/orders'
*/
const store46d571d7fe903e8a2eecb1a2ccbb23f8Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store46d571d7fe903e8a2eecb1a2ccbb23f8.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\OrderController::store
* @see app/Http/Controllers/OrderController.php:172
* @route '/orders'
*/
store46d571d7fe903e8a2eecb1a2ccbb23f8Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store46d571d7fe903e8a2eecb1a2ccbb23f8.url(options),
    method: 'post',
})

store46d571d7fe903e8a2eecb1a2ccbb23f8.form = store46d571d7fe903e8a2eecb1a2ccbb23f8Form

export const store = {
    '/api/orders': store3e512021f864d7544b44c9596911b435,
    '/orders': store46d571d7fe903e8a2eecb1a2ccbb23f8,
}

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/api/orders/{order}'
*/
const showe8e9a424b645480ae5eda2beaa7c2009 = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showe8e9a424b645480ae5eda2beaa7c2009.url(args, options),
    method: 'get',
})

showe8e9a424b645480ae5eda2beaa7c2009.definition = {
    methods: ["get","head"],
    url: '/api/orders/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/api/orders/{order}'
*/
showe8e9a424b645480ae5eda2beaa7c2009.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return showe8e9a424b645480ae5eda2beaa7c2009.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/api/orders/{order}'
*/
showe8e9a424b645480ae5eda2beaa7c2009.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showe8e9a424b645480ae5eda2beaa7c2009.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/api/orders/{order}'
*/
showe8e9a424b645480ae5eda2beaa7c2009.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showe8e9a424b645480ae5eda2beaa7c2009.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/api/orders/{order}'
*/
const showe8e9a424b645480ae5eda2beaa7c2009Form = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showe8e9a424b645480ae5eda2beaa7c2009.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/api/orders/{order}'
*/
showe8e9a424b645480ae5eda2beaa7c2009Form.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showe8e9a424b645480ae5eda2beaa7c2009.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/api/orders/{order}'
*/
showe8e9a424b645480ae5eda2beaa7c2009Form.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showe8e9a424b645480ae5eda2beaa7c2009.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showe8e9a424b645480ae5eda2beaa7c2009.form = showe8e9a424b645480ae5eda2beaa7c2009Form
/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/orders/{order}'
*/
const show5d07ec4e36119df081df6c80b02e8808 = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show5d07ec4e36119df081df6c80b02e8808.url(args, options),
    method: 'get',
})

show5d07ec4e36119df081df6c80b02e8808.definition = {
    methods: ["get","head"],
    url: '/orders/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/orders/{order}'
*/
show5d07ec4e36119df081df6c80b02e8808.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return show5d07ec4e36119df081df6c80b02e8808.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/orders/{order}'
*/
show5d07ec4e36119df081df6c80b02e8808.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show5d07ec4e36119df081df6c80b02e8808.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/orders/{order}'
*/
show5d07ec4e36119df081df6c80b02e8808.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show5d07ec4e36119df081df6c80b02e8808.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/orders/{order}'
*/
const show5d07ec4e36119df081df6c80b02e8808Form = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show5d07ec4e36119df081df6c80b02e8808.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/orders/{order}'
*/
show5d07ec4e36119df081df6c80b02e8808Form.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show5d07ec4e36119df081df6c80b02e8808.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OrderController::show
* @see app/Http/Controllers/OrderController.php:304
* @route '/orders/{order}'
*/
show5d07ec4e36119df081df6c80b02e8808Form.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show5d07ec4e36119df081df6c80b02e8808.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show5d07ec4e36119df081df6c80b02e8808.form = show5d07ec4e36119df081df6c80b02e8808Form

export const show = {
    '/api/orders/{order}': showe8e9a424b645480ae5eda2beaa7c2009,
    '/orders/{order}': show5d07ec4e36119df081df6c80b02e8808,
}

/**
* @see \App\Http\Controllers\OrderController::initiatePayment
* @see app/Http/Controllers/OrderController.php:34
* @route '/api/orders/{order}/pay'
*/
const initiatePaymenta1baf4c63d558bcaf1079723369da61b = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiatePaymenta1baf4c63d558bcaf1079723369da61b.url(args, options),
    method: 'post',
})

initiatePaymenta1baf4c63d558bcaf1079723369da61b.definition = {
    methods: ["post"],
    url: '/api/orders/{order}/pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\OrderController::initiatePayment
* @see app/Http/Controllers/OrderController.php:34
* @route '/api/orders/{order}/pay'
*/
initiatePaymenta1baf4c63d558bcaf1079723369da61b.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return initiatePaymenta1baf4c63d558bcaf1079723369da61b.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderController::initiatePayment
* @see app/Http/Controllers/OrderController.php:34
* @route '/api/orders/{order}/pay'
*/
initiatePaymenta1baf4c63d558bcaf1079723369da61b.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiatePaymenta1baf4c63d558bcaf1079723369da61b.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\OrderController::initiatePayment
* @see app/Http/Controllers/OrderController.php:34
* @route '/api/orders/{order}/pay'
*/
const initiatePaymenta1baf4c63d558bcaf1079723369da61bForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: initiatePaymenta1baf4c63d558bcaf1079723369da61b.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\OrderController::initiatePayment
* @see app/Http/Controllers/OrderController.php:34
* @route '/api/orders/{order}/pay'
*/
initiatePaymenta1baf4c63d558bcaf1079723369da61bForm.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: initiatePaymenta1baf4c63d558bcaf1079723369da61b.url(args, options),
    method: 'post',
})

initiatePaymenta1baf4c63d558bcaf1079723369da61b.form = initiatePaymenta1baf4c63d558bcaf1079723369da61bForm
/**
* @see \App\Http\Controllers\OrderController::initiatePayment
* @see app/Http/Controllers/OrderController.php:34
* @route '/orders/{order}/pay'
*/
const initiatePaymente767dddb797f07303c2066fb0c9ddad7 = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiatePaymente767dddb797f07303c2066fb0c9ddad7.url(args, options),
    method: 'post',
})

initiatePaymente767dddb797f07303c2066fb0c9ddad7.definition = {
    methods: ["post"],
    url: '/orders/{order}/pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\OrderController::initiatePayment
* @see app/Http/Controllers/OrderController.php:34
* @route '/orders/{order}/pay'
*/
initiatePaymente767dddb797f07303c2066fb0c9ddad7.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return initiatePaymente767dddb797f07303c2066fb0c9ddad7.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderController::initiatePayment
* @see app/Http/Controllers/OrderController.php:34
* @route '/orders/{order}/pay'
*/
initiatePaymente767dddb797f07303c2066fb0c9ddad7.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiatePaymente767dddb797f07303c2066fb0c9ddad7.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\OrderController::initiatePayment
* @see app/Http/Controllers/OrderController.php:34
* @route '/orders/{order}/pay'
*/
const initiatePaymente767dddb797f07303c2066fb0c9ddad7Form = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: initiatePaymente767dddb797f07303c2066fb0c9ddad7.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\OrderController::initiatePayment
* @see app/Http/Controllers/OrderController.php:34
* @route '/orders/{order}/pay'
*/
initiatePaymente767dddb797f07303c2066fb0c9ddad7Form.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: initiatePaymente767dddb797f07303c2066fb0c9ddad7.url(args, options),
    method: 'post',
})

initiatePaymente767dddb797f07303c2066fb0c9ddad7.form = initiatePaymente767dddb797f07303c2066fb0c9ddad7Form

export const initiatePayment = {
    '/api/orders/{order}/pay': initiatePaymenta1baf4c63d558bcaf1079723369da61b,
    '/orders/{order}/pay': initiatePaymente767dddb797f07303c2066fb0c9ddad7,
}

const OrderController = { index, store, show, initiatePayment }

export default OrderController