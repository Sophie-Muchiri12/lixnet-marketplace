import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/view'
*/
const indexdf4ca602b4f96f3e6357bac6550fd60d = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexdf4ca602b4f96f3e6357bac6550fd60d.url(options),
    method: 'get',
})

indexdf4ca602b4f96f3e6357bac6550fd60d.definition = {
    methods: ["get","head"],
    url: '/api/cart/view',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/view'
*/
indexdf4ca602b4f96f3e6357bac6550fd60d.url = (options?: RouteQueryOptions) => {
    return indexdf4ca602b4f96f3e6357bac6550fd60d.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/view'
*/
indexdf4ca602b4f96f3e6357bac6550fd60d.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexdf4ca602b4f96f3e6357bac6550fd60d.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/view'
*/
indexdf4ca602b4f96f3e6357bac6550fd60d.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexdf4ca602b4f96f3e6357bac6550fd60d.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/view'
*/
const indexdf4ca602b4f96f3e6357bac6550fd60dForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexdf4ca602b4f96f3e6357bac6550fd60d.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/view'
*/
indexdf4ca602b4f96f3e6357bac6550fd60dForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexdf4ca602b4f96f3e6357bac6550fd60d.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/view'
*/
indexdf4ca602b4f96f3e6357bac6550fd60dForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexdf4ca602b4f96f3e6357bac6550fd60d.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexdf4ca602b4f96f3e6357bac6550fd60d.form = indexdf4ca602b4f96f3e6357bac6550fd60dForm
/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/get'
*/
const index351542bef2e2129d5579ada179c60bc9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index351542bef2e2129d5579ada179c60bc9.url(options),
    method: 'get',
})

index351542bef2e2129d5579ada179c60bc9.definition = {
    methods: ["get","head"],
    url: '/api/cart/get',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/get'
*/
index351542bef2e2129d5579ada179c60bc9.url = (options?: RouteQueryOptions) => {
    return index351542bef2e2129d5579ada179c60bc9.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/get'
*/
index351542bef2e2129d5579ada179c60bc9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index351542bef2e2129d5579ada179c60bc9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/get'
*/
index351542bef2e2129d5579ada179c60bc9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index351542bef2e2129d5579ada179c60bc9.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/get'
*/
const index351542bef2e2129d5579ada179c60bc9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index351542bef2e2129d5579ada179c60bc9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/get'
*/
index351542bef2e2129d5579ada179c60bc9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index351542bef2e2129d5579ada179c60bc9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/api/cart/get'
*/
index351542bef2e2129d5579ada179c60bc9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index351542bef2e2129d5579ada179c60bc9.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index351542bef2e2129d5579ada179c60bc9.form = index351542bef2e2129d5579ada179c60bc9Form
/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/view'
*/
const index58e9ce23984da13c349e3c58e7180e39 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index58e9ce23984da13c349e3c58e7180e39.url(options),
    method: 'get',
})

index58e9ce23984da13c349e3c58e7180e39.definition = {
    methods: ["get","head"],
    url: '/cart/view',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/view'
*/
index58e9ce23984da13c349e3c58e7180e39.url = (options?: RouteQueryOptions) => {
    return index58e9ce23984da13c349e3c58e7180e39.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/view'
*/
index58e9ce23984da13c349e3c58e7180e39.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index58e9ce23984da13c349e3c58e7180e39.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/view'
*/
index58e9ce23984da13c349e3c58e7180e39.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index58e9ce23984da13c349e3c58e7180e39.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/view'
*/
const index58e9ce23984da13c349e3c58e7180e39Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index58e9ce23984da13c349e3c58e7180e39.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/view'
*/
index58e9ce23984da13c349e3c58e7180e39Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index58e9ce23984da13c349e3c58e7180e39.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/view'
*/
index58e9ce23984da13c349e3c58e7180e39Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index58e9ce23984da13c349e3c58e7180e39.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index58e9ce23984da13c349e3c58e7180e39.form = index58e9ce23984da13c349e3c58e7180e39Form
/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/get'
*/
const indexcb81a69273e8582eed6797b69e5112c9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexcb81a69273e8582eed6797b69e5112c9.url(options),
    method: 'get',
})

indexcb81a69273e8582eed6797b69e5112c9.definition = {
    methods: ["get","head"],
    url: '/cart/get',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/get'
*/
indexcb81a69273e8582eed6797b69e5112c9.url = (options?: RouteQueryOptions) => {
    return indexcb81a69273e8582eed6797b69e5112c9.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/get'
*/
indexcb81a69273e8582eed6797b69e5112c9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexcb81a69273e8582eed6797b69e5112c9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/get'
*/
indexcb81a69273e8582eed6797b69e5112c9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexcb81a69273e8582eed6797b69e5112c9.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/get'
*/
const indexcb81a69273e8582eed6797b69e5112c9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexcb81a69273e8582eed6797b69e5112c9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/get'
*/
indexcb81a69273e8582eed6797b69e5112c9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexcb81a69273e8582eed6797b69e5112c9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::index
* @see app/Http/Controllers/CartController.php:19
* @route '/cart/get'
*/
indexcb81a69273e8582eed6797b69e5112c9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexcb81a69273e8582eed6797b69e5112c9.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexcb81a69273e8582eed6797b69e5112c9.form = indexcb81a69273e8582eed6797b69e5112c9Form

export const index = {
    '/api/cart/view': indexdf4ca602b4f96f3e6357bac6550fd60d,
    '/api/cart/get': index351542bef2e2129d5579ada179c60bc9,
    '/cart/view': index58e9ce23984da13c349e3c58e7180e39,
    '/cart/get': indexcb81a69273e8582eed6797b69e5112c9,
}

/**
* @see \App\Http\Controllers\CartController::addItem
* @see app/Http/Controllers/CartController.php:53
* @route '/api/cart/add'
*/
const addItem3ded636e2a830dd2e0327b8ad88aca5a = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addItem3ded636e2a830dd2e0327b8ad88aca5a.url(options),
    method: 'post',
})

addItem3ded636e2a830dd2e0327b8ad88aca5a.definition = {
    methods: ["post"],
    url: '/api/cart/add',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::addItem
* @see app/Http/Controllers/CartController.php:53
* @route '/api/cart/add'
*/
addItem3ded636e2a830dd2e0327b8ad88aca5a.url = (options?: RouteQueryOptions) => {
    return addItem3ded636e2a830dd2e0327b8ad88aca5a.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::addItem
* @see app/Http/Controllers/CartController.php:53
* @route '/api/cart/add'
*/
addItem3ded636e2a830dd2e0327b8ad88aca5a.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addItem3ded636e2a830dd2e0327b8ad88aca5a.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::addItem
* @see app/Http/Controllers/CartController.php:53
* @route '/api/cart/add'
*/
const addItem3ded636e2a830dd2e0327b8ad88aca5aForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: addItem3ded636e2a830dd2e0327b8ad88aca5a.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::addItem
* @see app/Http/Controllers/CartController.php:53
* @route '/api/cart/add'
*/
addItem3ded636e2a830dd2e0327b8ad88aca5aForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: addItem3ded636e2a830dd2e0327b8ad88aca5a.url(options),
    method: 'post',
})

addItem3ded636e2a830dd2e0327b8ad88aca5a.form = addItem3ded636e2a830dd2e0327b8ad88aca5aForm
/**
* @see \App\Http\Controllers\CartController::addItem
* @see app/Http/Controllers/CartController.php:53
* @route '/cart/add'
*/
const addItemdc951d74dc665a2c7c6b65688c399565 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addItemdc951d74dc665a2c7c6b65688c399565.url(options),
    method: 'post',
})

addItemdc951d74dc665a2c7c6b65688c399565.definition = {
    methods: ["post"],
    url: '/cart/add',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::addItem
* @see app/Http/Controllers/CartController.php:53
* @route '/cart/add'
*/
addItemdc951d74dc665a2c7c6b65688c399565.url = (options?: RouteQueryOptions) => {
    return addItemdc951d74dc665a2c7c6b65688c399565.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::addItem
* @see app/Http/Controllers/CartController.php:53
* @route '/cart/add'
*/
addItemdc951d74dc665a2c7c6b65688c399565.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addItemdc951d74dc665a2c7c6b65688c399565.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::addItem
* @see app/Http/Controllers/CartController.php:53
* @route '/cart/add'
*/
const addItemdc951d74dc665a2c7c6b65688c399565Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: addItemdc951d74dc665a2c7c6b65688c399565.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::addItem
* @see app/Http/Controllers/CartController.php:53
* @route '/cart/add'
*/
addItemdc951d74dc665a2c7c6b65688c399565Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: addItemdc951d74dc665a2c7c6b65688c399565.url(options),
    method: 'post',
})

addItemdc951d74dc665a2c7c6b65688c399565.form = addItemdc951d74dc665a2c7c6b65688c399565Form

export const addItem = {
    '/api/cart/add': addItem3ded636e2a830dd2e0327b8ad88aca5a,
    '/cart/add': addItemdc951d74dc665a2c7c6b65688c399565,
}

/**
* @see \App\Http\Controllers\CartController::updateItem
* @see app/Http/Controllers/CartController.php:127
* @route '/api/cart/items/{cartItem}'
*/
const updateIteme899d7199b3630733153e3f2aefcc86e = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateIteme899d7199b3630733153e3f2aefcc86e.url(args, options),
    method: 'put',
})

updateIteme899d7199b3630733153e3f2aefcc86e.definition = {
    methods: ["put"],
    url: '/api/cart/items/{cartItem}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CartController::updateItem
* @see app/Http/Controllers/CartController.php:127
* @route '/api/cart/items/{cartItem}'
*/
updateIteme899d7199b3630733153e3f2aefcc86e.url = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cartItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { cartItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            cartItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        cartItem: typeof args.cartItem === 'object'
        ? args.cartItem.id
        : args.cartItem,
    }

    return updateIteme899d7199b3630733153e3f2aefcc86e.definition.url
            .replace('{cartItem}', parsedArgs.cartItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::updateItem
* @see app/Http/Controllers/CartController.php:127
* @route '/api/cart/items/{cartItem}'
*/
updateIteme899d7199b3630733153e3f2aefcc86e.put = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateIteme899d7199b3630733153e3f2aefcc86e.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\CartController::updateItem
* @see app/Http/Controllers/CartController.php:127
* @route '/api/cart/items/{cartItem}'
*/
const updateIteme899d7199b3630733153e3f2aefcc86eForm = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateIteme899d7199b3630733153e3f2aefcc86e.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::updateItem
* @see app/Http/Controllers/CartController.php:127
* @route '/api/cart/items/{cartItem}'
*/
updateIteme899d7199b3630733153e3f2aefcc86eForm.put = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateIteme899d7199b3630733153e3f2aefcc86e.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateIteme899d7199b3630733153e3f2aefcc86e.form = updateIteme899d7199b3630733153e3f2aefcc86eForm
/**
* @see \App\Http\Controllers\CartController::updateItem
* @see app/Http/Controllers/CartController.php:127
* @route '/cart/items/{cartItem}'
*/
const updateItema599612bccabe90e1a32ea0375179ede = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItema599612bccabe90e1a32ea0375179ede.url(args, options),
    method: 'put',
})

updateItema599612bccabe90e1a32ea0375179ede.definition = {
    methods: ["put"],
    url: '/cart/items/{cartItem}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CartController::updateItem
* @see app/Http/Controllers/CartController.php:127
* @route '/cart/items/{cartItem}'
*/
updateItema599612bccabe90e1a32ea0375179ede.url = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cartItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { cartItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            cartItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        cartItem: typeof args.cartItem === 'object'
        ? args.cartItem.id
        : args.cartItem,
    }

    return updateItema599612bccabe90e1a32ea0375179ede.definition.url
            .replace('{cartItem}', parsedArgs.cartItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::updateItem
* @see app/Http/Controllers/CartController.php:127
* @route '/cart/items/{cartItem}'
*/
updateItema599612bccabe90e1a32ea0375179ede.put = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItema599612bccabe90e1a32ea0375179ede.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\CartController::updateItem
* @see app/Http/Controllers/CartController.php:127
* @route '/cart/items/{cartItem}'
*/
const updateItema599612bccabe90e1a32ea0375179edeForm = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateItema599612bccabe90e1a32ea0375179ede.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::updateItem
* @see app/Http/Controllers/CartController.php:127
* @route '/cart/items/{cartItem}'
*/
updateItema599612bccabe90e1a32ea0375179edeForm.put = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateItema599612bccabe90e1a32ea0375179ede.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateItema599612bccabe90e1a32ea0375179ede.form = updateItema599612bccabe90e1a32ea0375179edeForm

export const updateItem = {
    '/api/cart/items/{cartItem}': updateIteme899d7199b3630733153e3f2aefcc86e,
    '/cart/items/{cartItem}': updateItema599612bccabe90e1a32ea0375179ede,
}

/**
* @see \App\Http\Controllers\CartController::removeItem
* @see app/Http/Controllers/CartController.php:234
* @route '/api/cart/items/{cartItem}'
*/
const removeIteme899d7199b3630733153e3f2aefcc86e = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeIteme899d7199b3630733153e3f2aefcc86e.url(args, options),
    method: 'delete',
})

removeIteme899d7199b3630733153e3f2aefcc86e.definition = {
    methods: ["delete"],
    url: '/api/cart/items/{cartItem}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CartController::removeItem
* @see app/Http/Controllers/CartController.php:234
* @route '/api/cart/items/{cartItem}'
*/
removeIteme899d7199b3630733153e3f2aefcc86e.url = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cartItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { cartItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            cartItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        cartItem: typeof args.cartItem === 'object'
        ? args.cartItem.id
        : args.cartItem,
    }

    return removeIteme899d7199b3630733153e3f2aefcc86e.definition.url
            .replace('{cartItem}', parsedArgs.cartItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::removeItem
* @see app/Http/Controllers/CartController.php:234
* @route '/api/cart/items/{cartItem}'
*/
removeIteme899d7199b3630733153e3f2aefcc86e.delete = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeIteme899d7199b3630733153e3f2aefcc86e.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CartController::removeItem
* @see app/Http/Controllers/CartController.php:234
* @route '/api/cart/items/{cartItem}'
*/
const removeIteme899d7199b3630733153e3f2aefcc86eForm = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeIteme899d7199b3630733153e3f2aefcc86e.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::removeItem
* @see app/Http/Controllers/CartController.php:234
* @route '/api/cart/items/{cartItem}'
*/
removeIteme899d7199b3630733153e3f2aefcc86eForm.delete = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeIteme899d7199b3630733153e3f2aefcc86e.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

removeIteme899d7199b3630733153e3f2aefcc86e.form = removeIteme899d7199b3630733153e3f2aefcc86eForm
/**
* @see \App\Http\Controllers\CartController::removeItem
* @see app/Http/Controllers/CartController.php:234
* @route '/cart/items/{cartItem}'
*/
const removeItema599612bccabe90e1a32ea0375179ede = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeItema599612bccabe90e1a32ea0375179ede.url(args, options),
    method: 'delete',
})

removeItema599612bccabe90e1a32ea0375179ede.definition = {
    methods: ["delete"],
    url: '/cart/items/{cartItem}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CartController::removeItem
* @see app/Http/Controllers/CartController.php:234
* @route '/cart/items/{cartItem}'
*/
removeItema599612bccabe90e1a32ea0375179ede.url = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cartItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { cartItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            cartItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        cartItem: typeof args.cartItem === 'object'
        ? args.cartItem.id
        : args.cartItem,
    }

    return removeItema599612bccabe90e1a32ea0375179ede.definition.url
            .replace('{cartItem}', parsedArgs.cartItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::removeItem
* @see app/Http/Controllers/CartController.php:234
* @route '/cart/items/{cartItem}'
*/
removeItema599612bccabe90e1a32ea0375179ede.delete = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeItema599612bccabe90e1a32ea0375179ede.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CartController::removeItem
* @see app/Http/Controllers/CartController.php:234
* @route '/cart/items/{cartItem}'
*/
const removeItema599612bccabe90e1a32ea0375179edeForm = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeItema599612bccabe90e1a32ea0375179ede.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::removeItem
* @see app/Http/Controllers/CartController.php:234
* @route '/cart/items/{cartItem}'
*/
removeItema599612bccabe90e1a32ea0375179edeForm.delete = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeItema599612bccabe90e1a32ea0375179ede.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

removeItema599612bccabe90e1a32ea0375179ede.form = removeItema599612bccabe90e1a32ea0375179edeForm

export const removeItem = {
    '/api/cart/items/{cartItem}': removeIteme899d7199b3630733153e3f2aefcc86e,
    '/cart/items/{cartItem}': removeItema599612bccabe90e1a32ea0375179ede,
}

/**
* @see \App\Http\Controllers\CartController::clear
* @see app/Http/Controllers/CartController.php:275
* @route '/api/cart/clear'
*/
const clear755eda98830fbfdc32c1f094b38318cf = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clear755eda98830fbfdc32c1f094b38318cf.url(options),
    method: 'delete',
})

clear755eda98830fbfdc32c1f094b38318cf.definition = {
    methods: ["delete"],
    url: '/api/cart/clear',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CartController::clear
* @see app/Http/Controllers/CartController.php:275
* @route '/api/cart/clear'
*/
clear755eda98830fbfdc32c1f094b38318cf.url = (options?: RouteQueryOptions) => {
    return clear755eda98830fbfdc32c1f094b38318cf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::clear
* @see app/Http/Controllers/CartController.php:275
* @route '/api/cart/clear'
*/
clear755eda98830fbfdc32c1f094b38318cf.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clear755eda98830fbfdc32c1f094b38318cf.url(options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CartController::clear
* @see app/Http/Controllers/CartController.php:275
* @route '/api/cart/clear'
*/
const clear755eda98830fbfdc32c1f094b38318cfForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clear755eda98830fbfdc32c1f094b38318cf.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::clear
* @see app/Http/Controllers/CartController.php:275
* @route '/api/cart/clear'
*/
clear755eda98830fbfdc32c1f094b38318cfForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clear755eda98830fbfdc32c1f094b38318cf.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

clear755eda98830fbfdc32c1f094b38318cf.form = clear755eda98830fbfdc32c1f094b38318cfForm
/**
* @see \App\Http\Controllers\CartController::clear
* @see app/Http/Controllers/CartController.php:275
* @route '/cart/clear'
*/
const cleara7627fa4d0540d28fbbe44549c0fe7d4 = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: cleara7627fa4d0540d28fbbe44549c0fe7d4.url(options),
    method: 'delete',
})

cleara7627fa4d0540d28fbbe44549c0fe7d4.definition = {
    methods: ["delete"],
    url: '/cart/clear',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CartController::clear
* @see app/Http/Controllers/CartController.php:275
* @route '/cart/clear'
*/
cleara7627fa4d0540d28fbbe44549c0fe7d4.url = (options?: RouteQueryOptions) => {
    return cleara7627fa4d0540d28fbbe44549c0fe7d4.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::clear
* @see app/Http/Controllers/CartController.php:275
* @route '/cart/clear'
*/
cleara7627fa4d0540d28fbbe44549c0fe7d4.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: cleara7627fa4d0540d28fbbe44549c0fe7d4.url(options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CartController::clear
* @see app/Http/Controllers/CartController.php:275
* @route '/cart/clear'
*/
const cleara7627fa4d0540d28fbbe44549c0fe7d4Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cleara7627fa4d0540d28fbbe44549c0fe7d4.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::clear
* @see app/Http/Controllers/CartController.php:275
* @route '/cart/clear'
*/
cleara7627fa4d0540d28fbbe44549c0fe7d4Form.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cleara7627fa4d0540d28fbbe44549c0fe7d4.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

cleara7627fa4d0540d28fbbe44549c0fe7d4.form = cleara7627fa4d0540d28fbbe44549c0fe7d4Form

export const clear = {
    '/api/cart/clear': clear755eda98830fbfdc32c1f094b38318cf,
    '/cart/clear': cleara7627fa4d0540d28fbbe44549c0fe7d4,
}

const CartController = { index, addItem, updateItem, removeItem, clear }

export default CartController