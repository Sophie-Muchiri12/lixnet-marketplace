import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/api/admin/users'
*/
const index782bd0c54c5c30ff04582a88a370210e = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index782bd0c54c5c30ff04582a88a370210e.url(options),
    method: 'get',
})

index782bd0c54c5c30ff04582a88a370210e.definition = {
    methods: ["get","head"],
    url: '/api/admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/api/admin/users'
*/
index782bd0c54c5c30ff04582a88a370210e.url = (options?: RouteQueryOptions) => {
    return index782bd0c54c5c30ff04582a88a370210e.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/api/admin/users'
*/
index782bd0c54c5c30ff04582a88a370210e.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index782bd0c54c5c30ff04582a88a370210e.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/api/admin/users'
*/
index782bd0c54c5c30ff04582a88a370210e.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index782bd0c54c5c30ff04582a88a370210e.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/api/admin/users'
*/
const index782bd0c54c5c30ff04582a88a370210eForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index782bd0c54c5c30ff04582a88a370210e.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/api/admin/users'
*/
index782bd0c54c5c30ff04582a88a370210eForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index782bd0c54c5c30ff04582a88a370210e.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/api/admin/users'
*/
index782bd0c54c5c30ff04582a88a370210eForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index782bd0c54c5c30ff04582a88a370210e.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index782bd0c54c5c30ff04582a88a370210e.form = index782bd0c54c5c30ff04582a88a370210eForm
/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/admin/users'
*/
const indexde7b92f5d57ab3be25571f27f05793f8 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexde7b92f5d57ab3be25571f27f05793f8.url(options),
    method: 'get',
})

indexde7b92f5d57ab3be25571f27f05793f8.definition = {
    methods: ["get","head"],
    url: '/admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/admin/users'
*/
indexde7b92f5d57ab3be25571f27f05793f8.url = (options?: RouteQueryOptions) => {
    return indexde7b92f5d57ab3be25571f27f05793f8.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/admin/users'
*/
indexde7b92f5d57ab3be25571f27f05793f8.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexde7b92f5d57ab3be25571f27f05793f8.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/admin/users'
*/
indexde7b92f5d57ab3be25571f27f05793f8.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexde7b92f5d57ab3be25571f27f05793f8.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/admin/users'
*/
const indexde7b92f5d57ab3be25571f27f05793f8Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexde7b92f5d57ab3be25571f27f05793f8.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/admin/users'
*/
indexde7b92f5d57ab3be25571f27f05793f8Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexde7b92f5d57ab3be25571f27f05793f8.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::index
* @see app/Http/Controllers/AdminUserController.php:15
* @route '/admin/users'
*/
indexde7b92f5d57ab3be25571f27f05793f8Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexde7b92f5d57ab3be25571f27f05793f8.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexde7b92f5d57ab3be25571f27f05793f8.form = indexde7b92f5d57ab3be25571f27f05793f8Form

export const index = {
    '/api/admin/users': index782bd0c54c5c30ff04582a88a370210e,
    '/admin/users': indexde7b92f5d57ab3be25571f27f05793f8,
}

/**
* @see \App\Http\Controllers\AdminUserController::store
* @see app/Http/Controllers/AdminUserController.php:194
* @route '/api/admin/users'
*/
const store782bd0c54c5c30ff04582a88a370210e = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store782bd0c54c5c30ff04582a88a370210e.url(options),
    method: 'post',
})

store782bd0c54c5c30ff04582a88a370210e.definition = {
    methods: ["post"],
    url: '/api/admin/users',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminUserController::store
* @see app/Http/Controllers/AdminUserController.php:194
* @route '/api/admin/users'
*/
store782bd0c54c5c30ff04582a88a370210e.url = (options?: RouteQueryOptions) => {
    return store782bd0c54c5c30ff04582a88a370210e.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminUserController::store
* @see app/Http/Controllers/AdminUserController.php:194
* @route '/api/admin/users'
*/
store782bd0c54c5c30ff04582a88a370210e.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store782bd0c54c5c30ff04582a88a370210e.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminUserController::store
* @see app/Http/Controllers/AdminUserController.php:194
* @route '/api/admin/users'
*/
const store782bd0c54c5c30ff04582a88a370210eForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store782bd0c54c5c30ff04582a88a370210e.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminUserController::store
* @see app/Http/Controllers/AdminUserController.php:194
* @route '/api/admin/users'
*/
store782bd0c54c5c30ff04582a88a370210eForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store782bd0c54c5c30ff04582a88a370210e.url(options),
    method: 'post',
})

store782bd0c54c5c30ff04582a88a370210e.form = store782bd0c54c5c30ff04582a88a370210eForm
/**
* @see \App\Http\Controllers\AdminUserController::store
* @see app/Http/Controllers/AdminUserController.php:194
* @route '/admin/users'
*/
const storede7b92f5d57ab3be25571f27f05793f8 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storede7b92f5d57ab3be25571f27f05793f8.url(options),
    method: 'post',
})

storede7b92f5d57ab3be25571f27f05793f8.definition = {
    methods: ["post"],
    url: '/admin/users',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminUserController::store
* @see app/Http/Controllers/AdminUserController.php:194
* @route '/admin/users'
*/
storede7b92f5d57ab3be25571f27f05793f8.url = (options?: RouteQueryOptions) => {
    return storede7b92f5d57ab3be25571f27f05793f8.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminUserController::store
* @see app/Http/Controllers/AdminUserController.php:194
* @route '/admin/users'
*/
storede7b92f5d57ab3be25571f27f05793f8.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storede7b92f5d57ab3be25571f27f05793f8.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminUserController::store
* @see app/Http/Controllers/AdminUserController.php:194
* @route '/admin/users'
*/
const storede7b92f5d57ab3be25571f27f05793f8Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storede7b92f5d57ab3be25571f27f05793f8.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminUserController::store
* @see app/Http/Controllers/AdminUserController.php:194
* @route '/admin/users'
*/
storede7b92f5d57ab3be25571f27f05793f8Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storede7b92f5d57ab3be25571f27f05793f8.url(options),
    method: 'post',
})

storede7b92f5d57ab3be25571f27f05793f8.form = storede7b92f5d57ab3be25571f27f05793f8Form

export const store = {
    '/api/admin/users': store782bd0c54c5c30ff04582a88a370210e,
    '/admin/users': storede7b92f5d57ab3be25571f27f05793f8,
}

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/api/admin/users/{user}'
*/
const show1ab12d0f9ad7670c3c8c48f5dd894839 = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show1ab12d0f9ad7670c3c8c48f5dd894839.url(args, options),
    method: 'get',
})

show1ab12d0f9ad7670c3c8c48f5dd894839.definition = {
    methods: ["get","head"],
    url: '/api/admin/users/{user}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/api/admin/users/{user}'
*/
show1ab12d0f9ad7670c3c8c48f5dd894839.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return show1ab12d0f9ad7670c3c8c48f5dd894839.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/api/admin/users/{user}'
*/
show1ab12d0f9ad7670c3c8c48f5dd894839.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show1ab12d0f9ad7670c3c8c48f5dd894839.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/api/admin/users/{user}'
*/
show1ab12d0f9ad7670c3c8c48f5dd894839.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show1ab12d0f9ad7670c3c8c48f5dd894839.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/api/admin/users/{user}'
*/
const show1ab12d0f9ad7670c3c8c48f5dd894839Form = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show1ab12d0f9ad7670c3c8c48f5dd894839.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/api/admin/users/{user}'
*/
show1ab12d0f9ad7670c3c8c48f5dd894839Form.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show1ab12d0f9ad7670c3c8c48f5dd894839.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/api/admin/users/{user}'
*/
show1ab12d0f9ad7670c3c8c48f5dd894839Form.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show1ab12d0f9ad7670c3c8c48f5dd894839.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show1ab12d0f9ad7670c3c8c48f5dd894839.form = show1ab12d0f9ad7670c3c8c48f5dd894839Form
/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/admin/users/{user}'
*/
const showfcf537c0ef09758de25ef4ed617562a1 = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showfcf537c0ef09758de25ef4ed617562a1.url(args, options),
    method: 'get',
})

showfcf537c0ef09758de25ef4ed617562a1.definition = {
    methods: ["get","head"],
    url: '/admin/users/{user}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/admin/users/{user}'
*/
showfcf537c0ef09758de25ef4ed617562a1.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return showfcf537c0ef09758de25ef4ed617562a1.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/admin/users/{user}'
*/
showfcf537c0ef09758de25ef4ed617562a1.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showfcf537c0ef09758de25ef4ed617562a1.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/admin/users/{user}'
*/
showfcf537c0ef09758de25ef4ed617562a1.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showfcf537c0ef09758de25ef4ed617562a1.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/admin/users/{user}'
*/
const showfcf537c0ef09758de25ef4ed617562a1Form = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showfcf537c0ef09758de25ef4ed617562a1.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/admin/users/{user}'
*/
showfcf537c0ef09758de25ef4ed617562a1Form.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showfcf537c0ef09758de25ef4ed617562a1.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::show
* @see app/Http/Controllers/AdminUserController.php:90
* @route '/admin/users/{user}'
*/
showfcf537c0ef09758de25ef4ed617562a1Form.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showfcf537c0ef09758de25ef4ed617562a1.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showfcf537c0ef09758de25ef4ed617562a1.form = showfcf537c0ef09758de25ef4ed617562a1Form

export const show = {
    '/api/admin/users/{user}': show1ab12d0f9ad7670c3c8c48f5dd894839,
    '/admin/users/{user}': showfcf537c0ef09758de25ef4ed617562a1,
}

/**
* @see \App\Http\Controllers\AdminUserController::update
* @see app/Http/Controllers/AdminUserController.php:170
* @route '/api/admin/users/{user}'
*/
const update1ab12d0f9ad7670c3c8c48f5dd894839 = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update1ab12d0f9ad7670c3c8c48f5dd894839.url(args, options),
    method: 'put',
})

update1ab12d0f9ad7670c3c8c48f5dd894839.definition = {
    methods: ["put"],
    url: '/api/admin/users/{user}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminUserController::update
* @see app/Http/Controllers/AdminUserController.php:170
* @route '/api/admin/users/{user}'
*/
update1ab12d0f9ad7670c3c8c48f5dd894839.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return update1ab12d0f9ad7670c3c8c48f5dd894839.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminUserController::update
* @see app/Http/Controllers/AdminUserController.php:170
* @route '/api/admin/users/{user}'
*/
update1ab12d0f9ad7670c3c8c48f5dd894839.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update1ab12d0f9ad7670c3c8c48f5dd894839.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\AdminUserController::update
* @see app/Http/Controllers/AdminUserController.php:170
* @route '/api/admin/users/{user}'
*/
const update1ab12d0f9ad7670c3c8c48f5dd894839Form = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update1ab12d0f9ad7670c3c8c48f5dd894839.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminUserController::update
* @see app/Http/Controllers/AdminUserController.php:170
* @route '/api/admin/users/{user}'
*/
update1ab12d0f9ad7670c3c8c48f5dd894839Form.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update1ab12d0f9ad7670c3c8c48f5dd894839.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update1ab12d0f9ad7670c3c8c48f5dd894839.form = update1ab12d0f9ad7670c3c8c48f5dd894839Form
/**
* @see \App\Http\Controllers\AdminUserController::update
* @see app/Http/Controllers/AdminUserController.php:170
* @route '/admin/users/{user}'
*/
const updatefcf537c0ef09758de25ef4ed617562a1 = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatefcf537c0ef09758de25ef4ed617562a1.url(args, options),
    method: 'put',
})

updatefcf537c0ef09758de25ef4ed617562a1.definition = {
    methods: ["put"],
    url: '/admin/users/{user}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminUserController::update
* @see app/Http/Controllers/AdminUserController.php:170
* @route '/admin/users/{user}'
*/
updatefcf537c0ef09758de25ef4ed617562a1.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return updatefcf537c0ef09758de25ef4ed617562a1.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminUserController::update
* @see app/Http/Controllers/AdminUserController.php:170
* @route '/admin/users/{user}'
*/
updatefcf537c0ef09758de25ef4ed617562a1.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatefcf537c0ef09758de25ef4ed617562a1.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\AdminUserController::update
* @see app/Http/Controllers/AdminUserController.php:170
* @route '/admin/users/{user}'
*/
const updatefcf537c0ef09758de25ef4ed617562a1Form = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updatefcf537c0ef09758de25ef4ed617562a1.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminUserController::update
* @see app/Http/Controllers/AdminUserController.php:170
* @route '/admin/users/{user}'
*/
updatefcf537c0ef09758de25ef4ed617562a1Form.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updatefcf537c0ef09758de25ef4ed617562a1.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updatefcf537c0ef09758de25ef4ed617562a1.form = updatefcf537c0ef09758de25ef4ed617562a1Form

export const update = {
    '/api/admin/users/{user}': update1ab12d0f9ad7670c3c8c48f5dd894839,
    '/admin/users/{user}': updatefcf537c0ef09758de25ef4ed617562a1,
}

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/api/admin/users/{user}/orders'
*/
const orders95c4ad21dd73cd709f0bef8a15f4e559 = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orders95c4ad21dd73cd709f0bef8a15f4e559.url(args, options),
    method: 'get',
})

orders95c4ad21dd73cd709f0bef8a15f4e559.definition = {
    methods: ["get","head"],
    url: '/api/admin/users/{user}/orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/api/admin/users/{user}/orders'
*/
orders95c4ad21dd73cd709f0bef8a15f4e559.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return orders95c4ad21dd73cd709f0bef8a15f4e559.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/api/admin/users/{user}/orders'
*/
orders95c4ad21dd73cd709f0bef8a15f4e559.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orders95c4ad21dd73cd709f0bef8a15f4e559.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/api/admin/users/{user}/orders'
*/
orders95c4ad21dd73cd709f0bef8a15f4e559.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orders95c4ad21dd73cd709f0bef8a15f4e559.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/api/admin/users/{user}/orders'
*/
const orders95c4ad21dd73cd709f0bef8a15f4e559Form = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orders95c4ad21dd73cd709f0bef8a15f4e559.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/api/admin/users/{user}/orders'
*/
orders95c4ad21dd73cd709f0bef8a15f4e559Form.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orders95c4ad21dd73cd709f0bef8a15f4e559.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/api/admin/users/{user}/orders'
*/
orders95c4ad21dd73cd709f0bef8a15f4e559Form.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orders95c4ad21dd73cd709f0bef8a15f4e559.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

orders95c4ad21dd73cd709f0bef8a15f4e559.form = orders95c4ad21dd73cd709f0bef8a15f4e559Form
/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/admin/users/{user}/orders'
*/
const orders56545e8f360db07a35b0d2614fee088e = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orders56545e8f360db07a35b0d2614fee088e.url(args, options),
    method: 'get',
})

orders56545e8f360db07a35b0d2614fee088e.definition = {
    methods: ["get","head"],
    url: '/admin/users/{user}/orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/admin/users/{user}/orders'
*/
orders56545e8f360db07a35b0d2614fee088e.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return orders56545e8f360db07a35b0d2614fee088e.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/admin/users/{user}/orders'
*/
orders56545e8f360db07a35b0d2614fee088e.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orders56545e8f360db07a35b0d2614fee088e.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/admin/users/{user}/orders'
*/
orders56545e8f360db07a35b0d2614fee088e.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orders56545e8f360db07a35b0d2614fee088e.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/admin/users/{user}/orders'
*/
const orders56545e8f360db07a35b0d2614fee088eForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orders56545e8f360db07a35b0d2614fee088e.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/admin/users/{user}/orders'
*/
orders56545e8f360db07a35b0d2614fee088eForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orders56545e8f360db07a35b0d2614fee088e.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminUserController::orders
* @see app/Http/Controllers/AdminUserController.php:133
* @route '/admin/users/{user}/orders'
*/
orders56545e8f360db07a35b0d2614fee088eForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: orders56545e8f360db07a35b0d2614fee088e.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

orders56545e8f360db07a35b0d2614fee088e.form = orders56545e8f360db07a35b0d2614fee088eForm

export const orders = {
    '/api/admin/users/{user}/orders': orders95c4ad21dd73cd709f0bef8a15f4e559,
    '/admin/users/{user}/orders': orders56545e8f360db07a35b0d2614fee088e,
}

const AdminUserController = { index, store, show, update, orders }

export default AdminUserController