import CategoryController from './CategoryController'
import ProductController from './ProductController'
import CartController from './CartController'
import JobController from './JobController'
import JobApplicationController from './JobApplicationController'
import PesapalCallbackController from './PesapalCallbackController'
import OrderController from './OrderController'
import UserController from './UserController'
import AgentApplicationController from './AgentApplicationController'
import SubscriptionController from './SubscriptionController'
import SSOProductController from './SSOProductController'
import Admin from './Admin'
import AdminUserController from './AdminUserController'
import Settings from './Settings'
import Auth from './Auth'

const Controllers = {
    CategoryController,
    ProductController,
    CartController,
    JobController,
    JobApplicationController,
    PesapalCallbackController,
    OrderController,
    UserController,
    AgentApplicationController,
    SubscriptionController,
    SSOProductController,
    Admin,
    AdminUserController,
    Settings,
    Auth,
}

export default Controllers