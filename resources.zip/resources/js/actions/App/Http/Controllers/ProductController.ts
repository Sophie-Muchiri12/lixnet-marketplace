import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/api/products'
*/
const index6ab24975c76dbf11a1bc082b81a80bc0 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index6ab24975c76dbf11a1bc082b81a80bc0.url(options),
    method: 'get',
})

index6ab24975c76dbf11a1bc082b81a80bc0.definition = {
    methods: ["get","head"],
    url: '/api/products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/api/products'
*/
index6ab24975c76dbf11a1bc082b81a80bc0.url = (options?: RouteQueryOptions) => {
    return index6ab24975c76dbf11a1bc082b81a80bc0.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/api/products'
*/
index6ab24975c76dbf11a1bc082b81a80bc0.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index6ab24975c76dbf11a1bc082b81a80bc0.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/api/products'
*/
index6ab24975c76dbf11a1bc082b81a80bc0.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index6ab24975c76dbf11a1bc082b81a80bc0.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/api/products'
*/
const index6ab24975c76dbf11a1bc082b81a80bc0Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index6ab24975c76dbf11a1bc082b81a80bc0.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/api/products'
*/
index6ab24975c76dbf11a1bc082b81a80bc0Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index6ab24975c76dbf11a1bc082b81a80bc0.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/api/products'
*/
index6ab24975c76dbf11a1bc082b81a80bc0Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index6ab24975c76dbf11a1bc082b81a80bc0.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index6ab24975c76dbf11a1bc082b81a80bc0.form = index6ab24975c76dbf11a1bc082b81a80bc0Form
/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/products'
*/
const index431eb3176f0b3b6628922509e73230e6 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'get',
})

index431eb3176f0b3b6628922509e73230e6.definition = {
    methods: ["get","head"],
    url: '/products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/products'
*/
index431eb3176f0b3b6628922509e73230e6.url = (options?: RouteQueryOptions) => {
    return index431eb3176f0b3b6628922509e73230e6.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/products'
*/
index431eb3176f0b3b6628922509e73230e6.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/products'
*/
index431eb3176f0b3b6628922509e73230e6.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/products'
*/
const index431eb3176f0b3b6628922509e73230e6Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/products'
*/
index431eb3176f0b3b6628922509e73230e6Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::index
* @see app/Http/Controllers/ProductController.php:17
* @route '/products'
*/
index431eb3176f0b3b6628922509e73230e6Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index431eb3176f0b3b6628922509e73230e6.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index431eb3176f0b3b6628922509e73230e6.form = index431eb3176f0b3b6628922509e73230e6Form

export const index = {
    '/api/products': index6ab24975c76dbf11a1bc082b81a80bc0,
    '/products': index431eb3176f0b3b6628922509e73230e6,
}

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:93
* @route '/api/products'
*/
const store6ab24975c76dbf11a1bc082b81a80bc0 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store6ab24975c76dbf11a1bc082b81a80bc0.url(options),
    method: 'post',
})

store6ab24975c76dbf11a1bc082b81a80bc0.definition = {
    methods: ["post"],
    url: '/api/products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:93
* @route '/api/products'
*/
store6ab24975c76dbf11a1bc082b81a80bc0.url = (options?: RouteQueryOptions) => {
    return store6ab24975c76dbf11a1bc082b81a80bc0.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:93
* @route '/api/products'
*/
store6ab24975c76dbf11a1bc082b81a80bc0.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store6ab24975c76dbf11a1bc082b81a80bc0.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:93
* @route '/api/products'
*/
const store6ab24975c76dbf11a1bc082b81a80bc0Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store6ab24975c76dbf11a1bc082b81a80bc0.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:93
* @route '/api/products'
*/
store6ab24975c76dbf11a1bc082b81a80bc0Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store6ab24975c76dbf11a1bc082b81a80bc0.url(options),
    method: 'post',
})

store6ab24975c76dbf11a1bc082b81a80bc0.form = store6ab24975c76dbf11a1bc082b81a80bc0Form
/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:93
* @route '/products'
*/
const store431eb3176f0b3b6628922509e73230e6 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'post',
})

store431eb3176f0b3b6628922509e73230e6.definition = {
    methods: ["post"],
    url: '/products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:93
* @route '/products'
*/
store431eb3176f0b3b6628922509e73230e6.url = (options?: RouteQueryOptions) => {
    return store431eb3176f0b3b6628922509e73230e6.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:93
* @route '/products'
*/
store431eb3176f0b3b6628922509e73230e6.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:93
* @route '/products'
*/
const store431eb3176f0b3b6628922509e73230e6Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::store
* @see app/Http/Controllers/ProductController.php:93
* @route '/products'
*/
store431eb3176f0b3b6628922509e73230e6Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store431eb3176f0b3b6628922509e73230e6.url(options),
    method: 'post',
})

store431eb3176f0b3b6628922509e73230e6.form = store431eb3176f0b3b6628922509e73230e6Form

export const store = {
    '/api/products': store6ab24975c76dbf11a1bc082b81a80bc0,
    '/products': store431eb3176f0b3b6628922509e73230e6,
}

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/api/products/search'
*/
const search09f4b7382ac131b890f1e8318762b1ae = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search09f4b7382ac131b890f1e8318762b1ae.url(options),
    method: 'get',
})

search09f4b7382ac131b890f1e8318762b1ae.definition = {
    methods: ["get","head"],
    url: '/api/products/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/api/products/search'
*/
search09f4b7382ac131b890f1e8318762b1ae.url = (options?: RouteQueryOptions) => {
    return search09f4b7382ac131b890f1e8318762b1ae.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/api/products/search'
*/
search09f4b7382ac131b890f1e8318762b1ae.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search09f4b7382ac131b890f1e8318762b1ae.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/api/products/search'
*/
search09f4b7382ac131b890f1e8318762b1ae.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search09f4b7382ac131b890f1e8318762b1ae.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/api/products/search'
*/
const search09f4b7382ac131b890f1e8318762b1aeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search09f4b7382ac131b890f1e8318762b1ae.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/api/products/search'
*/
search09f4b7382ac131b890f1e8318762b1aeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search09f4b7382ac131b890f1e8318762b1ae.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/api/products/search'
*/
search09f4b7382ac131b890f1e8318762b1aeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search09f4b7382ac131b890f1e8318762b1ae.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

search09f4b7382ac131b890f1e8318762b1ae.form = search09f4b7382ac131b890f1e8318762b1aeForm
/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/products/search'
*/
const search62a1a7643830243ffd378cf85ea39996 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search62a1a7643830243ffd378cf85ea39996.url(options),
    method: 'get',
})

search62a1a7643830243ffd378cf85ea39996.definition = {
    methods: ["get","head"],
    url: '/products/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/products/search'
*/
search62a1a7643830243ffd378cf85ea39996.url = (options?: RouteQueryOptions) => {
    return search62a1a7643830243ffd378cf85ea39996.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/products/search'
*/
search62a1a7643830243ffd378cf85ea39996.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search62a1a7643830243ffd378cf85ea39996.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/products/search'
*/
search62a1a7643830243ffd378cf85ea39996.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search62a1a7643830243ffd378cf85ea39996.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/products/search'
*/
const search62a1a7643830243ffd378cf85ea39996Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search62a1a7643830243ffd378cf85ea39996.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/products/search'
*/
search62a1a7643830243ffd378cf85ea39996Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search62a1a7643830243ffd378cf85ea39996.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::search
* @see app/Http/Controllers/ProductController.php:131
* @route '/products/search'
*/
search62a1a7643830243ffd378cf85ea39996Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search62a1a7643830243ffd378cf85ea39996.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

search62a1a7643830243ffd378cf85ea39996.form = search62a1a7643830243ffd378cf85ea39996Form

export const search = {
    '/api/products/search': search09f4b7382ac131b890f1e8318762b1ae,
    '/products/search': search62a1a7643830243ffd378cf85ea39996,
}

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/api/products/filter'
*/
const filterByCategorye6e566d433feef51b936de3209af6367 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filterByCategorye6e566d433feef51b936de3209af6367.url(options),
    method: 'get',
})

filterByCategorye6e566d433feef51b936de3209af6367.definition = {
    methods: ["get","head"],
    url: '/api/products/filter',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/api/products/filter'
*/
filterByCategorye6e566d433feef51b936de3209af6367.url = (options?: RouteQueryOptions) => {
    return filterByCategorye6e566d433feef51b936de3209af6367.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/api/products/filter'
*/
filterByCategorye6e566d433feef51b936de3209af6367.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filterByCategorye6e566d433feef51b936de3209af6367.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/api/products/filter'
*/
filterByCategorye6e566d433feef51b936de3209af6367.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: filterByCategorye6e566d433feef51b936de3209af6367.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/api/products/filter'
*/
const filterByCategorye6e566d433feef51b936de3209af6367Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filterByCategorye6e566d433feef51b936de3209af6367.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/api/products/filter'
*/
filterByCategorye6e566d433feef51b936de3209af6367Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filterByCategorye6e566d433feef51b936de3209af6367.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/api/products/filter'
*/
filterByCategorye6e566d433feef51b936de3209af6367Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filterByCategorye6e566d433feef51b936de3209af6367.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

filterByCategorye6e566d433feef51b936de3209af6367.form = filterByCategorye6e566d433feef51b936de3209af6367Form
/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/products/filter'
*/
const filterByCategoryf1674b89cee00b7d21c66faaf2072ffd = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.url(options),
    method: 'get',
})

filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.definition = {
    methods: ["get","head"],
    url: '/products/filter',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/products/filter'
*/
filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.url = (options?: RouteQueryOptions) => {
    return filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/products/filter'
*/
filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/products/filter'
*/
filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/products/filter'
*/
const filterByCategoryf1674b89cee00b7d21c66faaf2072ffdForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/products/filter'
*/
filterByCategoryf1674b89cee00b7d21c66faaf2072ffdForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::filterByCategory
* @see app/Http/Controllers/ProductController.php:161
* @route '/products/filter'
*/
filterByCategoryf1674b89cee00b7d21c66faaf2072ffdForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

filterByCategoryf1674b89cee00b7d21c66faaf2072ffd.form = filterByCategoryf1674b89cee00b7d21c66faaf2072ffdForm

export const filterByCategory = {
    '/api/products/filter': filterByCategorye6e566d433feef51b936de3209af6367,
    '/products/filter': filterByCategoryf1674b89cee00b7d21c66faaf2072ffd,
}

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/api/products/featured'
*/
const featured4a99cb56339c4fd8f86406e4b7f80284 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: featured4a99cb56339c4fd8f86406e4b7f80284.url(options),
    method: 'get',
})

featured4a99cb56339c4fd8f86406e4b7f80284.definition = {
    methods: ["get","head"],
    url: '/api/products/featured',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/api/products/featured'
*/
featured4a99cb56339c4fd8f86406e4b7f80284.url = (options?: RouteQueryOptions) => {
    return featured4a99cb56339c4fd8f86406e4b7f80284.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/api/products/featured'
*/
featured4a99cb56339c4fd8f86406e4b7f80284.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: featured4a99cb56339c4fd8f86406e4b7f80284.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/api/products/featured'
*/
featured4a99cb56339c4fd8f86406e4b7f80284.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: featured4a99cb56339c4fd8f86406e4b7f80284.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/api/products/featured'
*/
const featured4a99cb56339c4fd8f86406e4b7f80284Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: featured4a99cb56339c4fd8f86406e4b7f80284.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/api/products/featured'
*/
featured4a99cb56339c4fd8f86406e4b7f80284Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: featured4a99cb56339c4fd8f86406e4b7f80284.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/api/products/featured'
*/
featured4a99cb56339c4fd8f86406e4b7f80284Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: featured4a99cb56339c4fd8f86406e4b7f80284.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

featured4a99cb56339c4fd8f86406e4b7f80284.form = featured4a99cb56339c4fd8f86406e4b7f80284Form
/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/products/featured'
*/
const featured65647dc0d8f3e69b84d08350c42b7e49 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: featured65647dc0d8f3e69b84d08350c42b7e49.url(options),
    method: 'get',
})

featured65647dc0d8f3e69b84d08350c42b7e49.definition = {
    methods: ["get","head"],
    url: '/products/featured',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/products/featured'
*/
featured65647dc0d8f3e69b84d08350c42b7e49.url = (options?: RouteQueryOptions) => {
    return featured65647dc0d8f3e69b84d08350c42b7e49.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/products/featured'
*/
featured65647dc0d8f3e69b84d08350c42b7e49.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: featured65647dc0d8f3e69b84d08350c42b7e49.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/products/featured'
*/
featured65647dc0d8f3e69b84d08350c42b7e49.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: featured65647dc0d8f3e69b84d08350c42b7e49.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/products/featured'
*/
const featured65647dc0d8f3e69b84d08350c42b7e49Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: featured65647dc0d8f3e69b84d08350c42b7e49.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/products/featured'
*/
featured65647dc0d8f3e69b84d08350c42b7e49Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: featured65647dc0d8f3e69b84d08350c42b7e49.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::featured
* @see app/Http/Controllers/ProductController.php:200
* @route '/products/featured'
*/
featured65647dc0d8f3e69b84d08350c42b7e49Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: featured65647dc0d8f3e69b84d08350c42b7e49.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

featured65647dc0d8f3e69b84d08350c42b7e49.form = featured65647dc0d8f3e69b84d08350c42b7e49Form

export const featured = {
    '/api/products/featured': featured4a99cb56339c4fd8f86406e4b7f80284,
    '/products/featured': featured65647dc0d8f3e69b84d08350c42b7e49,
}

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/api/products/{product}'
*/
const show8b31a3148adac2aae83b33cd08a1abbb = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show8b31a3148adac2aae83b33cd08a1abbb.url(args, options),
    method: 'get',
})

show8b31a3148adac2aae83b33cd08a1abbb.definition = {
    methods: ["get","head"],
    url: '/api/products/{product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/api/products/{product}'
*/
show8b31a3148adac2aae83b33cd08a1abbb.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return show8b31a3148adac2aae83b33cd08a1abbb.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/api/products/{product}'
*/
show8b31a3148adac2aae83b33cd08a1abbb.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show8b31a3148adac2aae83b33cd08a1abbb.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/api/products/{product}'
*/
show8b31a3148adac2aae83b33cd08a1abbb.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show8b31a3148adac2aae83b33cd08a1abbb.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/api/products/{product}'
*/
const show8b31a3148adac2aae83b33cd08a1abbbForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show8b31a3148adac2aae83b33cd08a1abbb.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/api/products/{product}'
*/
show8b31a3148adac2aae83b33cd08a1abbbForm.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show8b31a3148adac2aae83b33cd08a1abbb.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/api/products/{product}'
*/
show8b31a3148adac2aae83b33cd08a1abbbForm.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show8b31a3148adac2aae83b33cd08a1abbb.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show8b31a3148adac2aae83b33cd08a1abbb.form = show8b31a3148adac2aae83b33cd08a1abbbForm
/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/products/{product}'
*/
const show10fd0b36a14fef2f24a4e9da12196a3a = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show10fd0b36a14fef2f24a4e9da12196a3a.url(args, options),
    method: 'get',
})

show10fd0b36a14fef2f24a4e9da12196a3a.definition = {
    methods: ["get","head"],
    url: '/products/{product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/products/{product}'
*/
show10fd0b36a14fef2f24a4e9da12196a3a.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return show10fd0b36a14fef2f24a4e9da12196a3a.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/products/{product}'
*/
show10fd0b36a14fef2f24a4e9da12196a3a.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show10fd0b36a14fef2f24a4e9da12196a3a.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/products/{product}'
*/
show10fd0b36a14fef2f24a4e9da12196a3a.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show10fd0b36a14fef2f24a4e9da12196a3a.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/products/{product}'
*/
const show10fd0b36a14fef2f24a4e9da12196a3aForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show10fd0b36a14fef2f24a4e9da12196a3a.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/products/{product}'
*/
show10fd0b36a14fef2f24a4e9da12196a3aForm.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show10fd0b36a14fef2f24a4e9da12196a3a.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProductController::show
* @see app/Http/Controllers/ProductController.php:71
* @route '/products/{product}'
*/
show10fd0b36a14fef2f24a4e9da12196a3aForm.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show10fd0b36a14fef2f24a4e9da12196a3a.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show10fd0b36a14fef2f24a4e9da12196a3a.form = show10fd0b36a14fef2f24a4e9da12196a3aForm

export const show = {
    '/api/products/{product}': show8b31a3148adac2aae83b33cd08a1abbb,
    '/products/{product}': show10fd0b36a14fef2f24a4e9da12196a3a,
}

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:227
* @route '/api/products/{product}'
*/
const update8b31a3148adac2aae83b33cd08a1abbb = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update8b31a3148adac2aae83b33cd08a1abbb.url(args, options),
    method: 'put',
})

update8b31a3148adac2aae83b33cd08a1abbb.definition = {
    methods: ["put"],
    url: '/api/products/{product}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:227
* @route '/api/products/{product}'
*/
update8b31a3148adac2aae83b33cd08a1abbb.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return update8b31a3148adac2aae83b33cd08a1abbb.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:227
* @route '/api/products/{product}'
*/
update8b31a3148adac2aae83b33cd08a1abbb.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update8b31a3148adac2aae83b33cd08a1abbb.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:227
* @route '/api/products/{product}'
*/
const update8b31a3148adac2aae83b33cd08a1abbbForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update8b31a3148adac2aae83b33cd08a1abbb.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:227
* @route '/api/products/{product}'
*/
update8b31a3148adac2aae83b33cd08a1abbbForm.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update8b31a3148adac2aae83b33cd08a1abbb.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update8b31a3148adac2aae83b33cd08a1abbb.form = update8b31a3148adac2aae83b33cd08a1abbbForm
/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:227
* @route '/products/{product}'
*/
const update10fd0b36a14fef2f24a4e9da12196a3a = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update10fd0b36a14fef2f24a4e9da12196a3a.url(args, options),
    method: 'put',
})

update10fd0b36a14fef2f24a4e9da12196a3a.definition = {
    methods: ["put"],
    url: '/products/{product}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:227
* @route '/products/{product}'
*/
update10fd0b36a14fef2f24a4e9da12196a3a.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return update10fd0b36a14fef2f24a4e9da12196a3a.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:227
* @route '/products/{product}'
*/
update10fd0b36a14fef2f24a4e9da12196a3a.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update10fd0b36a14fef2f24a4e9da12196a3a.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:227
* @route '/products/{product}'
*/
const update10fd0b36a14fef2f24a4e9da12196a3aForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update10fd0b36a14fef2f24a4e9da12196a3a.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::update
* @see app/Http/Controllers/ProductController.php:227
* @route '/products/{product}'
*/
update10fd0b36a14fef2f24a4e9da12196a3aForm.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update10fd0b36a14fef2f24a4e9da12196a3a.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update10fd0b36a14fef2f24a4e9da12196a3a.form = update10fd0b36a14fef2f24a4e9da12196a3aForm

export const update = {
    '/api/products/{product}': update8b31a3148adac2aae83b33cd08a1abbb,
    '/products/{product}': update10fd0b36a14fef2f24a4e9da12196a3a,
}

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:265
* @route '/api/products/{product}'
*/
const destroy8b31a3148adac2aae83b33cd08a1abbb = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy8b31a3148adac2aae83b33cd08a1abbb.url(args, options),
    method: 'delete',
})

destroy8b31a3148adac2aae83b33cd08a1abbb.definition = {
    methods: ["delete"],
    url: '/api/products/{product}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:265
* @route '/api/products/{product}'
*/
destroy8b31a3148adac2aae83b33cd08a1abbb.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return destroy8b31a3148adac2aae83b33cd08a1abbb.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:265
* @route '/api/products/{product}'
*/
destroy8b31a3148adac2aae83b33cd08a1abbb.delete = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy8b31a3148adac2aae83b33cd08a1abbb.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:265
* @route '/api/products/{product}'
*/
const destroy8b31a3148adac2aae83b33cd08a1abbbForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy8b31a3148adac2aae83b33cd08a1abbb.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:265
* @route '/api/products/{product}'
*/
destroy8b31a3148adac2aae83b33cd08a1abbbForm.delete = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy8b31a3148adac2aae83b33cd08a1abbb.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy8b31a3148adac2aae83b33cd08a1abbb.form = destroy8b31a3148adac2aae83b33cd08a1abbbForm
/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:265
* @route '/products/{product}'
*/
const destroy10fd0b36a14fef2f24a4e9da12196a3a = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy10fd0b36a14fef2f24a4e9da12196a3a.url(args, options),
    method: 'delete',
})

destroy10fd0b36a14fef2f24a4e9da12196a3a.definition = {
    methods: ["delete"],
    url: '/products/{product}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:265
* @route '/products/{product}'
*/
destroy10fd0b36a14fef2f24a4e9da12196a3a.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return destroy10fd0b36a14fef2f24a4e9da12196a3a.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:265
* @route '/products/{product}'
*/
destroy10fd0b36a14fef2f24a4e9da12196a3a.delete = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy10fd0b36a14fef2f24a4e9da12196a3a.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:265
* @route '/products/{product}'
*/
const destroy10fd0b36a14fef2f24a4e9da12196a3aForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy10fd0b36a14fef2f24a4e9da12196a3a.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProductController::destroy
* @see app/Http/Controllers/ProductController.php:265
* @route '/products/{product}'
*/
destroy10fd0b36a14fef2f24a4e9da12196a3aForm.delete = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy10fd0b36a14fef2f24a4e9da12196a3a.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy10fd0b36a14fef2f24a4e9da12196a3a.form = destroy10fd0b36a14fef2f24a4e9da12196a3aForm

export const destroy = {
    '/api/products/{product}': destroy8b31a3148adac2aae83b33cd08a1abbb,
    '/products/{product}': destroy10fd0b36a14fef2f24a4e9da12196a3a,
}

const ProductController = { index, store, search, filterByCategory, featured, show, update, destroy }

export default ProductController