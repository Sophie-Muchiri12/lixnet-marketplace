import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/api/jobs'
*/
const index2cc35475395df7ee52a68f77bc5edccc = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index2cc35475395df7ee52a68f77bc5edccc.url(options),
    method: 'get',
})

index2cc35475395df7ee52a68f77bc5edccc.definition = {
    methods: ["get","head"],
    url: '/api/jobs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/api/jobs'
*/
index2cc35475395df7ee52a68f77bc5edccc.url = (options?: RouteQueryOptions) => {
    return index2cc35475395df7ee52a68f77bc5edccc.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/api/jobs'
*/
index2cc35475395df7ee52a68f77bc5edccc.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index2cc35475395df7ee52a68f77bc5edccc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/api/jobs'
*/
index2cc35475395df7ee52a68f77bc5edccc.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index2cc35475395df7ee52a68f77bc5edccc.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/api/jobs'
*/
const index2cc35475395df7ee52a68f77bc5edcccForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index2cc35475395df7ee52a68f77bc5edccc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/api/jobs'
*/
index2cc35475395df7ee52a68f77bc5edcccForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index2cc35475395df7ee52a68f77bc5edccc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/api/jobs'
*/
index2cc35475395df7ee52a68f77bc5edcccForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index2cc35475395df7ee52a68f77bc5edccc.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index2cc35475395df7ee52a68f77bc5edccc.form = index2cc35475395df7ee52a68f77bc5edcccForm
/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/jobs'
*/
const index1645ac25bf51cd2492a4911501274e26 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index1645ac25bf51cd2492a4911501274e26.url(options),
    method: 'get',
})

index1645ac25bf51cd2492a4911501274e26.definition = {
    methods: ["get","head"],
    url: '/jobs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/jobs'
*/
index1645ac25bf51cd2492a4911501274e26.url = (options?: RouteQueryOptions) => {
    return index1645ac25bf51cd2492a4911501274e26.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/jobs'
*/
index1645ac25bf51cd2492a4911501274e26.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index1645ac25bf51cd2492a4911501274e26.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/jobs'
*/
index1645ac25bf51cd2492a4911501274e26.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index1645ac25bf51cd2492a4911501274e26.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/jobs'
*/
const index1645ac25bf51cd2492a4911501274e26Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index1645ac25bf51cd2492a4911501274e26.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/jobs'
*/
index1645ac25bf51cd2492a4911501274e26Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index1645ac25bf51cd2492a4911501274e26.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::index
* @see app/Http/Controllers/JobController.php:15
* @route '/jobs'
*/
index1645ac25bf51cd2492a4911501274e26Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index1645ac25bf51cd2492a4911501274e26.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index1645ac25bf51cd2492a4911501274e26.form = index1645ac25bf51cd2492a4911501274e26Form

export const index = {
    '/api/jobs': index2cc35475395df7ee52a68f77bc5edccc,
    '/jobs': index1645ac25bf51cd2492a4911501274e26,
}

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/jobs/{job}'
*/
const showd2bf57321076699d9b5c650cbbcf3c77 = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showd2bf57321076699d9b5c650cbbcf3c77.url(args, options),
    method: 'get',
})

showd2bf57321076699d9b5c650cbbcf3c77.definition = {
    methods: ["get","head"],
    url: '/api/jobs/{job}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/jobs/{job}'
*/
showd2bf57321076699d9b5c650cbbcf3c77.url = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { job: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { job: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            job: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object'
        ? args.job.id
        : args.job,
    }

    return showd2bf57321076699d9b5c650cbbcf3c77.definition.url
            .replace('{job}', parsedArgs.job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/jobs/{job}'
*/
showd2bf57321076699d9b5c650cbbcf3c77.get = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showd2bf57321076699d9b5c650cbbcf3c77.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/jobs/{job}'
*/
showd2bf57321076699d9b5c650cbbcf3c77.head = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showd2bf57321076699d9b5c650cbbcf3c77.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/jobs/{job}'
*/
const showd2bf57321076699d9b5c650cbbcf3c77Form = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showd2bf57321076699d9b5c650cbbcf3c77.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/jobs/{job}'
*/
showd2bf57321076699d9b5c650cbbcf3c77Form.get = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showd2bf57321076699d9b5c650cbbcf3c77.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/jobs/{job}'
*/
showd2bf57321076699d9b5c650cbbcf3c77Form.head = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showd2bf57321076699d9b5c650cbbcf3c77.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showd2bf57321076699d9b5c650cbbcf3c77.form = showd2bf57321076699d9b5c650cbbcf3c77Form
/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/admin/jobs/{job}'
*/
const show1c54dc49496fcc5031e7037c7535f6c0 = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show1c54dc49496fcc5031e7037c7535f6c0.url(args, options),
    method: 'get',
})

show1c54dc49496fcc5031e7037c7535f6c0.definition = {
    methods: ["get","head"],
    url: '/api/admin/jobs/{job}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/admin/jobs/{job}'
*/
show1c54dc49496fcc5031e7037c7535f6c0.url = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { job: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { job: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            job: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object'
        ? args.job.id
        : args.job,
    }

    return show1c54dc49496fcc5031e7037c7535f6c0.definition.url
            .replace('{job}', parsedArgs.job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/admin/jobs/{job}'
*/
show1c54dc49496fcc5031e7037c7535f6c0.get = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show1c54dc49496fcc5031e7037c7535f6c0.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/admin/jobs/{job}'
*/
show1c54dc49496fcc5031e7037c7535f6c0.head = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show1c54dc49496fcc5031e7037c7535f6c0.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/admin/jobs/{job}'
*/
const show1c54dc49496fcc5031e7037c7535f6c0Form = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show1c54dc49496fcc5031e7037c7535f6c0.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/admin/jobs/{job}'
*/
show1c54dc49496fcc5031e7037c7535f6c0Form.get = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show1c54dc49496fcc5031e7037c7535f6c0.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/api/admin/jobs/{job}'
*/
show1c54dc49496fcc5031e7037c7535f6c0Form.head = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show1c54dc49496fcc5031e7037c7535f6c0.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show1c54dc49496fcc5031e7037c7535f6c0.form = show1c54dc49496fcc5031e7037c7535f6c0Form
/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/jobs/{job}'
*/
const show681d8640dded3de8d182be566dee1f15 = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show681d8640dded3de8d182be566dee1f15.url(args, options),
    method: 'get',
})

show681d8640dded3de8d182be566dee1f15.definition = {
    methods: ["get","head"],
    url: '/jobs/{job}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/jobs/{job}'
*/
show681d8640dded3de8d182be566dee1f15.url = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { job: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { job: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            job: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object'
        ? args.job.id
        : args.job,
    }

    return show681d8640dded3de8d182be566dee1f15.definition.url
            .replace('{job}', parsedArgs.job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/jobs/{job}'
*/
show681d8640dded3de8d182be566dee1f15.get = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show681d8640dded3de8d182be566dee1f15.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/jobs/{job}'
*/
show681d8640dded3de8d182be566dee1f15.head = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show681d8640dded3de8d182be566dee1f15.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/jobs/{job}'
*/
const show681d8640dded3de8d182be566dee1f15Form = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show681d8640dded3de8d182be566dee1f15.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/jobs/{job}'
*/
show681d8640dded3de8d182be566dee1f15Form.get = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show681d8640dded3de8d182be566dee1f15.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/jobs/{job}'
*/
show681d8640dded3de8d182be566dee1f15Form.head = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show681d8640dded3de8d182be566dee1f15.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show681d8640dded3de8d182be566dee1f15.form = show681d8640dded3de8d182be566dee1f15Form
/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/admin/jobs/{job}'
*/
const showbf3541014a0287b3dee88e232b5c1fe1 = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showbf3541014a0287b3dee88e232b5c1fe1.url(args, options),
    method: 'get',
})

showbf3541014a0287b3dee88e232b5c1fe1.definition = {
    methods: ["get","head"],
    url: '/admin/jobs/{job}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/admin/jobs/{job}'
*/
showbf3541014a0287b3dee88e232b5c1fe1.url = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { job: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { job: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            job: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object'
        ? args.job.id
        : args.job,
    }

    return showbf3541014a0287b3dee88e232b5c1fe1.definition.url
            .replace('{job}', parsedArgs.job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/admin/jobs/{job}'
*/
showbf3541014a0287b3dee88e232b5c1fe1.get = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showbf3541014a0287b3dee88e232b5c1fe1.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/admin/jobs/{job}'
*/
showbf3541014a0287b3dee88e232b5c1fe1.head = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showbf3541014a0287b3dee88e232b5c1fe1.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/admin/jobs/{job}'
*/
const showbf3541014a0287b3dee88e232b5c1fe1Form = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showbf3541014a0287b3dee88e232b5c1fe1.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/admin/jobs/{job}'
*/
showbf3541014a0287b3dee88e232b5c1fe1Form.get = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showbf3541014a0287b3dee88e232b5c1fe1.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::show
* @see app/Http/Controllers/JobController.php:71
* @route '/admin/jobs/{job}'
*/
showbf3541014a0287b3dee88e232b5c1fe1Form.head = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: showbf3541014a0287b3dee88e232b5c1fe1.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

showbf3541014a0287b3dee88e232b5c1fe1.form = showbf3541014a0287b3dee88e232b5c1fe1Form

export const show = {
    '/api/jobs/{job}': showd2bf57321076699d9b5c650cbbcf3c77,
    '/api/admin/jobs/{job}': show1c54dc49496fcc5031e7037c7535f6c0,
    '/jobs/{job}': show681d8640dded3de8d182be566dee1f15,
    '/admin/jobs/{job}': showbf3541014a0287b3dee88e232b5c1fe1,
}

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/api/admin/jobs'
*/
const adminIndexaa7524f3e27665927ef3db624fd3432d = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndexaa7524f3e27665927ef3db624fd3432d.url(options),
    method: 'get',
})

adminIndexaa7524f3e27665927ef3db624fd3432d.definition = {
    methods: ["get","head"],
    url: '/api/admin/jobs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/api/admin/jobs'
*/
adminIndexaa7524f3e27665927ef3db624fd3432d.url = (options?: RouteQueryOptions) => {
    return adminIndexaa7524f3e27665927ef3db624fd3432d.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/api/admin/jobs'
*/
adminIndexaa7524f3e27665927ef3db624fd3432d.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndexaa7524f3e27665927ef3db624fd3432d.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/api/admin/jobs'
*/
adminIndexaa7524f3e27665927ef3db624fd3432d.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminIndexaa7524f3e27665927ef3db624fd3432d.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/api/admin/jobs'
*/
const adminIndexaa7524f3e27665927ef3db624fd3432dForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: adminIndexaa7524f3e27665927ef3db624fd3432d.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/api/admin/jobs'
*/
adminIndexaa7524f3e27665927ef3db624fd3432dForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: adminIndexaa7524f3e27665927ef3db624fd3432d.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/api/admin/jobs'
*/
adminIndexaa7524f3e27665927ef3db624fd3432dForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: adminIndexaa7524f3e27665927ef3db624fd3432d.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

adminIndexaa7524f3e27665927ef3db624fd3432d.form = adminIndexaa7524f3e27665927ef3db624fd3432dForm
/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/admin/jobs'
*/
const adminIndexf86e52e03687bafac0030683da2b17bf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndexf86e52e03687bafac0030683da2b17bf.url(options),
    method: 'get',
})

adminIndexf86e52e03687bafac0030683da2b17bf.definition = {
    methods: ["get","head"],
    url: '/admin/jobs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/admin/jobs'
*/
adminIndexf86e52e03687bafac0030683da2b17bf.url = (options?: RouteQueryOptions) => {
    return adminIndexf86e52e03687bafac0030683da2b17bf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/admin/jobs'
*/
adminIndexf86e52e03687bafac0030683da2b17bf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndexf86e52e03687bafac0030683da2b17bf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/admin/jobs'
*/
adminIndexf86e52e03687bafac0030683da2b17bf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminIndexf86e52e03687bafac0030683da2b17bf.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/admin/jobs'
*/
const adminIndexf86e52e03687bafac0030683da2b17bfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: adminIndexf86e52e03687bafac0030683da2b17bf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/admin/jobs'
*/
adminIndexf86e52e03687bafac0030683da2b17bfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: adminIndexf86e52e03687bafac0030683da2b17bf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JobController::adminIndex
* @see app/Http/Controllers/JobController.php:139
* @route '/admin/jobs'
*/
adminIndexf86e52e03687bafac0030683da2b17bfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: adminIndexf86e52e03687bafac0030683da2b17bf.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

adminIndexf86e52e03687bafac0030683da2b17bf.form = adminIndexf86e52e03687bafac0030683da2b17bfForm

export const adminIndex = {
    '/api/admin/jobs': adminIndexaa7524f3e27665927ef3db624fd3432d,
    '/admin/jobs': adminIndexf86e52e03687bafac0030683da2b17bf,
}

/**
* @see \App\Http\Controllers\JobController::store
* @see app/Http/Controllers/JobController.php:36
* @route '/api/admin/jobs'
*/
const storeaa7524f3e27665927ef3db624fd3432d = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeaa7524f3e27665927ef3db624fd3432d.url(options),
    method: 'post',
})

storeaa7524f3e27665927ef3db624fd3432d.definition = {
    methods: ["post"],
    url: '/api/admin/jobs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\JobController::store
* @see app/Http/Controllers/JobController.php:36
* @route '/api/admin/jobs'
*/
storeaa7524f3e27665927ef3db624fd3432d.url = (options?: RouteQueryOptions) => {
    return storeaa7524f3e27665927ef3db624fd3432d.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::store
* @see app/Http/Controllers/JobController.php:36
* @route '/api/admin/jobs'
*/
storeaa7524f3e27665927ef3db624fd3432d.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeaa7524f3e27665927ef3db624fd3432d.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobController::store
* @see app/Http/Controllers/JobController.php:36
* @route '/api/admin/jobs'
*/
const storeaa7524f3e27665927ef3db624fd3432dForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeaa7524f3e27665927ef3db624fd3432d.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobController::store
* @see app/Http/Controllers/JobController.php:36
* @route '/api/admin/jobs'
*/
storeaa7524f3e27665927ef3db624fd3432dForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeaa7524f3e27665927ef3db624fd3432d.url(options),
    method: 'post',
})

storeaa7524f3e27665927ef3db624fd3432d.form = storeaa7524f3e27665927ef3db624fd3432dForm
/**
* @see \App\Http\Controllers\JobController::store
* @see app/Http/Controllers/JobController.php:36
* @route '/admin/jobs'
*/
const storef86e52e03687bafac0030683da2b17bf = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storef86e52e03687bafac0030683da2b17bf.url(options),
    method: 'post',
})

storef86e52e03687bafac0030683da2b17bf.definition = {
    methods: ["post"],
    url: '/admin/jobs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\JobController::store
* @see app/Http/Controllers/JobController.php:36
* @route '/admin/jobs'
*/
storef86e52e03687bafac0030683da2b17bf.url = (options?: RouteQueryOptions) => {
    return storef86e52e03687bafac0030683da2b17bf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::store
* @see app/Http/Controllers/JobController.php:36
* @route '/admin/jobs'
*/
storef86e52e03687bafac0030683da2b17bf.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storef86e52e03687bafac0030683da2b17bf.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobController::store
* @see app/Http/Controllers/JobController.php:36
* @route '/admin/jobs'
*/
const storef86e52e03687bafac0030683da2b17bfForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storef86e52e03687bafac0030683da2b17bf.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobController::store
* @see app/Http/Controllers/JobController.php:36
* @route '/admin/jobs'
*/
storef86e52e03687bafac0030683da2b17bfForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storef86e52e03687bafac0030683da2b17bf.url(options),
    method: 'post',
})

storef86e52e03687bafac0030683da2b17bf.form = storef86e52e03687bafac0030683da2b17bfForm

export const store = {
    '/api/admin/jobs': storeaa7524f3e27665927ef3db624fd3432d,
    '/admin/jobs': storef86e52e03687bafac0030683da2b17bf,
}

/**
* @see \App\Http\Controllers\JobController::update
* @see app/Http/Controllers/JobController.php:91
* @route '/api/admin/jobs/{job}'
*/
const update1c54dc49496fcc5031e7037c7535f6c0 = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update1c54dc49496fcc5031e7037c7535f6c0.url(args, options),
    method: 'put',
})

update1c54dc49496fcc5031e7037c7535f6c0.definition = {
    methods: ["put"],
    url: '/api/admin/jobs/{job}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\JobController::update
* @see app/Http/Controllers/JobController.php:91
* @route '/api/admin/jobs/{job}'
*/
update1c54dc49496fcc5031e7037c7535f6c0.url = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { job: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { job: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            job: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object'
        ? args.job.id
        : args.job,
    }

    return update1c54dc49496fcc5031e7037c7535f6c0.definition.url
            .replace('{job}', parsedArgs.job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::update
* @see app/Http/Controllers/JobController.php:91
* @route '/api/admin/jobs/{job}'
*/
update1c54dc49496fcc5031e7037c7535f6c0.put = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update1c54dc49496fcc5031e7037c7535f6c0.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\JobController::update
* @see app/Http/Controllers/JobController.php:91
* @route '/api/admin/jobs/{job}'
*/
const update1c54dc49496fcc5031e7037c7535f6c0Form = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update1c54dc49496fcc5031e7037c7535f6c0.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobController::update
* @see app/Http/Controllers/JobController.php:91
* @route '/api/admin/jobs/{job}'
*/
update1c54dc49496fcc5031e7037c7535f6c0Form.put = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update1c54dc49496fcc5031e7037c7535f6c0.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update1c54dc49496fcc5031e7037c7535f6c0.form = update1c54dc49496fcc5031e7037c7535f6c0Form
/**
* @see \App\Http\Controllers\JobController::update
* @see app/Http/Controllers/JobController.php:91
* @route '/admin/jobs/{job}'
*/
const updatebf3541014a0287b3dee88e232b5c1fe1 = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatebf3541014a0287b3dee88e232b5c1fe1.url(args, options),
    method: 'put',
})

updatebf3541014a0287b3dee88e232b5c1fe1.definition = {
    methods: ["put"],
    url: '/admin/jobs/{job}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\JobController::update
* @see app/Http/Controllers/JobController.php:91
* @route '/admin/jobs/{job}'
*/
updatebf3541014a0287b3dee88e232b5c1fe1.url = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { job: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { job: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            job: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object'
        ? args.job.id
        : args.job,
    }

    return updatebf3541014a0287b3dee88e232b5c1fe1.definition.url
            .replace('{job}', parsedArgs.job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::update
* @see app/Http/Controllers/JobController.php:91
* @route '/admin/jobs/{job}'
*/
updatebf3541014a0287b3dee88e232b5c1fe1.put = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatebf3541014a0287b3dee88e232b5c1fe1.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\JobController::update
* @see app/Http/Controllers/JobController.php:91
* @route '/admin/jobs/{job}'
*/
const updatebf3541014a0287b3dee88e232b5c1fe1Form = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updatebf3541014a0287b3dee88e232b5c1fe1.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobController::update
* @see app/Http/Controllers/JobController.php:91
* @route '/admin/jobs/{job}'
*/
updatebf3541014a0287b3dee88e232b5c1fe1Form.put = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updatebf3541014a0287b3dee88e232b5c1fe1.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updatebf3541014a0287b3dee88e232b5c1fe1.form = updatebf3541014a0287b3dee88e232b5c1fe1Form

export const update = {
    '/api/admin/jobs/{job}': update1c54dc49496fcc5031e7037c7535f6c0,
    '/admin/jobs/{job}': updatebf3541014a0287b3dee88e232b5c1fe1,
}

/**
* @see \App\Http\Controllers\JobController::destroy
* @see app/Http/Controllers/JobController.php:126
* @route '/api/admin/jobs/{job}'
*/
const destroy1c54dc49496fcc5031e7037c7535f6c0 = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy1c54dc49496fcc5031e7037c7535f6c0.url(args, options),
    method: 'delete',
})

destroy1c54dc49496fcc5031e7037c7535f6c0.definition = {
    methods: ["delete"],
    url: '/api/admin/jobs/{job}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\JobController::destroy
* @see app/Http/Controllers/JobController.php:126
* @route '/api/admin/jobs/{job}'
*/
destroy1c54dc49496fcc5031e7037c7535f6c0.url = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { job: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { job: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            job: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object'
        ? args.job.id
        : args.job,
    }

    return destroy1c54dc49496fcc5031e7037c7535f6c0.definition.url
            .replace('{job}', parsedArgs.job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::destroy
* @see app/Http/Controllers/JobController.php:126
* @route '/api/admin/jobs/{job}'
*/
destroy1c54dc49496fcc5031e7037c7535f6c0.delete = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy1c54dc49496fcc5031e7037c7535f6c0.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\JobController::destroy
* @see app/Http/Controllers/JobController.php:126
* @route '/api/admin/jobs/{job}'
*/
const destroy1c54dc49496fcc5031e7037c7535f6c0Form = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy1c54dc49496fcc5031e7037c7535f6c0.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobController::destroy
* @see app/Http/Controllers/JobController.php:126
* @route '/api/admin/jobs/{job}'
*/
destroy1c54dc49496fcc5031e7037c7535f6c0Form.delete = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy1c54dc49496fcc5031e7037c7535f6c0.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy1c54dc49496fcc5031e7037c7535f6c0.form = destroy1c54dc49496fcc5031e7037c7535f6c0Form
/**
* @see \App\Http\Controllers\JobController::destroy
* @see app/Http/Controllers/JobController.php:126
* @route '/admin/jobs/{job}'
*/
const destroybf3541014a0287b3dee88e232b5c1fe1 = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroybf3541014a0287b3dee88e232b5c1fe1.url(args, options),
    method: 'delete',
})

destroybf3541014a0287b3dee88e232b5c1fe1.definition = {
    methods: ["delete"],
    url: '/admin/jobs/{job}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\JobController::destroy
* @see app/Http/Controllers/JobController.php:126
* @route '/admin/jobs/{job}'
*/
destroybf3541014a0287b3dee88e232b5c1fe1.url = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { job: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { job: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            job: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object'
        ? args.job.id
        : args.job,
    }

    return destroybf3541014a0287b3dee88e232b5c1fe1.definition.url
            .replace('{job}', parsedArgs.job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\JobController::destroy
* @see app/Http/Controllers/JobController.php:126
* @route '/admin/jobs/{job}'
*/
destroybf3541014a0287b3dee88e232b5c1fe1.delete = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroybf3541014a0287b3dee88e232b5c1fe1.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\JobController::destroy
* @see app/Http/Controllers/JobController.php:126
* @route '/admin/jobs/{job}'
*/
const destroybf3541014a0287b3dee88e232b5c1fe1Form = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroybf3541014a0287b3dee88e232b5c1fe1.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JobController::destroy
* @see app/Http/Controllers/JobController.php:126
* @route '/admin/jobs/{job}'
*/
destroybf3541014a0287b3dee88e232b5c1fe1Form.delete = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroybf3541014a0287b3dee88e232b5c1fe1.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroybf3541014a0287b3dee88e232b5c1fe1.form = destroybf3541014a0287b3dee88e232b5c1fe1Form

export const destroy = {
    '/api/admin/jobs/{job}': destroy1c54dc49496fcc5031e7037c7535f6c0,
    '/admin/jobs/{job}': destroybf3541014a0287b3dee88e232b5c1fe1,
}

const JobController = { index, show, adminIndex, store, update, destroy }

export default JobController