import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
const getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.url(options),
    method: 'get',
})

getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.definition = {
    methods: ["get","head"],
    url: '/api/sso/available-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.url = (options?: RouteQueryOptions) => {
    return getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
const getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396fForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396fForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396fForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f.form = getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396fForm
/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
const getAvailableProductse22a0caa713dd5e4f3a64156974a744c = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableProductse22a0caa713dd5e4f3a64156974a744c.url(options),
    method: 'get',
})

getAvailableProductse22a0caa713dd5e4f3a64156974a744c.definition = {
    methods: ["get","head"],
    url: '/sso/available-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
getAvailableProductse22a0caa713dd5e4f3a64156974a744c.url = (options?: RouteQueryOptions) => {
    return getAvailableProductse22a0caa713dd5e4f3a64156974a744c.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
getAvailableProductse22a0caa713dd5e4f3a64156974a744c.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableProductse22a0caa713dd5e4f3a64156974a744c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
getAvailableProductse22a0caa713dd5e4f3a64156974a744c.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAvailableProductse22a0caa713dd5e4f3a64156974a744c.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
const getAvailableProductse22a0caa713dd5e4f3a64156974a744cForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAvailableProductse22a0caa713dd5e4f3a64156974a744c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
getAvailableProductse22a0caa713dd5e4f3a64156974a744cForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAvailableProductse22a0caa713dd5e4f3a64156974a744c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getAvailableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
getAvailableProductse22a0caa713dd5e4f3a64156974a744cForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAvailableProductse22a0caa713dd5e4f3a64156974a744c.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getAvailableProductse22a0caa713dd5e4f3a64156974a744c.form = getAvailableProductse22a0caa713dd5e4f3a64156974a744cForm

export const getAvailableProducts = {
    '/api/sso/available-products': getAvailableProductsd5ffe0aed1e802dc032fb08a88a0396f,
    '/sso/available-products': getAvailableProductse22a0caa713dd5e4f3a64156974a744c,
}

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
const getMySubscriptions583281ee9f502398457fe3ef4a595e85 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMySubscriptions583281ee9f502398457fe3ef4a595e85.url(options),
    method: 'get',
})

getMySubscriptions583281ee9f502398457fe3ef4a595e85.definition = {
    methods: ["get","head"],
    url: '/api/sso/my-subscriptions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
getMySubscriptions583281ee9f502398457fe3ef4a595e85.url = (options?: RouteQueryOptions) => {
    return getMySubscriptions583281ee9f502398457fe3ef4a595e85.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
getMySubscriptions583281ee9f502398457fe3ef4a595e85.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMySubscriptions583281ee9f502398457fe3ef4a595e85.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
getMySubscriptions583281ee9f502398457fe3ef4a595e85.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getMySubscriptions583281ee9f502398457fe3ef4a595e85.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
const getMySubscriptions583281ee9f502398457fe3ef4a595e85Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMySubscriptions583281ee9f502398457fe3ef4a595e85.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
getMySubscriptions583281ee9f502398457fe3ef4a595e85Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMySubscriptions583281ee9f502398457fe3ef4a595e85.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
getMySubscriptions583281ee9f502398457fe3ef4a595e85Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMySubscriptions583281ee9f502398457fe3ef4a595e85.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getMySubscriptions583281ee9f502398457fe3ef4a595e85.form = getMySubscriptions583281ee9f502398457fe3ef4a595e85Form
/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
const getMySubscriptions066d2a75e28341d9dd0c599f94e760e3 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.url(options),
    method: 'get',
})

getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.definition = {
    methods: ["get","head"],
    url: '/sso/my-subscriptions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.url = (options?: RouteQueryOptions) => {
    return getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
const getMySubscriptions066d2a75e28341d9dd0c599f94e760e3Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
getMySubscriptions066d2a75e28341d9dd0c599f94e760e3Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getMySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
getMySubscriptions066d2a75e28341d9dd0c599f94e760e3Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getMySubscriptions066d2a75e28341d9dd0c599f94e760e3.form = getMySubscriptions066d2a75e28341d9dd0c599f94e760e3Form

export const getMySubscriptions = {
    '/api/sso/my-subscriptions': getMySubscriptions583281ee9f502398457fe3ef4a595e85,
    '/sso/my-subscriptions': getMySubscriptions066d2a75e28341d9dd0c599f94e760e3,
}

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
const getProductDetails19c9335540c591929b255d13e555b458 = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProductDetails19c9335540c591929b255d13e555b458.url(args, options),
    method: 'get',
})

getProductDetails19c9335540c591929b255d13e555b458.definition = {
    methods: ["get","head"],
    url: '/api/sso/product/{productId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
getProductDetails19c9335540c591929b255d13e555b458.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return getProductDetails19c9335540c591929b255d13e555b458.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
getProductDetails19c9335540c591929b255d13e555b458.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProductDetails19c9335540c591929b255d13e555b458.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
getProductDetails19c9335540c591929b255d13e555b458.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getProductDetails19c9335540c591929b255d13e555b458.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
const getProductDetails19c9335540c591929b255d13e555b458Form = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductDetails19c9335540c591929b255d13e555b458.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
getProductDetails19c9335540c591929b255d13e555b458Form.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductDetails19c9335540c591929b255d13e555b458.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
getProductDetails19c9335540c591929b255d13e555b458Form.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductDetails19c9335540c591929b255d13e555b458.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getProductDetails19c9335540c591929b255d13e555b458.form = getProductDetails19c9335540c591929b255d13e555b458Form
/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
const getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.url(args, options),
    method: 'get',
})

getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.definition = {
    methods: ["get","head"],
    url: '/sso/product/{productId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
const getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2eForm = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2eForm.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::getProductDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2eForm.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e.form = getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2eForm

export const getProductDetails = {
    '/api/sso/product/{productId}': getProductDetails19c9335540c591929b255d13e555b458,
    '/sso/product/{productId}': getProductDetails7da803d7a81da9d7d5b23a9d1bb79f2e,
}

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
const redirectToProduct829f0d952631561e01b56f186f95a788 = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToProduct829f0d952631561e01b56f186f95a788.url(args, options),
    method: 'get',
})

redirectToProduct829f0d952631561e01b56f186f95a788.definition = {
    methods: ["get","head"],
    url: '/api/sso/redirect/{productId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectToProduct829f0d952631561e01b56f186f95a788.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return redirectToProduct829f0d952631561e01b56f186f95a788.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectToProduct829f0d952631561e01b56f186f95a788.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToProduct829f0d952631561e01b56f186f95a788.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectToProduct829f0d952631561e01b56f186f95a788.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirectToProduct829f0d952631561e01b56f186f95a788.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
const redirectToProduct829f0d952631561e01b56f186f95a788Form = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectToProduct829f0d952631561e01b56f186f95a788.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectToProduct829f0d952631561e01b56f186f95a788Form.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectToProduct829f0d952631561e01b56f186f95a788.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectToProduct829f0d952631561e01b56f186f95a788Form.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectToProduct829f0d952631561e01b56f186f95a788.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

redirectToProduct829f0d952631561e01b56f186f95a788.form = redirectToProduct829f0d952631561e01b56f186f95a788Form
/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
const redirectToProduct829f0d952631561e01b56f186f95a788 = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: redirectToProduct829f0d952631561e01b56f186f95a788.url(args, options),
    method: 'post',
})

redirectToProduct829f0d952631561e01b56f186f95a788.definition = {
    methods: ["post"],
    url: '/api/sso/redirect/{productId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectToProduct829f0d952631561e01b56f186f95a788.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return redirectToProduct829f0d952631561e01b56f186f95a788.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectToProduct829f0d952631561e01b56f186f95a788.post = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: redirectToProduct829f0d952631561e01b56f186f95a788.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
const redirectToProduct829f0d952631561e01b56f186f95a788Form = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: redirectToProduct829f0d952631561e01b56f186f95a788.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectToProduct829f0d952631561e01b56f186f95a788Form.post = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: redirectToProduct829f0d952631561e01b56f186f95a788.url(args, options),
    method: 'post',
})

redirectToProduct829f0d952631561e01b56f186f95a788.form = redirectToProduct829f0d952631561e01b56f186f95a788Form
/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
const redirectToProduct039fb65ec29a5b22437bfa7757d02f5b = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url(args, options),
    method: 'get',
})

redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.definition = {
    methods: ["get","head"],
    url: '/sso/redirect/{productId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
const redirectToProduct039fb65ec29a5b22437bfa7757d02f5bForm = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectToProduct039fb65ec29a5b22437bfa7757d02f5bForm.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectToProduct039fb65ec29a5b22437bfa7757d02f5bForm.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.form = redirectToProduct039fb65ec29a5b22437bfa7757d02f5bForm
/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
const redirectToProduct039fb65ec29a5b22437bfa7757d02f5b = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url(args, options),
    method: 'post',
})

redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.definition = {
    methods: ["post"],
    url: '/sso/redirect/{productId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.post = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
const redirectToProduct039fb65ec29a5b22437bfa7757d02f5bForm = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectToProduct
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectToProduct039fb65ec29a5b22437bfa7757d02f5bForm.post = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.url(args, options),
    method: 'post',
})

redirectToProduct039fb65ec29a5b22437bfa7757d02f5b.form = redirectToProduct039fb65ec29a5b22437bfa7757d02f5bForm

export const redirectToProduct = {
    '/api/sso/redirect/{productId}': redirectToProduct829f0d952631561e01b56f186f95a788,
    '/api/sso/redirect/{productId}': redirectToProduct829f0d952631561e01b56f186f95a788,
    '/sso/redirect/{productId}': redirectToProduct039fb65ec29a5b22437bfa7757d02f5b,
    '/sso/redirect/{productId}': redirectToProduct039fb65ec29a5b22437bfa7757d02f5b,
}

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/api/sso/validate-token'
*/
const validateTokenf49d2725ca0ca1e38f419c238d4b3dee = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validateTokenf49d2725ca0ca1e38f419c238d4b3dee.url(options),
    method: 'post',
})

validateTokenf49d2725ca0ca1e38f419c238d4b3dee.definition = {
    methods: ["post"],
    url: '/api/sso/validate-token',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/api/sso/validate-token'
*/
validateTokenf49d2725ca0ca1e38f419c238d4b3dee.url = (options?: RouteQueryOptions) => {
    return validateTokenf49d2725ca0ca1e38f419c238d4b3dee.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/api/sso/validate-token'
*/
validateTokenf49d2725ca0ca1e38f419c238d4b3dee.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validateTokenf49d2725ca0ca1e38f419c238d4b3dee.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/api/sso/validate-token'
*/
const validateTokenf49d2725ca0ca1e38f419c238d4b3deeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: validateTokenf49d2725ca0ca1e38f419c238d4b3dee.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/api/sso/validate-token'
*/
validateTokenf49d2725ca0ca1e38f419c238d4b3deeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: validateTokenf49d2725ca0ca1e38f419c238d4b3dee.url(options),
    method: 'post',
})

validateTokenf49d2725ca0ca1e38f419c238d4b3dee.form = validateTokenf49d2725ca0ca1e38f419c238d4b3deeForm
/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/sso/validate-token'
*/
const validateTokenb96d16d6f008eb8464b572ca7ae8fd19 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validateTokenb96d16d6f008eb8464b572ca7ae8fd19.url(options),
    method: 'post',
})

validateTokenb96d16d6f008eb8464b572ca7ae8fd19.definition = {
    methods: ["post"],
    url: '/sso/validate-token',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/sso/validate-token'
*/
validateTokenb96d16d6f008eb8464b572ca7ae8fd19.url = (options?: RouteQueryOptions) => {
    return validateTokenb96d16d6f008eb8464b572ca7ae8fd19.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/sso/validate-token'
*/
validateTokenb96d16d6f008eb8464b572ca7ae8fd19.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validateTokenb96d16d6f008eb8464b572ca7ae8fd19.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/sso/validate-token'
*/
const validateTokenb96d16d6f008eb8464b572ca7ae8fd19Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: validateTokenb96d16d6f008eb8464b572ca7ae8fd19.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/sso/validate-token'
*/
validateTokenb96d16d6f008eb8464b572ca7ae8fd19Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: validateTokenb96d16d6f008eb8464b572ca7ae8fd19.url(options),
    method: 'post',
})

validateTokenb96d16d6f008eb8464b572ca7ae8fd19.form = validateTokenb96d16d6f008eb8464b572ca7ae8fd19Form

export const validateToken = {
    '/api/sso/validate-token': validateTokenf49d2725ca0ca1e38f419c238d4b3dee,
    '/sso/validate-token': validateTokenb96d16d6f008eb8464b572ca7ae8fd19,
}

const SSOProductController = { getAvailableProducts, getMySubscriptions, getProductDetails, redirectToProduct, validateToken }

export default SSOProductController