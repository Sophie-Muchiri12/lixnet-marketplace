import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/api/user/profile'
*/
const getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url(options),
    method: 'get',
})

getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.definition = {
    methods: ["get","head"],
    url: '/api/user/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/api/user/profile'
*/
getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url = (options?: RouteQueryOptions) => {
    return getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/api/user/profile'
*/
getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/api/user/profile'
*/
getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/api/user/profile'
*/
const getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/api/user/profile'
*/
getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/api/user/profile'
*/
getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.form = getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4Form
/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/user/profile'
*/
const getProfile24336b274ff0444f46cda8a0a44a347b = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProfile24336b274ff0444f46cda8a0a44a347b.url(options),
    method: 'get',
})

getProfile24336b274ff0444f46cda8a0a44a347b.definition = {
    methods: ["get","head"],
    url: '/user/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/user/profile'
*/
getProfile24336b274ff0444f46cda8a0a44a347b.url = (options?: RouteQueryOptions) => {
    return getProfile24336b274ff0444f46cda8a0a44a347b.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/user/profile'
*/
getProfile24336b274ff0444f46cda8a0a44a347b.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProfile24336b274ff0444f46cda8a0a44a347b.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/user/profile'
*/
getProfile24336b274ff0444f46cda8a0a44a347b.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getProfile24336b274ff0444f46cda8a0a44a347b.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/user/profile'
*/
const getProfile24336b274ff0444f46cda8a0a44a347bForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProfile24336b274ff0444f46cda8a0a44a347b.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/user/profile'
*/
getProfile24336b274ff0444f46cda8a0a44a347bForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProfile24336b274ff0444f46cda8a0a44a347b.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getProfile
* @see app/Http/Controllers/UserController.php:21
* @route '/user/profile'
*/
getProfile24336b274ff0444f46cda8a0a44a347bForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProfile24336b274ff0444f46cda8a0a44a347b.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getProfile24336b274ff0444f46cda8a0a44a347b.form = getProfile24336b274ff0444f46cda8a0a44a347bForm

export const getProfile = {
    '/api/user/profile': getProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4,
    '/user/profile': getProfile24336b274ff0444f46cda8a0a44a347b,
}

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:59
* @route '/api/user/profile'
*/
const updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4 = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url(options),
    method: 'put',
})

updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.definition = {
    methods: ["put"],
    url: '/api/user/profile',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:59
* @route '/api/user/profile'
*/
updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url = (options?: RouteQueryOptions) => {
    return updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:59
* @route '/api/user/profile'
*/
updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:59
* @route '/api/user/profile'
*/
const updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:59
* @route '/api/user/profile'
*/
updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4Form.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4.form = updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4Form
/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:59
* @route '/user/profile'
*/
const updateProfile24336b274ff0444f46cda8a0a44a347b = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProfile24336b274ff0444f46cda8a0a44a347b.url(options),
    method: 'put',
})

updateProfile24336b274ff0444f46cda8a0a44a347b.definition = {
    methods: ["put"],
    url: '/user/profile',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:59
* @route '/user/profile'
*/
updateProfile24336b274ff0444f46cda8a0a44a347b.url = (options?: RouteQueryOptions) => {
    return updateProfile24336b274ff0444f46cda8a0a44a347b.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:59
* @route '/user/profile'
*/
updateProfile24336b274ff0444f46cda8a0a44a347b.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProfile24336b274ff0444f46cda8a0a44a347b.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:59
* @route '/user/profile'
*/
const updateProfile24336b274ff0444f46cda8a0a44a347bForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateProfile24336b274ff0444f46cda8a0a44a347b.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:59
* @route '/user/profile'
*/
updateProfile24336b274ff0444f46cda8a0a44a347bForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateProfile24336b274ff0444f46cda8a0a44a347b.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateProfile24336b274ff0444f46cda8a0a44a347b.form = updateProfile24336b274ff0444f46cda8a0a44a347bForm

export const updateProfile = {
    '/api/user/profile': updateProfile2f492d1ee1357d6e8dbdc39fbbcfc8f4,
    '/user/profile': updateProfile24336b274ff0444f46cda8a0a44a347b,
}

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/api/user/summary'
*/
const getUserSummary973e5867c8a18342159b5b334fb5aeea = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserSummary973e5867c8a18342159b5b334fb5aeea.url(options),
    method: 'get',
})

getUserSummary973e5867c8a18342159b5b334fb5aeea.definition = {
    methods: ["get","head"],
    url: '/api/user/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/api/user/summary'
*/
getUserSummary973e5867c8a18342159b5b334fb5aeea.url = (options?: RouteQueryOptions) => {
    return getUserSummary973e5867c8a18342159b5b334fb5aeea.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/api/user/summary'
*/
getUserSummary973e5867c8a18342159b5b334fb5aeea.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserSummary973e5867c8a18342159b5b334fb5aeea.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/api/user/summary'
*/
getUserSummary973e5867c8a18342159b5b334fb5aeea.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getUserSummary973e5867c8a18342159b5b334fb5aeea.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/api/user/summary'
*/
const getUserSummary973e5867c8a18342159b5b334fb5aeeaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSummary973e5867c8a18342159b5b334fb5aeea.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/api/user/summary'
*/
getUserSummary973e5867c8a18342159b5b334fb5aeeaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSummary973e5867c8a18342159b5b334fb5aeea.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/api/user/summary'
*/
getUserSummary973e5867c8a18342159b5b334fb5aeeaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSummary973e5867c8a18342159b5b334fb5aeea.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getUserSummary973e5867c8a18342159b5b334fb5aeea.form = getUserSummary973e5867c8a18342159b5b334fb5aeeaForm
/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/user/summary'
*/
const getUserSummary6e06f5e530d7a470515edcee1646cfbc = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserSummary6e06f5e530d7a470515edcee1646cfbc.url(options),
    method: 'get',
})

getUserSummary6e06f5e530d7a470515edcee1646cfbc.definition = {
    methods: ["get","head"],
    url: '/user/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/user/summary'
*/
getUserSummary6e06f5e530d7a470515edcee1646cfbc.url = (options?: RouteQueryOptions) => {
    return getUserSummary6e06f5e530d7a470515edcee1646cfbc.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/user/summary'
*/
getUserSummary6e06f5e530d7a470515edcee1646cfbc.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserSummary6e06f5e530d7a470515edcee1646cfbc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/user/summary'
*/
getUserSummary6e06f5e530d7a470515edcee1646cfbc.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getUserSummary6e06f5e530d7a470515edcee1646cfbc.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/user/summary'
*/
const getUserSummary6e06f5e530d7a470515edcee1646cfbcForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSummary6e06f5e530d7a470515edcee1646cfbc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/user/summary'
*/
getUserSummary6e06f5e530d7a470515edcee1646cfbcForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSummary6e06f5e530d7a470515edcee1646cfbc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserSummary
* @see app/Http/Controllers/UserController.php:121
* @route '/user/summary'
*/
getUserSummary6e06f5e530d7a470515edcee1646cfbcForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserSummary6e06f5e530d7a470515edcee1646cfbc.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getUserSummary6e06f5e530d7a470515edcee1646cfbc.form = getUserSummary6e06f5e530d7a470515edcee1646cfbcForm

export const getUserSummary = {
    '/api/user/summary': getUserSummary973e5867c8a18342159b5b334fb5aeea,
    '/user/summary': getUserSummary6e06f5e530d7a470515edcee1646cfbc,
}

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/api/user/stats'
*/
const getUserStats9cde6edbf35d22a47518e36bc4756afc = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserStats9cde6edbf35d22a47518e36bc4756afc.url(options),
    method: 'get',
})

getUserStats9cde6edbf35d22a47518e36bc4756afc.definition = {
    methods: ["get","head"],
    url: '/api/user/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/api/user/stats'
*/
getUserStats9cde6edbf35d22a47518e36bc4756afc.url = (options?: RouteQueryOptions) => {
    return getUserStats9cde6edbf35d22a47518e36bc4756afc.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/api/user/stats'
*/
getUserStats9cde6edbf35d22a47518e36bc4756afc.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserStats9cde6edbf35d22a47518e36bc4756afc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/api/user/stats'
*/
getUserStats9cde6edbf35d22a47518e36bc4756afc.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getUserStats9cde6edbf35d22a47518e36bc4756afc.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/api/user/stats'
*/
const getUserStats9cde6edbf35d22a47518e36bc4756afcForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserStats9cde6edbf35d22a47518e36bc4756afc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/api/user/stats'
*/
getUserStats9cde6edbf35d22a47518e36bc4756afcForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserStats9cde6edbf35d22a47518e36bc4756afc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/api/user/stats'
*/
getUserStats9cde6edbf35d22a47518e36bc4756afcForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserStats9cde6edbf35d22a47518e36bc4756afc.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getUserStats9cde6edbf35d22a47518e36bc4756afc.form = getUserStats9cde6edbf35d22a47518e36bc4756afcForm
/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/user/stats'
*/
const getUserStatsb3f5022ad593210a802c86cd06ae4165 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserStatsb3f5022ad593210a802c86cd06ae4165.url(options),
    method: 'get',
})

getUserStatsb3f5022ad593210a802c86cd06ae4165.definition = {
    methods: ["get","head"],
    url: '/user/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/user/stats'
*/
getUserStatsb3f5022ad593210a802c86cd06ae4165.url = (options?: RouteQueryOptions) => {
    return getUserStatsb3f5022ad593210a802c86cd06ae4165.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/user/stats'
*/
getUserStatsb3f5022ad593210a802c86cd06ae4165.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserStatsb3f5022ad593210a802c86cd06ae4165.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/user/stats'
*/
getUserStatsb3f5022ad593210a802c86cd06ae4165.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getUserStatsb3f5022ad593210a802c86cd06ae4165.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/user/stats'
*/
const getUserStatsb3f5022ad593210a802c86cd06ae4165Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserStatsb3f5022ad593210a802c86cd06ae4165.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/user/stats'
*/
getUserStatsb3f5022ad593210a802c86cd06ae4165Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserStatsb3f5022ad593210a802c86cd06ae4165.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getUserStats
* @see app/Http/Controllers/UserController.php:183
* @route '/user/stats'
*/
getUserStatsb3f5022ad593210a802c86cd06ae4165Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getUserStatsb3f5022ad593210a802c86cd06ae4165.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getUserStatsb3f5022ad593210a802c86cd06ae4165.form = getUserStatsb3f5022ad593210a802c86cd06ae4165Form

export const getUserStats = {
    '/api/user/stats': getUserStats9cde6edbf35d22a47518e36bc4756afc,
    '/user/stats': getUserStatsb3f5022ad593210a802c86cd06ae4165,
}

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/api/user/orders'
*/
const getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.url(options),
    method: 'get',
})

getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.definition = {
    methods: ["get","head"],
    url: '/api/user/orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/api/user/orders'
*/
getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.url = (options?: RouteQueryOptions) => {
    return getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/api/user/orders'
*/
getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/api/user/orders'
*/
getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/api/user/orders'
*/
const getOrderHistory4401c0bf2d6cb89eb065c59ea41733aaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/api/user/orders'
*/
getOrderHistory4401c0bf2d6cb89eb065c59ea41733aaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/api/user/orders'
*/
getOrderHistory4401c0bf2d6cb89eb065c59ea41733aaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa.form = getOrderHistory4401c0bf2d6cb89eb065c59ea41733aaForm
/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/user/orders'
*/
const getOrderHistorydb9668820bf1f421ce52066b8e9b1b24 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.url(options),
    method: 'get',
})

getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.definition = {
    methods: ["get","head"],
    url: '/user/orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/user/orders'
*/
getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.url = (options?: RouteQueryOptions) => {
    return getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/user/orders'
*/
getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/user/orders'
*/
getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/user/orders'
*/
const getOrderHistorydb9668820bf1f421ce52066b8e9b1b24Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/user/orders'
*/
getOrderHistorydb9668820bf1f421ce52066b8e9b1b24Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::getOrderHistory
* @see app/Http/Controllers/UserController.php:261
* @route '/user/orders'
*/
getOrderHistorydb9668820bf1f421ce52066b8e9b1b24Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getOrderHistorydb9668820bf1f421ce52066b8e9b1b24.form = getOrderHistorydb9668820bf1f421ce52066b8e9b1b24Form

export const getOrderHistory = {
    '/api/user/orders': getOrderHistory4401c0bf2d6cb89eb065c59ea41733aa,
    '/user/orders': getOrderHistorydb9668820bf1f421ce52066b8e9b1b24,
}

/**
* @see \App\Http\Controllers\UserController::deleteAccount
* @see app/Http/Controllers/UserController.php:314
* @route '/api/user/account'
*/
const deleteAccounted60ce6792c03122554fe8ec5502f173 = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteAccounted60ce6792c03122554fe8ec5502f173.url(options),
    method: 'delete',
})

deleteAccounted60ce6792c03122554fe8ec5502f173.definition = {
    methods: ["delete"],
    url: '/api/user/account',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\UserController::deleteAccount
* @see app/Http/Controllers/UserController.php:314
* @route '/api/user/account'
*/
deleteAccounted60ce6792c03122554fe8ec5502f173.url = (options?: RouteQueryOptions) => {
    return deleteAccounted60ce6792c03122554fe8ec5502f173.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::deleteAccount
* @see app/Http/Controllers/UserController.php:314
* @route '/api/user/account'
*/
deleteAccounted60ce6792c03122554fe8ec5502f173.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteAccounted60ce6792c03122554fe8ec5502f173.url(options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\UserController::deleteAccount
* @see app/Http/Controllers/UserController.php:314
* @route '/api/user/account'
*/
const deleteAccounted60ce6792c03122554fe8ec5502f173Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deleteAccounted60ce6792c03122554fe8ec5502f173.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::deleteAccount
* @see app/Http/Controllers/UserController.php:314
* @route '/api/user/account'
*/
deleteAccounted60ce6792c03122554fe8ec5502f173Form.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deleteAccounted60ce6792c03122554fe8ec5502f173.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

deleteAccounted60ce6792c03122554fe8ec5502f173.form = deleteAccounted60ce6792c03122554fe8ec5502f173Form
/**
* @see \App\Http\Controllers\UserController::deleteAccount
* @see app/Http/Controllers/UserController.php:314
* @route '/user/account'
*/
const deleteAccount1f8a459a2b15b0ad6ec250f39a272e83 = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteAccount1f8a459a2b15b0ad6ec250f39a272e83.url(options),
    method: 'delete',
})

deleteAccount1f8a459a2b15b0ad6ec250f39a272e83.definition = {
    methods: ["delete"],
    url: '/user/account',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\UserController::deleteAccount
* @see app/Http/Controllers/UserController.php:314
* @route '/user/account'
*/
deleteAccount1f8a459a2b15b0ad6ec250f39a272e83.url = (options?: RouteQueryOptions) => {
    return deleteAccount1f8a459a2b15b0ad6ec250f39a272e83.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::deleteAccount
* @see app/Http/Controllers/UserController.php:314
* @route '/user/account'
*/
deleteAccount1f8a459a2b15b0ad6ec250f39a272e83.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteAccount1f8a459a2b15b0ad6ec250f39a272e83.url(options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\UserController::deleteAccount
* @see app/Http/Controllers/UserController.php:314
* @route '/user/account'
*/
const deleteAccount1f8a459a2b15b0ad6ec250f39a272e83Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deleteAccount1f8a459a2b15b0ad6ec250f39a272e83.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::deleteAccount
* @see app/Http/Controllers/UserController.php:314
* @route '/user/account'
*/
deleteAccount1f8a459a2b15b0ad6ec250f39a272e83Form.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deleteAccount1f8a459a2b15b0ad6ec250f39a272e83.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

deleteAccount1f8a459a2b15b0ad6ec250f39a272e83.form = deleteAccount1f8a459a2b15b0ad6ec250f39a272e83Form

export const deleteAccount = {
    '/api/user/account': deleteAccounted60ce6792c03122554fe8ec5502f173,
    '/user/account': deleteAccount1f8a459a2b15b0ad6ec250f39a272e83,
}

/**
* @see \App\Http\Controllers\UserController::changePassword
* @see app/Http/Controllers/UserController.php:378
* @route '/api/user/change-password'
*/
const changePassword03bc8b05c1cd129c7acaa9124a0b7791 = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: changePassword03bc8b05c1cd129c7acaa9124a0b7791.url(options),
    method: 'put',
})

changePassword03bc8b05c1cd129c7acaa9124a0b7791.definition = {
    methods: ["put"],
    url: '/api/user/change-password',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UserController::changePassword
* @see app/Http/Controllers/UserController.php:378
* @route '/api/user/change-password'
*/
changePassword03bc8b05c1cd129c7acaa9124a0b7791.url = (options?: RouteQueryOptions) => {
    return changePassword03bc8b05c1cd129c7acaa9124a0b7791.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::changePassword
* @see app/Http/Controllers/UserController.php:378
* @route '/api/user/change-password'
*/
changePassword03bc8b05c1cd129c7acaa9124a0b7791.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: changePassword03bc8b05c1cd129c7acaa9124a0b7791.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UserController::changePassword
* @see app/Http/Controllers/UserController.php:378
* @route '/api/user/change-password'
*/
const changePassword03bc8b05c1cd129c7acaa9124a0b7791Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: changePassword03bc8b05c1cd129c7acaa9124a0b7791.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::changePassword
* @see app/Http/Controllers/UserController.php:378
* @route '/api/user/change-password'
*/
changePassword03bc8b05c1cd129c7acaa9124a0b7791Form.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: changePassword03bc8b05c1cd129c7acaa9124a0b7791.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

changePassword03bc8b05c1cd129c7acaa9124a0b7791.form = changePassword03bc8b05c1cd129c7acaa9124a0b7791Form
/**
* @see \App\Http\Controllers\UserController::changePassword
* @see app/Http/Controllers/UserController.php:378
* @route '/user/change-password'
*/
const changePassworde7d7a6dca079030fdca11df6f9bb70d0 = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: changePassworde7d7a6dca079030fdca11df6f9bb70d0.url(options),
    method: 'put',
})

changePassworde7d7a6dca079030fdca11df6f9bb70d0.definition = {
    methods: ["put"],
    url: '/user/change-password',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UserController::changePassword
* @see app/Http/Controllers/UserController.php:378
* @route '/user/change-password'
*/
changePassworde7d7a6dca079030fdca11df6f9bb70d0.url = (options?: RouteQueryOptions) => {
    return changePassworde7d7a6dca079030fdca11df6f9bb70d0.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::changePassword
* @see app/Http/Controllers/UserController.php:378
* @route '/user/change-password'
*/
changePassworde7d7a6dca079030fdca11df6f9bb70d0.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: changePassworde7d7a6dca079030fdca11df6f9bb70d0.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UserController::changePassword
* @see app/Http/Controllers/UserController.php:378
* @route '/user/change-password'
*/
const changePassworde7d7a6dca079030fdca11df6f9bb70d0Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: changePassworde7d7a6dca079030fdca11df6f9bb70d0.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::changePassword
* @see app/Http/Controllers/UserController.php:378
* @route '/user/change-password'
*/
changePassworde7d7a6dca079030fdca11df6f9bb70d0Form.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: changePassworde7d7a6dca079030fdca11df6f9bb70d0.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

changePassworde7d7a6dca079030fdca11df6f9bb70d0.form = changePassworde7d7a6dca079030fdca11df6f9bb70d0Form

export const changePassword = {
    '/api/user/change-password': changePassword03bc8b05c1cd129c7acaa9124a0b7791,
    '/user/change-password': changePassworde7d7a6dca079030fdca11df6f9bb70d0,
}

const UserController = { getProfile, updateProfile, getUserSummary, getUserStats, getOrderHistory, deleteAccount, changePassword }

export default UserController