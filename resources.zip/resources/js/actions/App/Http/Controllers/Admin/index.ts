import DashboardController from './DashboardController'
import AgentApplicationController from './AgentApplicationController'

const Admin = {
    DashboardController,
    AgentApplicationController,
}

export default Admin