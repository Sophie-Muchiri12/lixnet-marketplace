import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
const index72952c054b2847b5cfb479cc9cee0b47 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index72952c054b2847b5cfb479cc9cee0b47.url(options),
    method: 'get',
})

index72952c054b2847b5cfb479cc9cee0b47.definition = {
    methods: ["get","head"],
    url: '/api/admin/agent-applications/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
index72952c054b2847b5cfb479cc9cee0b47.url = (options?: RouteQueryOptions) => {
    return index72952c054b2847b5cfb479cc9cee0b47.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
index72952c054b2847b5cfb479cc9cee0b47.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index72952c054b2847b5cfb479cc9cee0b47.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
index72952c054b2847b5cfb479cc9cee0b47.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index72952c054b2847b5cfb479cc9cee0b47.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
const index72952c054b2847b5cfb479cc9cee0b47Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index72952c054b2847b5cfb479cc9cee0b47.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
index72952c054b2847b5cfb479cc9cee0b47Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index72952c054b2847b5cfb479cc9cee0b47.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
index72952c054b2847b5cfb479cc9cee0b47Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index72952c054b2847b5cfb479cc9cee0b47.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index72952c054b2847b5cfb479cc9cee0b47.form = index72952c054b2847b5cfb479cc9cee0b47Form
/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
const index82294aafde23704be2f7002cbd1b50ee = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index82294aafde23704be2f7002cbd1b50ee.url(options),
    method: 'get',
})

index82294aafde23704be2f7002cbd1b50ee.definition = {
    methods: ["get","head"],
    url: '/admin/agent-applications/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
index82294aafde23704be2f7002cbd1b50ee.url = (options?: RouteQueryOptions) => {
    return index82294aafde23704be2f7002cbd1b50ee.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
index82294aafde23704be2f7002cbd1b50ee.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index82294aafde23704be2f7002cbd1b50ee.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
index82294aafde23704be2f7002cbd1b50ee.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index82294aafde23704be2f7002cbd1b50ee.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
const index82294aafde23704be2f7002cbd1b50eeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index82294aafde23704be2f7002cbd1b50ee.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
index82294aafde23704be2f7002cbd1b50eeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index82294aafde23704be2f7002cbd1b50ee.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
index82294aafde23704be2f7002cbd1b50eeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index82294aafde23704be2f7002cbd1b50ee.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index82294aafde23704be2f7002cbd1b50ee.form = index82294aafde23704be2f7002cbd1b50eeForm

export const index = {
    '/api/admin/agent-applications/list': index72952c054b2847b5cfb479cc9cee0b47,
    '/admin/agent-applications/list': index82294aafde23704be2f7002cbd1b50ee,
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
const show6a23637c4e747d6dbc80198a57a3e702 = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show6a23637c4e747d6dbc80198a57a3e702.url(args, options),
    method: 'get',
})

show6a23637c4e747d6dbc80198a57a3e702.definition = {
    methods: ["get","head"],
    url: '/api/admin/agent-applications/details/{application}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
show6a23637c4e747d6dbc80198a57a3e702.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return show6a23637c4e747d6dbc80198a57a3e702.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
show6a23637c4e747d6dbc80198a57a3e702.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show6a23637c4e747d6dbc80198a57a3e702.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
show6a23637c4e747d6dbc80198a57a3e702.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show6a23637c4e747d6dbc80198a57a3e702.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
const show6a23637c4e747d6dbc80198a57a3e702Form = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show6a23637c4e747d6dbc80198a57a3e702.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
show6a23637c4e747d6dbc80198a57a3e702Form.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show6a23637c4e747d6dbc80198a57a3e702.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
show6a23637c4e747d6dbc80198a57a3e702Form.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show6a23637c4e747d6dbc80198a57a3e702.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show6a23637c4e747d6dbc80198a57a3e702.form = show6a23637c4e747d6dbc80198a57a3e702Form
/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
const show9176128268368e088779d04e0e1b8fc8 = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show9176128268368e088779d04e0e1b8fc8.url(args, options),
    method: 'get',
})

show9176128268368e088779d04e0e1b8fc8.definition = {
    methods: ["get","head"],
    url: '/admin/agent-applications/details/{application}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
show9176128268368e088779d04e0e1b8fc8.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return show9176128268368e088779d04e0e1b8fc8.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
show9176128268368e088779d04e0e1b8fc8.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show9176128268368e088779d04e0e1b8fc8.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
show9176128268368e088779d04e0e1b8fc8.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show9176128268368e088779d04e0e1b8fc8.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
const show9176128268368e088779d04e0e1b8fc8Form = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show9176128268368e088779d04e0e1b8fc8.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
show9176128268368e088779d04e0e1b8fc8Form.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show9176128268368e088779d04e0e1b8fc8.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
show9176128268368e088779d04e0e1b8fc8Form.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show9176128268368e088779d04e0e1b8fc8.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show9176128268368e088779d04e0e1b8fc8.form = show9176128268368e088779d04e0e1b8fc8Form

export const show = {
    '/api/admin/agent-applications/details/{application}': show6a23637c4e747d6dbc80198a57a3e702,
    '/admin/agent-applications/details/{application}': show9176128268368e088779d04e0e1b8fc8,
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/api/admin/agent-applications/{application}/approve'
*/
const approve1af2cdf7e208ca6478456d7bdad0bf4b = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve1af2cdf7e208ca6478456d7bdad0bf4b.url(args, options),
    method: 'post',
})

approve1af2cdf7e208ca6478456d7bdad0bf4b.definition = {
    methods: ["post"],
    url: '/api/admin/agent-applications/{application}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/api/admin/agent-applications/{application}/approve'
*/
approve1af2cdf7e208ca6478456d7bdad0bf4b.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return approve1af2cdf7e208ca6478456d7bdad0bf4b.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/api/admin/agent-applications/{application}/approve'
*/
approve1af2cdf7e208ca6478456d7bdad0bf4b.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve1af2cdf7e208ca6478456d7bdad0bf4b.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/api/admin/agent-applications/{application}/approve'
*/
const approve1af2cdf7e208ca6478456d7bdad0bf4bForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve1af2cdf7e208ca6478456d7bdad0bf4b.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/api/admin/agent-applications/{application}/approve'
*/
approve1af2cdf7e208ca6478456d7bdad0bf4bForm.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve1af2cdf7e208ca6478456d7bdad0bf4b.url(args, options),
    method: 'post',
})

approve1af2cdf7e208ca6478456d7bdad0bf4b.form = approve1af2cdf7e208ca6478456d7bdad0bf4bForm
/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/admin/agent-applications/{application}/approve'
*/
const approve3253e6303afb40117ac74dc4cc507123 = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve3253e6303afb40117ac74dc4cc507123.url(args, options),
    method: 'post',
})

approve3253e6303afb40117ac74dc4cc507123.definition = {
    methods: ["post"],
    url: '/admin/agent-applications/{application}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/admin/agent-applications/{application}/approve'
*/
approve3253e6303afb40117ac74dc4cc507123.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return approve3253e6303afb40117ac74dc4cc507123.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/admin/agent-applications/{application}/approve'
*/
approve3253e6303afb40117ac74dc4cc507123.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve3253e6303afb40117ac74dc4cc507123.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/admin/agent-applications/{application}/approve'
*/
const approve3253e6303afb40117ac74dc4cc507123Form = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve3253e6303afb40117ac74dc4cc507123.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/admin/agent-applications/{application}/approve'
*/
approve3253e6303afb40117ac74dc4cc507123Form.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve3253e6303afb40117ac74dc4cc507123.url(args, options),
    method: 'post',
})

approve3253e6303afb40117ac74dc4cc507123.form = approve3253e6303afb40117ac74dc4cc507123Form

export const approve = {
    '/api/admin/agent-applications/{application}/approve': approve1af2cdf7e208ca6478456d7bdad0bf4b,
    '/admin/agent-applications/{application}/approve': approve3253e6303afb40117ac74dc4cc507123,
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/api/admin/agent-applications/{application}/reject'
*/
const reject780366bf5e6bc52ddaef0fe2e2d6098c = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject780366bf5e6bc52ddaef0fe2e2d6098c.url(args, options),
    method: 'post',
})

reject780366bf5e6bc52ddaef0fe2e2d6098c.definition = {
    methods: ["post"],
    url: '/api/admin/agent-applications/{application}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/api/admin/agent-applications/{application}/reject'
*/
reject780366bf5e6bc52ddaef0fe2e2d6098c.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return reject780366bf5e6bc52ddaef0fe2e2d6098c.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/api/admin/agent-applications/{application}/reject'
*/
reject780366bf5e6bc52ddaef0fe2e2d6098c.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject780366bf5e6bc52ddaef0fe2e2d6098c.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/api/admin/agent-applications/{application}/reject'
*/
const reject780366bf5e6bc52ddaef0fe2e2d6098cForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject780366bf5e6bc52ddaef0fe2e2d6098c.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/api/admin/agent-applications/{application}/reject'
*/
reject780366bf5e6bc52ddaef0fe2e2d6098cForm.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject780366bf5e6bc52ddaef0fe2e2d6098c.url(args, options),
    method: 'post',
})

reject780366bf5e6bc52ddaef0fe2e2d6098c.form = reject780366bf5e6bc52ddaef0fe2e2d6098cForm
/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/admin/agent-applications/{application}/reject'
*/
const rejectc9c5a3bcff402fdf64f8f77dd6c79f52 = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectc9c5a3bcff402fdf64f8f77dd6c79f52.url(args, options),
    method: 'post',
})

rejectc9c5a3bcff402fdf64f8f77dd6c79f52.definition = {
    methods: ["post"],
    url: '/admin/agent-applications/{application}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/admin/agent-applications/{application}/reject'
*/
rejectc9c5a3bcff402fdf64f8f77dd6c79f52.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return rejectc9c5a3bcff402fdf64f8f77dd6c79f52.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/admin/agent-applications/{application}/reject'
*/
rejectc9c5a3bcff402fdf64f8f77dd6c79f52.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectc9c5a3bcff402fdf64f8f77dd6c79f52.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/admin/agent-applications/{application}/reject'
*/
const rejectc9c5a3bcff402fdf64f8f77dd6c79f52Form = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rejectc9c5a3bcff402fdf64f8f77dd6c79f52.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/admin/agent-applications/{application}/reject'
*/
rejectc9c5a3bcff402fdf64f8f77dd6c79f52Form.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: rejectc9c5a3bcff402fdf64f8f77dd6c79f52.url(args, options),
    method: 'post',
})

rejectc9c5a3bcff402fdf64f8f77dd6c79f52.form = rejectc9c5a3bcff402fdf64f8f77dd6c79f52Form

export const reject = {
    '/api/admin/agent-applications/{application}/reject': reject780366bf5e6bc52ddaef0fe2e2d6098c,
    '/admin/agent-applications/{application}/reject': rejectc9c5a3bcff402fdf64f8f77dd6c79f52,
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
const downloadDocument1ec1bca7174302c253fd9121488d625d = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDocument1ec1bca7174302c253fd9121488d625d.url(args, options),
    method: 'get',
})

downloadDocument1ec1bca7174302c253fd9121488d625d.definition = {
    methods: ["get","head"],
    url: '/api/admin/agent-applications/{application}/documents/{documentType}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocument1ec1bca7174302c253fd9121488d625d.url = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            application: args[0],
            documentType: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
        documentType: args.documentType,
    }

    return downloadDocument1ec1bca7174302c253fd9121488d625d.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace('{documentType}', parsedArgs.documentType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocument1ec1bca7174302c253fd9121488d625d.get = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDocument1ec1bca7174302c253fd9121488d625d.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocument1ec1bca7174302c253fd9121488d625d.head = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadDocument1ec1bca7174302c253fd9121488d625d.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
const downloadDocument1ec1bca7174302c253fd9121488d625dForm = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocument1ec1bca7174302c253fd9121488d625d.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocument1ec1bca7174302c253fd9121488d625dForm.get = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocument1ec1bca7174302c253fd9121488d625d.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocument1ec1bca7174302c253fd9121488d625dForm.head = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocument1ec1bca7174302c253fd9121488d625d.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

downloadDocument1ec1bca7174302c253fd9121488d625d.form = downloadDocument1ec1bca7174302c253fd9121488d625dForm
/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
const downloadDocument5381647b887479ea839fd0ef52441a26 = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDocument5381647b887479ea839fd0ef52441a26.url(args, options),
    method: 'get',
})

downloadDocument5381647b887479ea839fd0ef52441a26.definition = {
    methods: ["get","head"],
    url: '/admin/agent-applications/{application}/documents/{documentType}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocument5381647b887479ea839fd0ef52441a26.url = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            application: args[0],
            documentType: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
        documentType: args.documentType,
    }

    return downloadDocument5381647b887479ea839fd0ef52441a26.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace('{documentType}', parsedArgs.documentType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocument5381647b887479ea839fd0ef52441a26.get = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDocument5381647b887479ea839fd0ef52441a26.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocument5381647b887479ea839fd0ef52441a26.head = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadDocument5381647b887479ea839fd0ef52441a26.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
const downloadDocument5381647b887479ea839fd0ef52441a26Form = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocument5381647b887479ea839fd0ef52441a26.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocument5381647b887479ea839fd0ef52441a26Form.get = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocument5381647b887479ea839fd0ef52441a26.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocument
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocument5381647b887479ea839fd0ef52441a26Form.head = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocument5381647b887479ea839fd0ef52441a26.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

downloadDocument5381647b887479ea839fd0ef52441a26.form = downloadDocument5381647b887479ea839fd0ef52441a26Form

export const downloadDocument = {
    '/api/admin/agent-applications/{application}/documents/{documentType}': downloadDocument1ec1bca7174302c253fd9121488d625d,
    '/admin/agent-applications/{application}/documents/{documentType}': downloadDocument5381647b887479ea839fd0ef52441a26,
}

const AgentApplicationController = { index, show, approve, reject, downloadDocument }

export default AgentApplicationController