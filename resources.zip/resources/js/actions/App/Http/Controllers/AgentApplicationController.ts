import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/api/agent-application/status'
*/
const status9b94d07ccad640eeb6f2a2057a05d1df = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status9b94d07ccad640eeb6f2a2057a05d1df.url(options),
    method: 'get',
})

status9b94d07ccad640eeb6f2a2057a05d1df.definition = {
    methods: ["get","head"],
    url: '/api/agent-application/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/api/agent-application/status'
*/
status9b94d07ccad640eeb6f2a2057a05d1df.url = (options?: RouteQueryOptions) => {
    return status9b94d07ccad640eeb6f2a2057a05d1df.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/api/agent-application/status'
*/
status9b94d07ccad640eeb6f2a2057a05d1df.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status9b94d07ccad640eeb6f2a2057a05d1df.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/api/agent-application/status'
*/
status9b94d07ccad640eeb6f2a2057a05d1df.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status9b94d07ccad640eeb6f2a2057a05d1df.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/api/agent-application/status'
*/
const status9b94d07ccad640eeb6f2a2057a05d1dfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status9b94d07ccad640eeb6f2a2057a05d1df.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/api/agent-application/status'
*/
status9b94d07ccad640eeb6f2a2057a05d1dfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status9b94d07ccad640eeb6f2a2057a05d1df.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/api/agent-application/status'
*/
status9b94d07ccad640eeb6f2a2057a05d1dfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status9b94d07ccad640eeb6f2a2057a05d1df.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

status9b94d07ccad640eeb6f2a2057a05d1df.form = status9b94d07ccad640eeb6f2a2057a05d1dfForm
/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/agent-application/status'
*/
const statuse037f77538f8fcd4a03c319d13fe905c = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statuse037f77538f8fcd4a03c319d13fe905c.url(options),
    method: 'get',
})

statuse037f77538f8fcd4a03c319d13fe905c.definition = {
    methods: ["get","head"],
    url: '/agent-application/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/agent-application/status'
*/
statuse037f77538f8fcd4a03c319d13fe905c.url = (options?: RouteQueryOptions) => {
    return statuse037f77538f8fcd4a03c319d13fe905c.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/agent-application/status'
*/
statuse037f77538f8fcd4a03c319d13fe905c.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statuse037f77538f8fcd4a03c319d13fe905c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/agent-application/status'
*/
statuse037f77538f8fcd4a03c319d13fe905c.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: statuse037f77538f8fcd4a03c319d13fe905c.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/agent-application/status'
*/
const statuse037f77538f8fcd4a03c319d13fe905cForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: statuse037f77538f8fcd4a03c319d13fe905c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/agent-application/status'
*/
statuse037f77538f8fcd4a03c319d13fe905cForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: statuse037f77538f8fcd4a03c319d13fe905c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::status
* @see app/Http/Controllers/AgentApplicationController.php:14
* @route '/agent-application/status'
*/
statuse037f77538f8fcd4a03c319d13fe905cForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: statuse037f77538f8fcd4a03c319d13fe905c.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

statuse037f77538f8fcd4a03c319d13fe905c.form = statuse037f77538f8fcd4a03c319d13fe905cForm

export const status = {
    '/api/agent-application/status': status9b94d07ccad640eeb6f2a2057a05d1df,
    '/agent-application/status': statuse037f77538f8fcd4a03c319d13fe905c,
}

/**
* @see \App\Http\Controllers\AgentApplicationController::submit
* @see app/Http/Controllers/AgentApplicationController.php:34
* @route '/api/agent-application/submit'
*/
const submitf748256dad0247b9aa3263c928256865 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitf748256dad0247b9aa3263c928256865.url(options),
    method: 'post',
})

submitf748256dad0247b9aa3263c928256865.definition = {
    methods: ["post"],
    url: '/api/agent-application/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AgentApplicationController::submit
* @see app/Http/Controllers/AgentApplicationController.php:34
* @route '/api/agent-application/submit'
*/
submitf748256dad0247b9aa3263c928256865.url = (options?: RouteQueryOptions) => {
    return submitf748256dad0247b9aa3263c928256865.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AgentApplicationController::submit
* @see app/Http/Controllers/AgentApplicationController.php:34
* @route '/api/agent-application/submit'
*/
submitf748256dad0247b9aa3263c928256865.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitf748256dad0247b9aa3263c928256865.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::submit
* @see app/Http/Controllers/AgentApplicationController.php:34
* @route '/api/agent-application/submit'
*/
const submitf748256dad0247b9aa3263c928256865Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitf748256dad0247b9aa3263c928256865.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::submit
* @see app/Http/Controllers/AgentApplicationController.php:34
* @route '/api/agent-application/submit'
*/
submitf748256dad0247b9aa3263c928256865Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitf748256dad0247b9aa3263c928256865.url(options),
    method: 'post',
})

submitf748256dad0247b9aa3263c928256865.form = submitf748256dad0247b9aa3263c928256865Form
/**
* @see \App\Http\Controllers\AgentApplicationController::submit
* @see app/Http/Controllers/AgentApplicationController.php:34
* @route '/agent-application/submit'
*/
const submit0b76aa0aae7da99e862ef11b9f83e3bc = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit0b76aa0aae7da99e862ef11b9f83e3bc.url(options),
    method: 'post',
})

submit0b76aa0aae7da99e862ef11b9f83e3bc.definition = {
    methods: ["post"],
    url: '/agent-application/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AgentApplicationController::submit
* @see app/Http/Controllers/AgentApplicationController.php:34
* @route '/agent-application/submit'
*/
submit0b76aa0aae7da99e862ef11b9f83e3bc.url = (options?: RouteQueryOptions) => {
    return submit0b76aa0aae7da99e862ef11b9f83e3bc.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AgentApplicationController::submit
* @see app/Http/Controllers/AgentApplicationController.php:34
* @route '/agent-application/submit'
*/
submit0b76aa0aae7da99e862ef11b9f83e3bc.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit0b76aa0aae7da99e862ef11b9f83e3bc.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::submit
* @see app/Http/Controllers/AgentApplicationController.php:34
* @route '/agent-application/submit'
*/
const submit0b76aa0aae7da99e862ef11b9f83e3bcForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit0b76aa0aae7da99e862ef11b9f83e3bc.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AgentApplicationController::submit
* @see app/Http/Controllers/AgentApplicationController.php:34
* @route '/agent-application/submit'
*/
submit0b76aa0aae7da99e862ef11b9f83e3bcForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit0b76aa0aae7da99e862ef11b9f83e3bc.url(options),
    method: 'post',
})

submit0b76aa0aae7da99e862ef11b9f83e3bc.form = submit0b76aa0aae7da99e862ef11b9f83e3bcForm

export const submit = {
    '/api/agent-application/submit': submitf748256dad0247b9aa3263c928256865,
    '/agent-application/submit': submit0b76aa0aae7da99e862ef11b9f83e3bc,
}

const AgentApplicationController = { status, submit }

export default AgentApplicationController