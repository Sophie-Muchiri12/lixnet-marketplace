import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/agent-applications/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/api/admin/agent-applications/list'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/agent-applications/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::index
* @see app/Http/Controllers/Admin/AgentApplicationController.php:18
* @route '/admin/agent-applications/list'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
export const show = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/admin/agent-applications/details/{application}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
show.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return show.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
show.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
show.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
const showForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
showForm.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/api/admin/agent-applications/details/{application}'
*/
showForm.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
export const show = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/agent-applications/details/{application}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
show.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return show.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
show.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
show.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
const showForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
showForm.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::show
* @see app/Http/Controllers/Admin/AgentApplicationController.php:73
* @route '/admin/agent-applications/details/{application}'
*/
showForm.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/api/admin/agent-applications/{application}/approve'
*/
export const approve = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/api/admin/agent-applications/{application}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/api/admin/agent-applications/{application}/approve'
*/
approve.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return approve.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/api/admin/agent-applications/{application}/approve'
*/
approve.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/api/admin/agent-applications/{application}/approve'
*/
const approveForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/api/admin/agent-applications/{application}/approve'
*/
approveForm.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

approve.form = approveForm

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/admin/agent-applications/{application}/approve'
*/
export const approve = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/admin/agent-applications/{application}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/admin/agent-applications/{application}/approve'
*/
approve.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return approve.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/admin/agent-applications/{application}/approve'
*/
approve.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/admin/agent-applications/{application}/approve'
*/
const approveForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::approve
* @see app/Http/Controllers/Admin/AgentApplicationController.php:85
* @route '/admin/agent-applications/{application}/approve'
*/
approveForm.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

approve.form = approveForm

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/api/admin/agent-applications/{application}/reject'
*/
export const reject = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/api/admin/agent-applications/{application}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/api/admin/agent-applications/{application}/reject'
*/
reject.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return reject.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/api/admin/agent-applications/{application}/reject'
*/
reject.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/api/admin/agent-applications/{application}/reject'
*/
const rejectForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/api/admin/agent-applications/{application}/reject'
*/
rejectForm.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, options),
    method: 'post',
})

reject.form = rejectForm

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/admin/agent-applications/{application}/reject'
*/
export const reject = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/admin/agent-applications/{application}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/admin/agent-applications/{application}/reject'
*/
reject.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { application: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            application: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
    }

    return reject.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/admin/agent-applications/{application}/reject'
*/
reject.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/admin/agent-applications/{application}/reject'
*/
const rejectForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::reject
* @see app/Http/Controllers/Admin/AgentApplicationController.php:139
* @route '/admin/agent-applications/{application}/reject'
*/
rejectForm.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, options),
    method: 'post',
})

reject.form = rejectForm

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
export const downloadDocuments = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDocuments.url(args, options),
    method: 'get',
})

downloadDocuments.definition = {
    methods: ["get","head"],
    url: '/api/admin/agent-applications/{application}/documents/{documentType}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocuments.url = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            application: args[0],
            documentType: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
        documentType: args.documentType,
    }

    return downloadDocuments.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace('{documentType}', parsedArgs.documentType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocuments.get = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDocuments.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocuments.head = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadDocuments.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
const downloadDocumentsForm = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocuments.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocumentsForm.get = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocuments.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/api/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocumentsForm.head = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocuments.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

downloadDocuments.form = downloadDocumentsForm

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
export const downloadDocuments = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDocuments.url(args, options),
    method: 'get',
})

downloadDocuments.definition = {
    methods: ["get","head"],
    url: '/admin/agent-applications/{application}/documents/{documentType}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocuments.url = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            application: args[0],
            documentType: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        application: typeof args.application === 'object'
        ? args.application.id
        : args.application,
        documentType: args.documentType,
    }

    return downloadDocuments.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace('{documentType}', parsedArgs.documentType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocuments.get = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDocuments.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocuments.head = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadDocuments.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
const downloadDocumentsForm = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocuments.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocumentsForm.get = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocuments.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentApplicationController::downloadDocuments
* @see app/Http/Controllers/Admin/AgentApplicationController.php:173
* @route '/admin/agent-applications/{application}/documents/{documentType}'
*/
downloadDocumentsForm.head = (args: { application: number | { id: number }, documentType: string | number } | [application: number | { id: number }, documentType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: downloadDocuments.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

downloadDocuments.form = downloadDocumentsForm

const agentApplications = {
    index,
    show,
    approve,
    reject,
    downloadDocuments,
}

export default agentApplications