import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import users from './users'
import agentApplications from './agent-applications'
import categories from './categories'
import products from './products'
import jobs from './jobs'
/**
* @see routes/web.php:139
* @route '/admin/users-list'
*/
export const userlist = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userlist.url(options),
    method: 'get',
})

userlist.definition = {
    methods: ["get","head"],
    url: '/admin/users-list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:139
* @route '/admin/users-list'
*/
userlist.url = (options?: RouteQueryOptions) => {
    return userlist.definition.url + queryParams(options)
}

/**
* @see routes/web.php:139
* @route '/admin/users-list'
*/
userlist.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userlist.url(options),
    method: 'get',
})

/**
* @see routes/web.php:139
* @route '/admin/users-list'
*/
userlist.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: userlist.url(options),
    method: 'head',
})

/**
* @see routes/web.php:139
* @route '/admin/users-list'
*/
const userlistForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: userlist.url(options),
    method: 'get',
})

/**
* @see routes/web.php:139
* @route '/admin/users-list'
*/
userlistForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: userlist.url(options),
    method: 'get',
})

/**
* @see routes/web.php:139
* @route '/admin/users-list'
*/
userlistForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: userlist.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

userlist.form = userlistForm

/**
* @see routes/web.php:143
* @route '/admin/users-list/{userId}'
*/
export const userdetails = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userdetails.url(args, options),
    method: 'get',
})

userdetails.definition = {
    methods: ["get","head"],
    url: '/admin/users-list/{userId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:143
* @route '/admin/users-list/{userId}'
*/
userdetails.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    if (Array.isArray(args)) {
        args = {
            userId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        userId: args.userId,
    }

    return userdetails.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:143
* @route '/admin/users-list/{userId}'
*/
userdetails.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userdetails.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:143
* @route '/admin/users-list/{userId}'
*/
userdetails.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: userdetails.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:143
* @route '/admin/users-list/{userId}'
*/
const userdetailsForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: userdetails.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:143
* @route '/admin/users-list/{userId}'
*/
userdetailsForm.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: userdetails.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:143
* @route '/admin/users-list/{userId}'
*/
userdetailsForm.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: userdetails.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

userdetails.form = userdetailsForm

/**
* @see routes/web.php:150
* @route '/admin/categories'
*/
export const categories = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})

categories.definition = {
    methods: ["get","head"],
    url: '/admin/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:150
* @route '/admin/categories'
*/
categories.url = (options?: RouteQueryOptions) => {
    return categories.definition.url + queryParams(options)
}

/**
* @see routes/web.php:150
* @route '/admin/categories'
*/
categories.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})

/**
* @see routes/web.php:150
* @route '/admin/categories'
*/
categories.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: categories.url(options),
    method: 'head',
})

/**
* @see routes/web.php:150
* @route '/admin/categories'
*/
const categoriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: categories.url(options),
    method: 'get',
})

/**
* @see routes/web.php:150
* @route '/admin/categories'
*/
categoriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: categories.url(options),
    method: 'get',
})

/**
* @see routes/web.php:150
* @route '/admin/categories'
*/
categoriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: categories.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

categories.form = categoriesForm

/**
* @see routes/web.php:165
* @route '/admin/products'
*/
export const products = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: products.url(options),
    method: 'get',
})

products.definition = {
    methods: ["get","head"],
    url: '/admin/products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:165
* @route '/admin/products'
*/
products.url = (options?: RouteQueryOptions) => {
    return products.definition.url + queryParams(options)
}

/**
* @see routes/web.php:165
* @route '/admin/products'
*/
products.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: products.url(options),
    method: 'get',
})

/**
* @see routes/web.php:165
* @route '/admin/products'
*/
products.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: products.url(options),
    method: 'head',
})

/**
* @see routes/web.php:165
* @route '/admin/products'
*/
const productsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: products.url(options),
    method: 'get',
})

/**
* @see routes/web.php:165
* @route '/admin/products'
*/
productsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: products.url(options),
    method: 'get',
})

/**
* @see routes/web.php:165
* @route '/admin/products'
*/
productsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: products.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

products.form = productsForm

const admin = {
    users,
    agentApplications,
    userlist,
    userdetails,
    categories,
    products,
    jobs,
}

export default admin