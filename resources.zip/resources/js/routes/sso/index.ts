import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
export const availableProducts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableProducts.url(options),
    method: 'get',
})

availableProducts.definition = {
    methods: ["get","head"],
    url: '/api/sso/available-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
availableProducts.url = (options?: RouteQueryOptions) => {
    return availableProducts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
availableProducts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
availableProducts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availableProducts.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
const availableProductsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: availableProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
availableProductsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: availableProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/api/sso/available-products'
*/
availableProductsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: availableProducts.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

availableProducts.form = availableProductsForm

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
export const availableProducts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableProducts.url(options),
    method: 'get',
})

availableProducts.definition = {
    methods: ["get","head"],
    url: '/sso/available-products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
availableProducts.url = (options?: RouteQueryOptions) => {
    return availableProducts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
availableProducts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
availableProducts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availableProducts.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
const availableProductsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: availableProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
availableProductsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: availableProducts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::availableProducts
* @see app/Http/Controllers/SSOProductController.php:118
* @route '/sso/available-products'
*/
availableProductsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: availableProducts.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

availableProducts.form = availableProductsForm

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
export const mySubscriptions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mySubscriptions.url(options),
    method: 'get',
})

mySubscriptions.definition = {
    methods: ["get","head"],
    url: '/api/sso/my-subscriptions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
mySubscriptions.url = (options?: RouteQueryOptions) => {
    return mySubscriptions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
mySubscriptions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mySubscriptions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
mySubscriptions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: mySubscriptions.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
const mySubscriptionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: mySubscriptions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
mySubscriptionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: mySubscriptions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/api/sso/my-subscriptions'
*/
mySubscriptionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: mySubscriptions.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

mySubscriptions.form = mySubscriptionsForm

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
export const mySubscriptions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mySubscriptions.url(options),
    method: 'get',
})

mySubscriptions.definition = {
    methods: ["get","head"],
    url: '/sso/my-subscriptions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
mySubscriptions.url = (options?: RouteQueryOptions) => {
    return mySubscriptions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
mySubscriptions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mySubscriptions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
mySubscriptions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: mySubscriptions.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
const mySubscriptionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: mySubscriptions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
mySubscriptionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: mySubscriptions.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::mySubscriptions
* @see app/Http/Controllers/SSOProductController.php:174
* @route '/sso/my-subscriptions'
*/
mySubscriptionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: mySubscriptions.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

mySubscriptions.form = mySubscriptionsForm

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
export const productDetails = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: productDetails.url(args, options),
    method: 'get',
})

productDetails.definition = {
    methods: ["get","head"],
    url: '/api/sso/product/{productId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
productDetails.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return productDetails.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
productDetails.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: productDetails.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
productDetails.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: productDetails.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
const productDetailsForm = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: productDetails.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
productDetailsForm.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: productDetails.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/api/sso/product/{productId}'
*/
productDetailsForm.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: productDetails.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

productDetails.form = productDetailsForm

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
export const productDetails = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: productDetails.url(args, options),
    method: 'get',
})

productDetails.definition = {
    methods: ["get","head"],
    url: '/sso/product/{productId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
productDetails.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return productDetails.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
productDetails.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: productDetails.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
productDetails.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: productDetails.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
const productDetailsForm = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: productDetails.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
productDetailsForm.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: productDetails.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::productDetails
* @see app/Http/Controllers/SSOProductController.php:327
* @route '/sso/product/{productId}'
*/
productDetailsForm.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: productDetails.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

productDetails.form = productDetailsForm

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
export const redirectGet = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectGet.url(args, options),
    method: 'get',
})

redirectGet.definition = {
    methods: ["get","head"],
    url: '/api/sso/redirect/{productId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectGet.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return redirectGet.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectGet.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectGet.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectGet.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirectGet.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
const redirectGetForm = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectGet.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectGetForm.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectGet.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectGetForm.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectGet.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

redirectGet.form = redirectGetForm

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
export const redirectGet = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectGet.url(args, options),
    method: 'get',
})

redirectGet.definition = {
    methods: ["get","head"],
    url: '/sso/redirect/{productId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectGet.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return redirectGet.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectGet.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectGet.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectGet.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirectGet.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
const redirectGetForm = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectGet.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectGetForm.get = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectGet.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectGet
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectGetForm.head = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectGet.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

redirectGet.form = redirectGetForm

/**
* @see \App\Http\Controllers\SSOProductController::redirectPost
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
export const redirectPost = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: redirectPost.url(args, options),
    method: 'post',
})

redirectPost.definition = {
    methods: ["post"],
    url: '/api/sso/redirect/{productId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SSOProductController::redirectPost
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectPost.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return redirectPost.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::redirectPost
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectPost.post = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: redirectPost.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectPost
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
const redirectPostForm = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: redirectPost.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectPost
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/api/sso/redirect/{productId}'
*/
redirectPostForm.post = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: redirectPost.url(args, options),
    method: 'post',
})

redirectPost.form = redirectPostForm

/**
* @see \App\Http\Controllers\SSOProductController::redirectPost
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
export const redirectPost = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: redirectPost.url(args, options),
    method: 'post',
})

redirectPost.definition = {
    methods: ["post"],
    url: '/sso/redirect/{productId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SSOProductController::redirectPost
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectPost.url = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productId: args }
    }

    if (Array.isArray(args)) {
        args = {
            productId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        productId: args.productId,
    }

    return redirectPost.definition.url
            .replace('{productId}', parsedArgs.productId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::redirectPost
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectPost.post = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: redirectPost.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectPost
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
const redirectPostForm = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: redirectPost.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::redirectPost
* @see app/Http/Controllers/SSOProductController.php:33
* @route '/sso/redirect/{productId}'
*/
redirectPostForm.post = (args: { productId: string | number } | [productId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: redirectPost.url(args, options),
    method: 'post',
})

redirectPost.form = redirectPostForm

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/api/sso/validate-token'
*/
export const validateToken = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validateToken.url(options),
    method: 'post',
})

validateToken.definition = {
    methods: ["post"],
    url: '/api/sso/validate-token',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/api/sso/validate-token'
*/
validateToken.url = (options?: RouteQueryOptions) => {
    return validateToken.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/api/sso/validate-token'
*/
validateToken.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validateToken.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/api/sso/validate-token'
*/
const validateTokenForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: validateToken.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/api/sso/validate-token'
*/
validateTokenForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: validateToken.url(options),
    method: 'post',
})

validateToken.form = validateTokenForm

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/sso/validate-token'
*/
export const validateToken = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validateToken.url(options),
    method: 'post',
})

validateToken.definition = {
    methods: ["post"],
    url: '/sso/validate-token',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/sso/validate-token'
*/
validateToken.url = (options?: RouteQueryOptions) => {
    return validateToken.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/sso/validate-token'
*/
validateToken.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validateToken.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/sso/validate-token'
*/
const validateTokenForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: validateToken.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SSOProductController::validateToken
* @see app/Http/Controllers/SSOProductController.php:225
* @route '/sso/validate-token'
*/
validateTokenForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: validateToken.url(options),
    method: 'post',
})

validateToken.form = validateTokenForm

const sso = {
    availableProducts,
    mySubscriptions,
    productDetails,
    redirectGet,
    redirectPost,
    validateToken,
}

export default sso