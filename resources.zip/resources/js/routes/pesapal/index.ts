import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/api/pesapal/callback'
*/
export const callback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

callback.definition = {
    methods: ["get","head"],
    url: '/api/pesapal/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/api/pesapal/callback'
*/
callback.url = (options?: RouteQueryOptions) => {
    return callback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/api/pesapal/callback'
*/
callback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/api/pesapal/callback'
*/
callback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: callback.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/api/pesapal/callback'
*/
const callbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/api/pesapal/callback'
*/
callbackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/api/pesapal/callback'
*/
callbackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

callback.form = callbackForm

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/pesapal/callback'
*/
export const callback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

callback.definition = {
    methods: ["get","head"],
    url: '/pesapal/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/pesapal/callback'
*/
callback.url = (options?: RouteQueryOptions) => {
    return callback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/pesapal/callback'
*/
callback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/pesapal/callback'
*/
callback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: callback.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/pesapal/callback'
*/
const callbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/pesapal/callback'
*/
callbackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::callback
* @see app/Http/Controllers/PesapalCallbackController.php:34
* @route '/pesapal/callback'
*/
callbackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

callback.form = callbackForm

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/api/pesapal/webhook'
*/
export const webhook = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: webhook.url(options),
    method: 'get',
})

webhook.definition = {
    methods: ["get","post","head"],
    url: '/api/pesapal/webhook',
} satisfies RouteDefinition<["get","post","head"]>

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/api/pesapal/webhook'
*/
webhook.url = (options?: RouteQueryOptions) => {
    return webhook.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/api/pesapal/webhook'
*/
webhook.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: webhook.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/api/pesapal/webhook'
*/
webhook.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: webhook.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/api/pesapal/webhook'
*/
webhook.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: webhook.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/api/pesapal/webhook'
*/
const webhookForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: webhook.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/api/pesapal/webhook'
*/
webhookForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: webhook.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/api/pesapal/webhook'
*/
webhookForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: webhook.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/api/pesapal/webhook'
*/
webhookForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: webhook.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

webhook.form = webhookForm

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/pesapal/webhook'
*/
export const webhook = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: webhook.url(options),
    method: 'get',
})

webhook.definition = {
    methods: ["get","post","head"],
    url: '/pesapal/webhook',
} satisfies RouteDefinition<["get","post","head"]>

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/pesapal/webhook'
*/
webhook.url = (options?: RouteQueryOptions) => {
    return webhook.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/pesapal/webhook'
*/
webhook.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: webhook.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/pesapal/webhook'
*/
webhook.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: webhook.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/pesapal/webhook'
*/
webhook.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: webhook.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/pesapal/webhook'
*/
const webhookForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: webhook.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/pesapal/webhook'
*/
webhookForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: webhook.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/pesapal/webhook'
*/
webhookForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: webhook.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::webhook
* @see app/Http/Controllers/PesapalCallbackController.php:67
* @route '/pesapal/webhook'
*/
webhookForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: webhook.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

webhook.form = webhookForm

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/api/pesapal/confirm'
*/
export const confirm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirm.url(options),
    method: 'get',
})

confirm.definition = {
    methods: ["get","head"],
    url: '/api/pesapal/confirm',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/api/pesapal/confirm'
*/
confirm.url = (options?: RouteQueryOptions) => {
    return confirm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/api/pesapal/confirm'
*/
confirm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/api/pesapal/confirm'
*/
confirm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: confirm.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/api/pesapal/confirm'
*/
const confirmForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/api/pesapal/confirm'
*/
confirmForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/api/pesapal/confirm'
*/
confirmForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

confirm.form = confirmForm

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/pesapal/confirm'
*/
export const confirm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirm.url(options),
    method: 'get',
})

confirm.definition = {
    methods: ["get","head"],
    url: '/pesapal/confirm',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/pesapal/confirm'
*/
confirm.url = (options?: RouteQueryOptions) => {
    return confirm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/pesapal/confirm'
*/
confirm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/pesapal/confirm'
*/
confirm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: confirm.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/pesapal/confirm'
*/
const confirmForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/pesapal/confirm'
*/
confirmForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PesapalCallbackController::confirm
* @see app/Http/Controllers/PesapalCallbackController.php:198
* @route '/pesapal/confirm'
*/
confirmForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

confirm.form = confirmForm

const pesapal = {
    callback,
    webhook,
    confirm,
}

export default pesapal